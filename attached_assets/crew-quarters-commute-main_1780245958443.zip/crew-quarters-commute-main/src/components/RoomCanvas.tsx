// src/components/RoomCanvas.tsx
// Renders the hand-crafted pixel art room scenes using canvas drawing
// Based on Andre's space_station_rooms HTML — preserves all animated elements
// ⚠️ WARNING: Drawing functions below are hand-tuned pixel art. Do NOT auto-refactor.
// If changes are needed, verify visually in browser after each edit.

import { useEffect, useRef } from "react";

export type RoomType = "command" | "security" | "workshop" | "archive";

interface RoomCanvasProps {
  room: RoomType;
  className?: string;
}

// Each room drawing function extracted from Andre's HTML
// They draw the static parts; animations are handled via setInterval

function drawCommandRoom(ctx: CanvasRenderingContext2D, S: number) {
  const r = (x: number, y: number, w: number, h: number, col: string) => { ctx.fillStyle = col; ctx.fillRect(x*S, y*S, w*S, h*S); };
  const p = (x: number, y: number, col: string) => r(x, y, 1, 1, col);
  const hline = (x: number, y: number, w: number, col: string) => r(x, y, w, 1, col);
  const vline = (x: number, y: number, h: number, col: string) => r(x, y, 1, h, col);

  // Floor
  r(0,90,384,166,"#0e1428");
  for(let y=90;y<256;y+=8) hline(0,y,384,"#121a34");
  for(let x=0;x<384;x+=12) vline(x,90,166,"#121a34");
  hline(0,255,384,"#4020a0"); hline(0,254,384,"#2a1460"); hline(0,253,384,"#180c40");
  // Ceiling
  r(0,0,384,90,"#0a0e1e"); hline(0,89,384,"#16203a");
  hline(0,10,384,"#2a1460"); hline(0,11,384,"#3a1e80"); hline(0,12,384,"#2a1460");
  // Walls
  r(0,50,384,42,"#0c1226"); hline(0,50,384,"#16203a"); hline(0,91,384,"#16203a");
  r(0,0,18,256,"#0c1220"); vline(17,0,256,"#16203a"); vline(0,0,256,"#3018a0"); vline(1,0,256,"#200e60");
  r(366,0,18,256,"#0c1220"); vline(366,0,256,"#16203a"); vline(383,0,256,"#3018a0"); vline(382,0,256,"#200e60");
  // Monitor 1 — orbital
  r(22,54,72,32,"#080e1e"); r(23,55,70,30,"#0a1228");
  for(let a=0;a<180;a+=8){const rad=a*Math.PI/180;p(Math.round(58+22*Math.cos(rad)),Math.round(70+8*Math.sin(rad)),"#4020a0");}
  p(58,70,"#6030c0"); r(56,68,4,4,"#5025b0"); p(42,67,"#8040e0"); p(76,67,"#8040e0");
  r(21,53,74,1,"#2a1460"); r(21,86,74,1,"#2a1460"); vline(21,53,34,"#2a1460"); vline(94,53,34,"#2a1460"); r(22,86,72,3,"#14102a");
  // Monitor 2 — star map
  r(150,52,84,36,"#080e1e"); r(151,53,82,34,"#06080e");
  [[155,56],[162,60],[170,55],[178,62],[186,58],[194,64],[200,57],[208,63],[215,59],[220,66],[165,70],[175,74],[185,68],[195,72],[205,76],[212,70]].forEach(([sx,sy])=>p(sx,sy,"#a060ff"));
  for(let gx=152;gx<233;gx+=10) vline(gx,53,34,"#180e30");
  for(let gy=54;gy<87;gy+=8) hline(152,gy,82,"#180e30");
  r(190,67,4,4,"#c080ff"); p(192,69,"#ffffff");
  hline(175,69,15,"#4020a0"); vline(190,56,13,"#4020a0");
  r(149,51,86,1,"#4020a0"); r(149,88,86,1,"#4020a0"); vline(149,51,38,"#4020a0"); vline(234,51,38,"#4020a0"); r(150,88,84,3,"#14102a");
  // Monitor 3 — comm
  r(278,54,80,32,"#080e1e"); r(279,55,78,30,"#050810");
  for(let wx=280;wx<356;wx+=4){const amp=Math.sin((wx-280)*0.3)*6;p(wx,Math.round(70+amp),"#6030c0");p(wx+1,Math.round(70+amp*0.5),"#4020a0");}
  hline(280,70,76,"#1a1040");
  r(280,57,8,4,"#2a1860"); r(280,57,3,4,"#8040ff"); r(292,57,8,4,"#2a1860"); r(292,57,3,4,"#4020a0"); r(304,57,8,4,"#2a1860"); r(304,57,3,4,"#6030c0");
  r(277,53,82,1,"#2a1460"); r(277,86,82,1,"#2a1460"); vline(277,53,34,"#2a1460"); vline(358,53,34,"#2a1460"); r(278,86,80,3,"#14102a");
  // Side screens
  r(19,100,40,60,"#080e1e");
  for(let sy=102;sy<158;sy+=10){r(21,sy,36,8,"#0c1228");r(21,sy,36,2,"#2a1460");r(21,sy,12,8,"#4020a0");r(21,sy,4,8,"#8040ff");}
  r(19,99,40,1,"#4020a0"); r(19,160,40,1,"#4020a0"); vline(59,99,62,"#4020a0");
  r(325,100,40,60,"#080e1e");
  for(let ty=0;ty<5;ty++){const ys=102+ty*11;r(327,ys,36,9,"#080e18");for(let ax=328;ax<362;ax+=3){const av=Math.sin((ax-328+ty*20)*0.15)*3;p(ax,Math.round(ys+4+av),"#6030c0");}}
  r(325,99,40,1,"#4020a0"); r(325,160,40,1,"#4020a0"); vline(325,99,62,"#4020a0");
  // Holo table
  r(110,155,164,8,"#1a103a"); r(112,148,160,8,"#120c2e"); r(114,149,156,6,"#0e0822");
  r(120,132,144,22,"#06060e"); r(121,133,142,20,"#0a0618"); r(122,134,140,18,"#0e0820");
  const tStars=[[130,138],[140,142],[152,136],[160,140],[170,144],[178,138],[185,142],[195,136],[200,140],[210,144],[220,138]];
  tStars.forEach(([sx,sy])=>p(sx,sy,"#a060ff"));
  r(175,139,6,6,"#6030c0"); r(176,140,4,4,"#8040e0"); p(177,141,"#c080ff"); p(178,141,"#ffffff");
  for(let gx=122;gx<262;gx+=14) vline(gx,134,18,"#2a1460");
  for(let gy=134;gy<152;gy+=6) hline(122,gy,140,"#2a1460");
  r(120,131,144,1,"#6030c0"); r(120,152,144,1,"#4020a0"); vline(120,131,22,"#4020a0"); vline(263,131,22,"#4020a0");
  vline(118,155,50,"#0e0820"); vline(269,155,50,"#0e0820"); r(116,203,6,2,"#14102a"); r(267,203,6,2,"#14102a");
  hline(114,154,156,"#6030c0"); hline(114,155,156,"#3a1e70");
  // Chair
  r(178,175,28,4,"#14102a"); r(179,174,26,2,"#1e1840"); r(180,166,26,10,"#0e0c1e"); r(181,167,24,8,"#141230"); r(181,167,24,2,"#2a2460");
  hline(181,174,24,"#4020a0"); vline(180,167,8,"#4020a0"); vline(205,167,8,"#4020a0");
  r(174,172,6,4,"#0e0c1e"); r(204,172,6,4,"#0e0c1e"); hline(174,171,6,"#2a2060"); hline(204,171,6,"#2a2060");
  vline(191,179,14,"#0a0818"); r(185,192,14,2,"#14102a");
  // Personal touches
  r(250,148,8,8,"#c8854a"); r(251,145,6,5,"#c8854a"); p(252,147,"#e8b080"); p(253,147,"#e8b080"); p(253,148,"#1a0a00");
  r(249,148,2,3,"#a06030"); r(257,148,2,3,"#a06030");
  r(130,148,8,6,"#2a2040"); r(131,149,6,4,"#604020"); r(131,149,6,2,"#c06020"); p(138,150,"#2a2040"); p(138,151,"#2a2040");
  // Floor strips
  hline(18,200,348,"#1e1040"); hline(18,201,348,"#2a1460"); hline(18,202,348,"#1e1040");
  hline(18,230,348,"#1e1040"); hline(18,231,348,"#2a1460"); hline(18,232,348,"#1e1040");
  // Door
  r(168,60,48,32,"#0c101e"); r(170,62,44,28,"#080c18"); r(170,62,2,28,"#6030c0"); r(212,62,2,28,"#4020a0");
  vline(191,62,28,"#2a1460"); vline(192,62,28,"#2a1460"); r(168,59,48,1,"#4020a0"); r(168,91,48,1,"#2a1460");

  return { tStars };
}

function drawSecurityRoom(ctx: CanvasRenderingContext2D, S: number) {
  const r = (x: number, y: number, w: number, h: number, col: string) => { ctx.fillStyle = col; ctx.fillRect(x*S, y*S, w*S, h*S); };
  const p = (x: number, y: number, col: string) => r(x, y, 1, 1, col);
  const hline = (x: number, y: number, w: number, col: string) => r(x, y, w, 1, col);
  const vline = (x: number, y: number, h: number, col: string) => r(x, y, 1, h, col);

  r(0,0,384,256,"#06060c");
  r(0,100,384,156,"#0a080e");
  for(let y=100;y<256;y+=10) hline(0,y,384,"#0e0c14");
  for(let x=0;x<384;x+=16) vline(x,100,156,"#0c0a12");
  hline(0,254,384,"#e040a0"); hline(0,253,384,"#801060"); hline(0,252,384,"#40082a");
  r(0,0,384,55,"#070610"); hline(0,10,384,"#801060"); hline(0,11,384,"#e040a0"); hline(0,12,384,"#801060");
  r(0,55,384,48,"#08060e"); hline(0,55,384,"#14101e"); hline(0,102,384,"#14101e");
  r(0,0,16,256,"#07060c"); vline(0,0,256,"#e040a0"); vline(1,0,256,"#601040");
  r(368,0,16,256,"#07060c"); vline(383,0,256,"#e040a0"); vline(382,0,256,"#601040");

  // 6 camera feeds
  const cams=[{x:18,y:58},{x:80,y:58},{x:142,y:58},{x:204,y:58},{x:266,y:58},{x:310,y:58}];
  const camCols=["#0e0818","#080e0e","#0e0808","#08080e","#0e0a08","#0a080e"];
  cams.forEach(({x,y},i)=>{
    r(x,y,56,34,camCols[i]); r(x+1,y+1,54,32,"#0a0612");
    for(let sy=y+2;sy<y+32;sy+=4) hline(x+2,sy,52,"#0e0c18");
    const cx2=x+28,cy2=y+17;
    hline(Math.round(cx2-6),Math.round(cy2),12,"#e040a040");
    vline(Math.round(cx2),Math.round(cy2-5),10,"#e040a040");
    r(Math.round(cx2-2),Math.round(cy2-2),4,4,"#e040a060");
    r(x,y,56,1,"#e040a0"); r(x,y+34,56,1,"#801060"); vline(x,y,34,"#801060"); vline(x+56,y,34,"#801060");
    r(x+2,y+2,2,2,"#ff0040");
  });

  // Radar
  r(20,108,70,70,"#04030c"); r(21,109,68,68,"#06040e");
  [28,20,12,5].forEach(rad=>{for(let a=0;a<360;a+=5){const ar=a*Math.PI/180;p(Math.round(55+rad*Math.cos(ar)),Math.round(143+rad*Math.sin(ar)),"#2a0e40");}});
  hline(21,143,68,"#1a0830"); vline(55,109,68,"#1a0830");
  p(42,130,"#ff60c0"); r(41,129,3,3,"#ff60c080"); p(68,138,"#ff60c0"); r(67,137,3,3,"#ff60c080"); p(58,118,"#ff60c0");
  r(20,107,70,1,"#e040a0"); r(20,178,70,1,"#601040"); vline(20,107,72,"#601040"); vline(89,107,72,"#601040");

  // Env bars
  r(100,108,50,20,"#06040e"); r(102,110,46,16,"#0a0614"); r(102,110,38,16,"#400880"); r(102,110,38,4,"#6010a0");
  r(100,107,50,1,"#e040a0"); r(100,128,50,1,"#601040"); vline(100,107,22,"#601040"); vline(149,107,22,"#601040");
  r(100,132,50,20,"#06040e"); r(102,134,46,16,"#0a0614"); r(102,134,42,16,"#400880"); r(102,134,42,4,"#8020b0");
  r(100,131,50,1,"#e040a0"); r(100,152,50,1,"#601040"); vline(100,131,22,"#601040"); vline(149,131,22,"#601040");
  r(100,156,50,20,"#06040e"); r(102,158,46,16,"#0a0614"); r(102,158,28,16,"#601040"); r(102,158,28,4,"#a02060");
  r(100,155,50,1,"#ff4060"); r(100,176,50,1,"#601040"); vline(100,155,22,"#601040"); vline(149,155,22,"#601040"); r(142,157,6,4,"#ff2040");

  // Central desk
  r(155,170,200,18,"#0c0a14"); r(153,185,204,12,"#08060e"); r(155,170,200,2,"#e040a0");
  vline(155,197,40,"#08060e"); vline(354,197,40,"#08060e"); r(152,235,6,2,"#0c0a14"); r(351,235,6,2,"#0c0a14");

  // Holo displays
  r(162,148,80,24,"#04030e"); r(163,149,78,22,"#06040e");
  for(let gx=164;gx<240;gx+=8) vline(gx,149,22,"#300828");
  for(let gy=150;gy<171;gy+=5) hline(164,gy,76,"#300828");
  r(164,150,20,10,"#180830"); r(164,150,20,3,"#601040"); hline(164,154,20,"#e040a060");
  r(188,150,30,10,"#180830"); r(190,152,26,6,"#300840"); hline(190,152,26,"#e040a0");
  r(168,162,12,6,"#400880"); r(168,162,12,1,"#e040a0"); r(202,162,16,6,"#400880"); r(202,162,16,1,"#ff60c0");
  r(162,147,80,1,"#e040a0"); r(162,172,80,1,"#601040"); vline(162,147,26,"#601040"); vline(241,147,26,"#601040");
  r(260,148,76,24,"#04030e"); r(261,149,74,22,"#06040e");
  for(let gy2=150;gy2<171;gy2+=3) hline(262,gy2,72,"#1a0828");
  for(let wx=262;wx<334;wx+=2){const wamp=Math.sin((wx-262)*0.2)*7+160;p(wx,Math.round(wamp),"#e040a0");}
  r(260,147,76,1,"#ff60c0"); r(260,172,76,1,"#601040"); vline(260,147,26,"#601040"); vline(335,147,26,"#601040");

  // Lockers
  r(330,108,36,68,"#0a0812"); r(330,108,36,2,"#e040a0");
  r(332,112,14,28,"#0e0a18"); r(332,112,14,4,"#200830"); r(348,112,14,28,"#0e0a18"); r(348,112,14,4,"#200830");
  r(332,142,14,30,"#0e0a18"); r(332,142,14,4,"#1a0828"); r(348,142,14,30,"#0e0a18"); r(348,142,14,4,"#1a0828");
  p(338,125,"#601040"); p(354,125,"#601040"); p(338,155,"#e040a0"); p(354,155,"#e040a0");
  vline(330,108,68,"#601040"); vline(365,108,68,"#601040"); vline(346,108,68,"#200828");
  r(330,140,36,1,"#200828"); r(330,175,36,1,"#601040"); r(331,110,4,2,"#e040a0");

  return { cams };
}

function drawWorkshopRoom(ctx: CanvasRenderingContext2D, S: number) {
  const r = (x: number, y: number, w: number, h: number, col: string) => { ctx.fillStyle = col; ctx.fillRect(x*S, y*S, w*S, h*S); };
  const p = (x: number, y: number, col: string) => r(x, y, 1, 1, col);
  const hline = (x: number, y: number, w: number, col: string) => r(x, y, w, 1, col);
  const vline = (x: number, y: number, h: number, col: string) => r(x, y, 1, h, col);

  r(0,95,384,161,"#161410");
  for(let y=95;y<256;y+=6) hline(0,y,384,"#1a1812");
  for(let x=0;x<384;x+=6) vline(x,95,161,"#1a1812");
  for(let gx=3;gx<384;gx+=6) for(let gy=98;gy<256;gy+=6) r(gx,gy,2,2,"#100e0a");
  hline(0,253,384,"#40d0e0"); hline(0,252,384,"#208090"); hline(0,251,384,"#104850");
  r(0,0,384,55,"#111008"); hline(0,10,384,"#208090"); hline(0,11,384,"#40d0e0"); hline(0,12,384,"#208090");
  r(40,0,8,55,"#1e1c16"); r(41,0,6,55,"#262420"); r(180,0,8,55,"#1e1c16"); r(181,0,6,55,"#262420"); r(310,0,8,55,"#1e1c16"); r(311,0,6,55,"#262420");
  hline(40,25,8,"#40d0e0"); hline(180,25,8,"#40d0e0"); hline(310,25,8,"#40d0e0");
  r(0,55,384,42,"#131108");
  for(let sx=0;sx<384;sx+=24) vline(sx,55,42,"#181610");
  hline(0,55,384,"#1e1c14"); hline(0,96,384,"#1e1c14");
  r(0,0,16,256,"#121008"); vline(0,0,256,"#40d0e0"); vline(1,0,256,"#205060");
  r(368,0,16,256,"#121008"); vline(383,0,256,"#40d0e0"); vline(382,0,256,"#205060");

  // Left workbench
  r(18,140,120,10,"#1e1c14"); r(18,149,120,4,"#181610"); hline(18,140,120,"#40d0e0");
  vline(22,153,50,"#141210"); vline(132,153,50,"#141210"); r(19,202,8,2,"#1a1814"); r(129,202,8,2,"#1a1814");
  r(24,132,3,9,"#606060"); r(24,128,3,5,"#c0a060");
  r(30,130,4,12,"#808080"); r(29,128,6,4,"#909090");
  r(38,134,16,8,"#204020"); r(39,135,14,6,"#2a5428");
  r(58,132,22,10,"#303028"); r(59,133,20,8,"#383630");
  r(60,134,4,4,"#40d0e0"); r(66,134,4,4,"#208090");
  for(let wy=0;wy<5;wy++) hline(84,133+wy,22,wy%2?"#c04020":"#a06040");
  r(84,132,22,1,"#606040");

  // Right workbench
  r(248,140,118,10,"#1e1c14"); r(248,149,118,4,"#181610"); hline(248,140,118,"#40d0e0");
  vline(252,153,50,"#141210"); vline(360,153,50,"#141210"); r(249,202,8,2,"#1a1814"); r(357,202,8,2,"#1a1814");
  r(252,126,30,16,"#1a1814"); r(253,127,28,14,"#222018");
  r(255,120,2,14,"#606060"); r(256,118,2,4,"#a08040");
  p(256,119,"#ffffff"); p(257,119,"#ffff80");
  p(258,117,"#ffffff"); p(259,116,"#ffff80"); p(260,117,"#ff8000"); p(257,115,"#ffff80"); p(256,114,"#ff8000");
  r(260,128,8,8,"#404040"); r(261,129,6,6,"#282018");
  r(268,120,16,3,"#303028"); r(282,115,4,10,"#303028"); r(280,113,8,8,"#202820"); r(281,114,6,6,"#204028"); r(282,115,4,4,"#40c0a080");

  // 3D Printer
  r(340,105,36,38,"#181614"); r(341,106,34,36,"#201e18"); r(342,107,32,4,"#282620"); hline(342,107,32,"#40d0e0");
  r(343,120,30,8,"#282620"); hline(343,120,30,"#40d0e0");
  r(351,112,14,9,"#303028"); r(352,113,12,7,"#383630"); r(354,109,8,5,"#40d0e0"); r(355,108,6,3,"#80e8f0"); p(357,107,"#c0f8ff");
  vline(343,107,34,"#303028"); vline(371,107,34,"#303028"); r(342,111,4,2,"#40d0e0"); r(340,141,36,2,"#282620"); hline(340,141,36,"#40d0e0");

  // Wall shelves
  r(18,100,46,4,"#1a1812"); hline(18,100,46,"#40d0e0");
  r(20,95,6,6,"#404040"); r(20,95,6,2,"#606060"); r(28,93,4,8,"#606040"); r(28,93,4,2,"#808060");
  r(34,95,5,6,"#204040"); hline(34,95,5,"#40d0e0"); r(41,94,8,7,"#282618"); r(42,95,6,5,"#343228");
  r(50,96,10,5,"#404838"); hline(50,96,10,"#40d0e0"); r(62,97,6,4,"#303028");
  r(18,118,40,4,"#1a1812"); hline(18,118,40,"#40d0e0");
  r(20,112,8,7,"#202830"); hline(20,112,8,"#40d0e0"); r(30,113,6,6,"#303028"); r(36,114,8,5,"#282018"); r(46,111,8,8,"#204040"); r(46,111,8,3,"#40d0e0");

  // Holo blueprint table
  r(140,155,110,12,"#181610"); r(138,165,114,6,"#141210"); hline(140,155,110,"#40d0e0"); hline(138,170,114,"#101010");
  vline(142,170,40,"#141210"); vline(244,170,40,"#141210"); r(139,209,8,2,"#1a1814"); r(241,209,8,2,"#1a1814");
  r(144,125,104,32,"#02050a"); r(145,126,102,30,"#040810");
  for(let bx=146;bx<246;bx+=10) vline(bx,126,30,"#0a2830");
  for(let by=127;by<156;by+=8) hline(146,by,100,"#0a2830");
  r(150,128,30,20,"#082028"); r(150,128,30,1,"#40d0e0"); r(150,128,1,20,"#40d0e0"); r(179,128,1,20,"#40d0e0"); r(150,147,30,1,"#40d0e0");
  r(158,132,14,12,"#0c2a38"); r(158,132,14,1,"#80e8f0"); r(158,132,1,12,"#80e8f0"); r(171,132,1,12,"#80e8f0"); r(158,143,14,1,"#80e8f0");
  hline(184,134,30,"#208090"); p(184,133,"#208090"); p(184,135,"#208090"); p(213,133,"#208090"); p(213,135,"#208090"); vline(220,128,20,"#208090");
  r(186,127,58,14,"#051828"); r(187,128,56,12,"#07202e");
  for(let cx=188;cx<242;cx+=6) vline(cx,128,12,"#0c2a38");
  hline(188,134,54,"#40d0e060");
  r(144,124,104,1,"#40d0e0"); r(144,156,104,1,"#208090"); vline(144,124,33,"#208090"); vline(247,124,33,"#208090");

  return { sparkX: 256, sparkY: 119 };
}

function drawArchiveRoom(ctx: CanvasRenderingContext2D, S: number) {
  const r = (x: number, y: number, w: number, h: number, col: string) => { ctx.fillStyle = col; ctx.fillRect(x*S, y*S, w*S, h*S); };
  const p = (x: number, y: number, col: string) => r(x, y, 1, 1, col);
  const hline = (x: number, y: number, w: number, col: string) => r(x, y, w, 1, col);
  const vline = (x: number, y: number, h: number, col: string) => r(x, y, 1, h, col);

  r(0,100,384,156,"#120d08");
  for(let y=100;y<256;y+=8){hline(0,y,384,"#161008");if(y%16===0)hline(0,y,384,"#18120a");}
  for(let x=0;x<384;x+=32) vline(x,100,156,"#0e0a06");
  hline(0,254,384,"#e0a020"); hline(0,253,384,"#806010"); hline(0,252,384,"#402e08");
  r(0,0,384,60,"#0e0904");
  hline(0,15,384,"#604010"); hline(0,16,384,"#806020"); hline(0,17,384,"#604010");
  r(0,60,384,42,"#0e0a05"); hline(0,60,384,"#1e1608"); hline(0,100,384,"#181008");
  for(let px2=0;px2<384;px2+=32) vline(px2,60,42,"#140e06");
  r(0,0,16,256,"#0c0804"); vline(0,0,256,"#e0a020"); vline(1,0,256,"#604010");
  r(368,0,16,256,"#0c0804"); vline(383,0,256,"#e0a020"); vline(382,0,256,"#604010");

  // Data crystal shelves
  r(18,60,350,42,"#0e0a05"); hline(18,63,350,"#2a1e08"); hline(18,64,350,"#3a2a10");
  const bookCols=["#4a2010","#3a1e40","#2a3040","#402808","#1a3028","#3a2820","#402010","#2a1830"];
  for(let bk=0;bk<22;bk++){
    const bx=20+bk*16; const bh=6+Math.floor(Math.random()*6); const bc=bookCols[bk%bookCols.length];
    r(bx,65-bh,14,bh,bc); hline(bx,65-bh,14,"#604010");
    if(bk%3===0){r(bx+5,65-bh+1,4,4,"#e0a020");r(bx+6,65-bh+2,2,2,"#fff080");}
    else if(bk%3===1){r(bx+5,65-bh+1,4,4,"#a06010");}
  }

  // Left data column
  r(18,65,46,170,"#0e0a04"); r(19,66,44,168,"#120c06");
  for(let seg=0;seg<8;seg++){
    const sy=68+seg*20; r(21,sy,40,18,"#1a1208"); r(21,sy,40,2,"#3a2810");
    for(let cs=0;cs<5;cs++){const cx2=23+cs*8;r(cx2,sy+4,6,10,"#0e0c04");r(cx2+1,sy+5,4,8,"#e0a02060");r(cx2+2,sy+6,2,6,"#f0c040");p(cx2+2,sy+6,"#fff0a0");}
    hline(21,sy+18,40,"#2a1e08");
  }
  vline(18,65,170,"#e0a020"); vline(63,65,170,"#604010");

  // Right data column
  r(320,65,46,170,"#0e0a04"); r(321,66,44,168,"#120c06");
  for(let seg=0;seg<8;seg++){
    const sy=68+seg*20; r(323,sy,40,18,"#1a1208"); r(323,sy,40,2,"#3a2810");
    for(let cs=0;cs<5;cs++){const cx2=325+cs*8;r(cx2,sy+4,6,10,"#0e0c04");r(cx2+1,sy+5,4,8,"#c08010a0");r(cx2+2,sy+6,2,6,"#e09030");p(cx2+2,sy+6,"#fff0a0");}
    hline(323,sy+18,40,"#2a1e08");
  }
  vline(320,65,170,"#604010"); vline(365,65,170,"#e0a020");

  // Reading desk
  r(120,175,144,12,"#2a1e0a"); r(118,185,148,8,"#221808"); hline(120,175,144,"#e0a020"); hline(118,192,148,"#181008");
  vline(124,193,40,"#1a1208"); vline(258,193,40,"#1a1208"); r(120,232,10,2,"#221808"); r(254,232,10,2,"#221808");

  // Holo display
  r(130,138,124,38,"#06040a"); r(131,139,122,36,"#08050c"); r(132,140,120,34,"#07050a");
  const archStars=[[140,145],[148,142],[158,148],[168,144],[178,150],[188,146],[198,152],[208,148],[218,142],[228,146],[238,150],[246,144],[144,154],[154,158],[164,152],[174,156],[184,150],[194,158],[204,154],[214,148],[224,156],[234,152]];
  archStars.forEach(([sx,sy])=>p(sx,sy,"#e0a020"));
  hline(140,145,28,"#604010"); hline(168,144,30,"#604010"); vline(140,145,9,"#604010"); vline(198,144,8,"#604010"); hline(140,154,14,"#604010");
  for(let tl=0;tl<4;tl++) hline(133,162+tl*3,118,"#e0a02040");
  hline(133,162,60,"#e0a020"); hline(133,165,40,"#c08010"); hline(133,168,80,"#e0a020"); hline(133,171,50,"#c08010");
  r(130,137,124,1,"#e0a020"); r(130,175,124,1,"#806010"); vline(130,137,39,"#806010"); vline(253,137,39,"#806010");
  r(130,137,4,4,"#f0c040"); r(249,137,4,4,"#f0c040"); r(130,172,4,4,"#c08010"); r(249,172,4,4,"#c08010");

  // Lanterns
  r(68,105,14,18,"#2a1a04"); r(69,106,12,16,"#382208"); r(70,107,10,14,"#e0a02060"); r(71,108,8,12,"#f0c040"); r(72,109,6,10,"#fff0a0");
  r(68,104,14,2,"#604010"); r(68,122,14,2,"#604010"); vline(68,104,20,"#604010"); vline(81,104,20,"#604010"); r(64,100,22,30,"#e0a02008"); vline(74,90,15,"#604010"); p(74,88,"#806020");
  r(302,108,14,18,"#2a1a04"); r(303,109,12,16,"#382208"); r(304,110,10,14,"#e0a02060"); r(305,111,8,12,"#f0c040"); r(306,112,6,10,"#fff0a0");
  r(302,107,14,2,"#604010"); r(302,125,14,2,"#604010"); vline(302,107,20,"#604010"); vline(315,107,20,"#604010"); r(298,103,22,30,"#e0a02008"); vline(308,93,15,"#604010"); p(308,91,"#806020");
  r(186,92,14,20,"#2a1a04"); r(187,93,12,18,"#382208"); r(188,94,10,16,"#e0a02080"); r(189,95,8,14,"#f0c040"); r(190,96,6,12,"#fff0a0");
  r(186,91,14,2,"#604010"); r(186,111,14,2,"#604010"); vline(186,91,22,"#604010"); vline(199,91,22,"#604010"); r(182,86,22,34,"#e0a02010"); vline(192,76,16,"#604010"); p(192,74,"#806020");

  // Reading nook chair
  r(318,152,44,62,"#1a1008"); r(320,153,40,60,"#221408"); r(322,154,36,20,"#2a1a0a"); r(323,155,34,18,"#342010"); hline(322,154,36,"#604010");
  r(320,172,42,12,"#2a1a0a"); r(321,173,40,10,"#342010");
  r(316,168,6,8,"#1e1208"); r(362,168,6,8,"#1e1208"); hline(316,167,6,"#604010"); hline(362,167,6,"#604010");
  r(318,152,44,1,"#e0a020"); vline(318,152,62,"#604010"); vline(361,152,62,"#604010"); hline(318,214,44,"#604010");
  hline(323,162,34,"#3a2210"); hline(322,168,36,"#2a1a08");
  r(318,213,44,4,"#1a1208"); r(326,216,10,16,"#141008"); r(348,216,10,16,"#141008");
  r(316,163,8,10,"#4a2810"); r(317,164,6,8,"#6a3820"); r(317,164,6,2,"#e0a020"); hline(317,168,6,"#c08010");
  r(362,168,10,6,"#e0a020"); r(363,169,8,4,"#f0c040"); r(364,170,6,2,"#fff0a0");

  // Light beams
  r(188,112,10,80,"#f0c04006"); r(190,112,6,80,"#f0c04010"); r(192,112,2,80,"#f0c04018");
  r(70,123,14,100,"#e0a02006"); r(72,123,10,100,"#e0a0200c"); r(74,123,6,100,"#e0a02010");
  r(304,126,10,100,"#e0a02006"); r(306,126,6,100,"#e0a0200c");

  return {};
}

export function RoomCanvas({ room, className }: RoomCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animRef = useRef<ReturnType<typeof setInterval>[]>([]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const W = 768, H = 512, S = 2;
    ctx.imageSmoothingEnabled = false;

    // Clear previous animations
    animRef.current.forEach(id => clearInterval(id));
    animRef.current = [];

    // Draw the static room
    let animData: Record<string, unknown> = {};
    switch (room) {
      case "command": animData = drawCommandRoom(ctx, S); break;
      case "security": animData = drawSecurityRoom(ctx, S); break;
      case "workshop": animData = drawWorkshopRoom(ctx, S); break;
      case "archive": animData = drawArchiveRoom(ctx, S); break;
    }

    // Add room-specific animations
    if (room === "command") {
      const tStars = animData.tStars as number[][];
      // Holo table glow pulse
      const glowColors = ["#2a1460","#3a1e80","#4020a0","#3a1e80"];
      let glowState = 0;
      animRef.current.push(setInterval(() => {
        glowState = (glowState + 1) % 4;
        ctx.fillStyle = glowColors[glowState];
        ctx.fillRect(120*S, 131*S, 144*S, S);
        ctx.fillStyle = glowColors[(glowState + 2) % 4];
        ctx.fillRect(120*S, 152*S, 144*S, S);
      }, 300));
      // Star twinkle
      animRef.current.push(setInterval(() => {
        tStars.slice(0, 5).forEach(([sx, sy]) => {
          ctx.fillStyle = Math.random() > 0.5 ? "#c080ff" : "#6030b0";
          ctx.fillRect(sx*S, sy*S, S, S);
        });
      }, 400));
      // Blinking indicators
      let blinkOn = true;
      animRef.current.push(setInterval(() => {
        blinkOn = !blinkOn;
        ctx.fillStyle = blinkOn ? "#ff4040" : "#400000";
        ctx.fillRect(354*S, 57*S, S, S);
        ctx.fillStyle = blinkOn ? "#ff8040" : "#402000";
        ctx.fillRect(354*S, 62*S, S, S);
      }, 800));
    }

    if (room === "security") {
      const cams = animData.cams as {x: number, y: number}[];
      // Camera blink
      let camOn = true;
      animRef.current.push(setInterval(() => {
        camOn = !camOn;
        cams.forEach(({x, y}) => {
          ctx.fillStyle = camOn ? "#ff0040" : "#300010";
          ctx.fillRect((x+2)*S, (y+2)*S, 2*S, 2*S);
        });
      }, 900));
      // Warning flash
      let warnOn = true;
      animRef.current.push(setInterval(() => {
        warnOn = !warnOn;
        ctx.fillStyle = warnOn ? "#ff2040" : "#400010";
        ctx.fillRect(142*S, 157*S, 6*S, 4*S);
      }, 600));
      // Radar sweep
      let sweepAngle = 0;
      animRef.current.push(setInterval(() => {
        // Redraw radar background
        ctx.fillStyle = "#06040e";
        ctx.fillRect(21*S, 109*S, 68*S, 68*S);
        // Circles
        [28,20,12,5].forEach(rad => {
          for (let a = 0; a < 360; a += 6) {
            const ar = a * Math.PI / 180;
            ctx.fillStyle = "#2a0e40";
            ctx.fillRect((55+rad*Math.cos(ar))*S, (143+rad*Math.sin(ar))*S, S, S);
          }
        });
        ctx.fillStyle = "#1a0830";
        ctx.fillRect(21*S, 143*S, 68*S, S);
        ctx.fillRect(55*S, 109*S, S, 68*S);
        // Sweep
        sweepAngle = (sweepAngle + 15) % 360;
        const ar = sweepAngle * Math.PI / 180;
        for (let d = 0; d < 28; d++) {
          const fade = (1 - d/28) * 0.8;
          ctx.fillStyle = `rgba(224,64,160,${fade})`;
          ctx.fillRect((55+d*Math.cos(ar))*S, (143+d*Math.sin(ar))*S, S, S);
        }
        // Blips
        ctx.fillStyle = "#ff60c0";
        ctx.fillRect(42*S, 130*S, S, S); ctx.fillRect(68*S, 138*S, S, S); ctx.fillRect(58*S, 118*S, S, S);
      }, 120));
    }

    if (room === "workshop") {
      // Spark animation
      let sparkFrame = 0;
      animRef.current.push(setInterval(() => {
        sparkFrame = (sparkFrame + 1) % 3;
        ctx.fillStyle = "#222018";
        ctx.fillRect(254*S, 113*S, 12*S, 8*S);
        const sparks = [
          [[258,117,"#ffffff"],[259,116,"#ffff80"],[260,117,"#ff8000"],[257,115,"#ffff80"]],
          [[257,116,"#ffffff"],[258,115,"#ffff80"],[261,116,"#ff8000"],[259,114,"#ffff80"],[256,117,"#ff4000"]],
          [[259,117,"#ffffff"],[258,115,"#ffff80"],[260,115,"#ff8000"],[257,116,"#ff4000"]],
        ];
        sparks[sparkFrame].forEach(([sx, sy, col]) => {
          ctx.fillStyle = col as string;
          ctx.fillRect((sx as number)*S, (sy as number)*S, S, S);
        });
        // Tip always glows
        ctx.fillStyle = "#ffffff"; ctx.fillRect(256*S, 119*S, S, S);
        ctx.fillStyle = "#ffff80"; ctx.fillRect(257*S, 119*S, S, S);
      }, 200));
      // Blueprint pulse
      let bpOn = true;
      animRef.current.push(setInterval(() => {
        bpOn = !bpOn;
        ctx.fillStyle = bpOn ? "#40d0e0" : "#208090";
        ctx.fillRect(144*S, 124*S, 104*S, S);
        ctx.fillStyle = bpOn ? "#208090" : "#104848";
        ctx.fillRect(144*S, 156*S, 104*S, S);
      }, 700));
      // Printer LED
      let ledOn = true;
      animRef.current.push(setInterval(() => {
        ledOn = !ledOn;
        ctx.fillStyle = ledOn ? "#40d0e0" : "#104848";
        ctx.fillRect(342*S, 111*S, 4*S, 2*S);
      }, 500));
    }

    if (room === "archive") {
      // Lantern flicker
      let flickerA = 0;
      const brightnesses = ["#fff0a0","#f8e090","#ffe880","#fff8b0"];
      animRef.current.push(setInterval(() => {
        flickerA = (flickerA + 1) % 4;
        const br = brightnesses[flickerA];
        ctx.fillStyle = br; ctx.fillRect(72*S, 109*S, 6*S, 10*S);
        ctx.fillStyle = br; ctx.fillRect(190*S, 96*S, 6*S, 12*S);
        ctx.fillStyle = br; ctx.fillRect(306*S, 112*S, 6*S, 10*S);
      }, 180));
      // Scrolling text
      let scrollOff = 0;
      animRef.current.push(setInterval(() => {
        scrollOff = (scrollOff + 1) % 4;
        ctx.fillStyle = "#07050a";
        ctx.fillRect(133*S, 162*S, 118*S, 14*S);
        for (let tl = 0; tl < 4; tl++) {
          ctx.fillStyle = "#e0a02040";
          ctx.fillRect(133*S, (162+((tl+scrollOff)%4)*3)*S, 118*S, S);
        }
        ctx.fillStyle = "#e0a020"; ctx.fillRect(133*S, (162+(scrollOff%4)*3)*S, 60*S, S);
        ctx.fillStyle = "#c08010"; ctx.fillRect(133*S, (162+((scrollOff+2)%4)*3)*S, 80*S, S);
      }, 600));
    }

    return () => {
      animRef.current.forEach(id => clearInterval(id));
      animRef.current = [];
    };
  }, [room]);

  return (
    <canvas
      ref={canvasRef}
      width={768}
      height={512}
      className={className}
      style={{ imageRendering: "pixelated", width: "100%", height: "auto" }}
    />
  );
}
