// src/components/AgentOffice.tsx
// Main Agent Office orchestrator — the living, animated station view
// Continuous floorplan, animated agents, status bubbles, walking movement

import { useEffect, useState, useCallback, useReducer, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { StationRoom } from "./StationRoom";
import { TaskFlowSignals } from "./TaskFlowSignals";
import { AmbientStation } from "./AmbientStation";
import { AgentTravel } from "./AgentTravel";
import { StationFloorplan } from "./StationFloorplan";
import { stationReducer, createInitialStationState, type StationState, type AgentActivity } from "@/lib/station-state";
import { useLiveStationData } from "@/lib/live-data";
import type { SystemStats } from "@/lib/server-data-types";
import { CREW } from "@/lib/crew";
import { getRandomChatter } from "@/lib/delights";

const ROOMS = [
  {
    id: "command",
    label: "COMMAND HQ",
    occupantId: "monkey",
    accent: "#6030c0",
    accentHue: 270,
    agentPos: { xPct: 50, yPct: 65 },
    monitors: [
      { xPct: 15, yPct: 15, w: 20, h: 15, label: "orbital" },
      { xPct: 40, yPct: 12, w: 22, h: 18, label: "starmap" },
      { xPct: 68, yPct: 15, w: 18, h: 15, label: "comms" },
    ],
  },
  {
    id: "security",
    label: "SECURITY DECK",
    occupantId: "lifesupport",
    accent: "#e040a0",
    accentHue: 320,
    agentPos: { xPct: 50, yPct: 60 },
    monitors: [
      { xPct: 10, yPct: 12, w: 60, h: 20, label: "cameras" },
    ],
  },
  {
    id: "workshop",
    label: "WORKSHOP",
    occupantId: "engineer",
    accent: "#40d0e0",
    accentHue: 190,
    agentPos: { xPct: 55, yPct: 62 },
    monitors: [
      { xPct: 15, yPct: 10, w: 25, h: 15, label: "blueprint" },
    ],
  },
  {
    id: "archive",
    label: "ARCHIVE",
    occupantId: "archivist",
    accent: "#e0a020",
    accentHue: 45,
    agentPos: { xPct: 50, yPct: 58 },
    monitors: [
      { xPct: 30, yPct: 10, w: 40, h: 20, label: "holodisplay" },
    ],
  },
];

const SPRITES: Record<string, Record<string, string>> = {};
// Sprites loaded dynamically from crew data

// Default status phrases per agent (idle state)
const DEFAULT_PHRASES: Record<string, string> = {
  monkey: "Waiting for orders…",
  lifesupport: "Standing by…",
  engineer: "Idle — no builds queued",
  archivist: "Indexing memory sectors…",
};

interface AgentOfficeProps {
  initialAgents?: Array<{id:string;name:string;status:string;tasksActive:number;currentAction?:string}>;
  initialStats?: SystemStats;
  initialIncidents?: Array<{id:string;severity:string;status:string;title:string}>;
}

export function AgentOffice({ initialAgents, initialStats, initialIncidents }: AgentOfficeProps) {
  const [state, dispatch] = useReducer(stationReducer, createInitialStationState());
  const liveData = useLiveStationData();

  // Seed initial data from server loader
  useEffect(() => {
    if (initialAgents) {
      initialAgents.forEach(agent => {
        const activity: AgentActivity = agent.status === "active" && agent.tasksActive > 0 ? "working" : "idle";
        dispatch({ type: "SET_AGENT_ACTIVITY", agentId: agent.id, activity });
      });
    }
  }, []);
  // Always live — no toggle
  const [nowRunning, setNowRunning] = useState<string[]>([]);
  const [upNext, setUpNext] = useState<string[]>([]);
  const [chatter, setChatter] = useState("");
  const [celebrating, setCelebrating] = useState(false);
  const prevActiveTaskTotal = useRef<number | null>(null);
  // Always live mode — no ambient timer needed

  // Load sprites from crew (outside useEffect so SSR gets the values)
  CREW.forEach(c => {
    SPRITES[c.id] = { idle: c.sprites.idle, working: c.sprites.working, walking: c.sprites.walking, away: c.sprites.idle };
  });

  // Live data is always used directly

  // Dispatch live data updates (but don't override seeded initial data on first render)
  const initialDataSeeded = useRef(false);
  useEffect(() => {
    if (!initialDataSeeded.current) {
      initialDataSeeded.current = true;
      return; // Skip first render — initial data already seeded
    }
    liveData.agents.forEach(agent => {
      const activity: AgentActivity = agent.status === "working" ? "working" : agent.status === "collaborating" ? "collaborating" : agent.status === "idle" ? "idle" : "idle";
      dispatch({ type: "SET_AGENT_ACTIVITY", agentId: agent.id, activity });
    });
    dispatch({ type: "SET_MOOD", mood: liveData.stationMood });
    dispatch({ type: "SET_ALERT", level: liveData.alertLevel });
  }, [liveData]);

  // No ambient mode — always use live data

  // Update running/up-next + celebration trigger on task-count transition to 0
  useEffect(() => {
    const running = liveData.agents
      .filter(a => a.status === "working" || a.status === "collaborating")
      .map(a => `${a.name}: ${a.currentAction || "Active"}`);
    setNowRunning(running.length > 0 ? running : ["All systems nominal — standing by"]);
    setUpNext(["Memory consolidation", "Wiki lint check", "Git auto-commit"]);

    // Celebration: previously had active tasks, now zero
    const activeTotal = liveData.agents.reduce((sum, a) => sum + (a.tasksActive || 0), 0);
    if (
      prevActiveTaskTotal.current !== null &&
      prevActiveTaskTotal.current > 0 &&
      activeTotal === 0 &&
      liveData.agents.length > 0
    ) {
      setCelebrating(true);
      const timer = setTimeout(() => setCelebrating(false), 3200);
      prevActiveTaskTotal.current = activeTotal;
      return () => clearTimeout(timer);
    }
    if (liveData.agents.length > 0) prevActiveTaskTotal.current = activeTotal;
  }, [liveData]);

  // Station chatter
  useEffect(() => {
    setChatter(getRandomChatter());
    const interval = setInterval(() => setChatter(getRandomChatter()), 8000);
    return () => clearInterval(interval);
  }, []);

  // Collaboration data for AgentTravel
  const collaborations = liveData.agents
    .filter(a => a.status === "collaborating")
    .map((a, i) => ({
      id: `collab-${a.id}-${i}`,
      agents: [a.id, "monkey"] as [string, string],
      fromRoom: a.id === "monkey" ? "command" : a.id === "lifesupport" ? "security" : a.id === "engineer" ? "workshop" : "archive",
      toRoom: "command",
      sprite: SPRITES[a.id]?.walking || SPRITES[a.id]?.idle || "",
    }));

  const moodColors: Record<string, string> = {
    calm: "text-[oklch(0.88_0.18_145)]",
    busy: "text-violet",
    alert: "text-warning",
    critical: "text-destructive",
  };

  // ── TEST MODE: Force visible animations for verification ──
  const TEST_MODE = false;
  const _testTimeStr = TEST_MODE ? new Date().toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit", second: "2-digit" }) : "";
  const _testActivityOverride: Record<string, AgentActivity> = TEST_MODE
    ? { monkey: "working", engineer: "walking", lifesupport: "idle", archivist: "idle" }
    : {};
  const _testStatusOverride: Record<string, string> = TEST_MODE
    ? {
        monkey: `🔧 TEST: Animation check ${_testTimeStr}`,
        engineer: "Walking to Command HQ…",
        lifesupport: "Standing by…",
        archivist: "Indexing memory sectors…",
      }
    : {};
  const _testWalking: Record<string, { isWalking: boolean; walkFromPos: { xPct: number; yPct: number } | null }> = TEST_MODE
    ? { engineer: { isWalking: true, walkFromPos: { xPct: 55, yPct: 62 } } }
    : {};

  return (
    <div className="w-full">
      {/* Living station — continuous 2x2 floorplan */}
      <AmbientStation mood={state.mood} celebrating={celebrating}>
        <StationFloorplan>
          {ROOMS.map(room => {
            // Use initial agents from server loader for accurate first render
            const initialAgent = initialAgents?.find(a => a.id === room.occupantId);
            const liveAgent = liveData.agents.find(a => a.id === room.occupantId);
            const agentData = initialAgent || liveAgent;
            const agentStatus = agentData?.status || "idle";
            // Map status to activity: active+has tasks=working, active+no tasks=idle
            const derivedActivity: AgentActivity = _testActivityOverride[room.occupantId] || (agentStatus === "active" && agentData && agentData.tasksActive > 0 ? "working" : "idle");
            const activity = derivedActivity;
            const sprite = SPRITES[room.occupantId]?.[activity] || SPRITES[room.occupantId]?.idle;
            const crew = CREW.find(c => c.id === room.occupantId);
            const isSleeping = activity === "away";
            const isCollaborating = activity === "collaborating";
            // Use real task title from server data
            const currentTaskName = agentData?.currentAction;
            const lastActivityMin = liveAgent ? Math.floor((Date.now() - (liveData.lastUpdated || Date.now())) / 60000) : undefined;

            // Test overrides
            const _walkOverride = _testWalking[room.occupantId];
            const _statusOverride = _testStatusOverride[room.occupantId];

            // Collaboration: find the other collaborating agent
            const collabPartner = isCollaborating
              ? liveData.agents.find(a => a.id !== room.occupantId && a.status === "collaborating")
              : null;
            const hasCollaborator = !!collabPartner;
            const collaboratorPos = hasCollaborator ? {
              xPct: room.agentPos.xPct + 12,
              yPct: room.agentPos.yPct - 5,
            } : null;

            return (
              <StationRoom
                key={room.id}
                roomId={room.id}
                label={room.label}
                bgImage=""
                accent={room.accent}
                accentHue={room.accentHue}
                agentId={room.occupantId}
                agentName={crew?.name || room.occupantId}
                agentRole={crew?.shortRole || ""}
                agentSprite={sprite}
                agentActivity={activity}
                agentPos={room.agentPos}
                monitors={room.monitors}
                isAlertActive={state.alertLevel === "critical" || state.alertLevel === "warning"}
                useCanvas={true}
                statusText={_statusOverride || DEFAULT_PHRASES[room.occupantId] || "Monitoring…"}
                currentTaskName={_statusOverride || currentTaskName}
                lastActivityMinutes={lastActivityMin}
                isSleeping={isSleeping}
                isWalking={_walkOverride?.isWalking || false}
                walkFromPos={_walkOverride?.walkFromPos || null}
                hasCollaborator={hasCollaborator}
                collaboratorPos={collaboratorPos}
                sharedTaskName={isCollaborating ? currentTaskName : undefined}
              />
            );
          })}
        </StationFloorplan>
      </AmbientStation>

      {/* Agent travel visualization */}
      {collaborations.length > 0 && (
        <AgentTravel
          collaborations={collaborations}
          roomPositions={{
            command: { x: 25, y: 25 },
            security: { x: 75, y: 25 },
            workshop: { x: 25, y: 75 },
            archive: { x: 75, y: 75 },
          }}
          isVisible={true}
        />
      )}

      {/* Task flow signals */}
      <TaskFlowSignals packets={state.taskQueue} />

      {/* Status panels */}
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        <div className="rounded-xl border border-border bg-card/30 p-4">
          <div className="font-mono text-[10px] tracking-[0.2em] text-muted-foreground mb-3">NOW RUNNING</div>
          <div className="space-y-2">
            {nowRunning.map((item) => (
              <motion.div key={item} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }}
                className="flex items-center gap-2 text-sm">
                <span className="h-1.5 w-1.5 rounded-full bg-violet animate-pulse" />
                <span>{item}</span>
              </motion.div>
            ))}
          </div>
        </div>
        <div className="rounded-xl border border-border bg-card/30 p-4">
          <div className="font-mono text-[10px] tracking-[0.2em] text-muted-foreground mb-3">UP NEXT</div>
          <div className="space-y-2">
            {upNext.map((item) => (
              <div key={item} className="flex items-center gap-2 text-sm text-muted-foreground">
                <span className="h-1.5 w-1.5 rounded-full bg-muted-foreground/40" />
                <span>{item}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="rounded-xl border border-border bg-card/30 p-4">
          <div className="font-mono text-[10px] tracking-[0.2em] text-muted-foreground mb-3">STATION SERVICES</div>
          <div className="flex flex-wrap gap-1.5">
            {[
              { label: "GATEWAY", ok: true },
              { label: "CRON", ok: liveData.activeCrons > 0 },
              { label: "TELEGRAM", ok: true },
              { label: "MEMORY", ok: true },
              { label: "WIKI", ok: true },
            ].map(s => (
              <span key={s.label}
                className={`inline-flex items-center gap-1 rounded-full border px-2 py-0.5 font-mono text-[8px] tracking-wider ${
                  s.ok
                    ? "border-[oklch(0.30_0.04_265)] bg-[oklch(0.82_0.21_145)]/10 text-[oklch(0.88_0.18_145)]"
                    : "border-destructive/30 bg-destructive/10 text-destructive"
                }`}>
                <span className={`h-1.5 w-1.5 rounded-full ${s.ok ? "bg-[oklch(0.88_0.18_145)]" : "bg-destructive"}`} />
                {s.label}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Queue pressure */}
      <div className="rounded-xl border border-border bg-card/30 p-4">
        <div className="flex items-center justify-between mb-2">
          <div className="font-mono text-[10px] tracking-[0.2em] text-muted-foreground">QUEUE PRESSURE</div>
          <div className="font-mono text-[10px]">{state.queuePressure}%</div>
        </div>
        <div className="h-2 rounded-full bg-background overflow-hidden">
          <motion.div
            className={`h-full rounded-full ${
              state.queuePressure > 70 ? "bg-destructive" :
              state.queuePressure > 40 ? "bg-warning" :
              "bg-[oklch(0.88_0.18_145)]"
            }`}
            animate={{ width: `${state.queuePressure}%` }}
            transition={{ duration: 0.5 }}
          />
        </div>
      </div>

      {/* Station chatter */}
      <AnimatePresence mode="wait">
        <motion.div key={chatter}
          initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -4 }}
          transition={{ duration: 0.4 }}
          className="font-mono text-[8px] text-muted-foreground/40 tracking-wider text-center">
          {chatter}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
