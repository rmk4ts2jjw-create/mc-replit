import { useState, useEffect } from "react";
import { CREW } from "@/lib/crew";
import type { Incident, IncidentAction, IncidentEvent } from "@/lib/server-data-types";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Pill } from "@/components/PageHeader";
import {
  AlertTriangle,
  CheckCircle2,
  Clock,
  Flame,
  Minus,
  Play,
  SkipForward,
  Tag,
  User,
} from "lucide-react";
import type { ReactNode } from "react";

// ── Status config ────────────────────────────────────────────────────────────

const STATUS_CONFIG: Record<
  Incident["status"],
  { label: string; color: string; dot: string; icon: ReactNode }
> = {
  TRIAGE: {
    label: "TRIAGE",
    color: "text-warning",
    dot: "bg-warning",
    icon: <AlertTriangle className="h-4 w-4 text-warning" />,
  },
  MITIGATING: {
    label: "MITIGATING",
    color: "text-cyan-400",
    dot: "bg-cyan-400",
    icon: <Minus className="h-4 w-4 text-cyan-400" />,
  },
  RESOLVED: {
    label: "RESOLVED",
    color: "text-[oklch(0.88_0.18_145)]",
    dot: "bg-[oklch(0.88_0.18_145)]",
    icon: <CheckCircle2 className="h-4 w-4 text-[oklch(0.88_0.18_145)]" />,
  },
};

const SEVERITY_CONFIG: Record<
  Incident["severity"],
  { label: string; color: string; bg: string; border: string }
> = {
  P1: {
    label: "P1 — CRITICAL",
    color: "text-red-400",
    bg: "bg-red-500/10",
    border: "border-red-500/40",
  },
  P2: {
    label: "P2 — HIGH",
    color: "text-warning",
    bg: "bg-warning/10",
    border: "border-warning/40",
  },
  P3: {
    label: "P3 — STANDARD",
    color: "text-cyan-400",
    bg: "bg-cyan-500/10",
    border: "border-cyan-500/40",
  },
  P4: {
    label: "P4 — LOW",
    color: "text-gray-400",
    bg: "bg-gray-500/10",
    border: "border-gray-500/40",
  },
};

const ACTION_STATUS_CONFIG: Record<
  IncidentAction["status"],
  { icon: ReactNode; label: string; color: string }
> = {
  available: {
    icon: <Clock className="h-3.5 w-3.5" />,
    label: "Available",
    color: "text-muted-foreground",
  },
  in_progress: {
    icon: <Play className="h-3.5 w-3.5" />,
    label: "In Progress",
    color: "text-violet",
  },
  completed: {
    icon: <CheckCircle2 className="h-3.5 w-3.5" />,
    label: "Completed",
    color: "text-[oklch(0.88_0.18_145)]",
  },
  skipped: {
    icon: <SkipForward className="h-3.5 w-3.5" />,
    label: "Skipped",
    color: "text-muted-foreground/60",
  },
};

// ── Timeline item ────────────────────────────────────────────────────────────

function TimelineItem({ event, isLast }: { event: IncidentEvent; isLast: boolean }) {
  const actor = event.actor ? CREW.find((c) => c.id === event.actor) : null;

  return (
    <div className="flex gap-3">
      {/* Vertical line + dot */}
      <div className="flex flex-col items-center pt-1">
        <div className="h-2.5 w-2.5 rounded-full bg-violet/60 ring-2 ring-violet/20 shrink-0" />
        {!isLast && <div className="w-px flex-1 bg-border/60 mt-1" />}
      </div>

      {/* Content */}
      <div className="pb-4 min-w-0 flex-1">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="font-mono text-[11px] text-muted-foreground tracking-wider">
            {event.ts}
          </span>
          {actor && (
            <span className="flex items-center gap-1.5">
              <img src={actor.avatar} alt={actor.name} className="h-4 w-4 rounded" />
              <span className="font-mono text-[10px] text-foreground/70">{actor.name}</span>
            </span>
          )}
        </div>
        <p className="mt-0.5 text-sm text-foreground/85 leading-relaxed">
          {event.message}
        </p>
      </div>
    </div>
  );
}

// ── Action item ──────────────────────────────────────────────────────────────

function ActionItem({ action, onRun, onSkip, onComplete, onUndo, running }: { action: IncidentAction; onRun?: () => void; onSkip?: () => void; onComplete?: () => void; onUndo?: () => void; running?: boolean; }) {
  const cfg = ACTION_STATUS_CONFIG[action.status];
  const isDone = action.status === "completed";
  const isSkipped = action.status === "skipped";
  const isAvailable = action.status === "available";
  const isInProgress = action.status === "in_progress";

  return (
    <div
      className={[
        "rounded-lg border p-3 transition-colors",
        isDone
          ? "border-[oklch(0.88_0.18_145)]/20 bg-[oklch(0.88_0.18_145)]/5"
          : isSkipped
          ? "border-border/40 bg-card/20 opacity-60"
          : isInProgress
          ? "border-violet/40 bg-violet/10"
          : "border-border bg-card/40",
      ].join(" ")}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <span className={["flex items-center gap-1 font-mono text-[10px] uppercase tracking-wider", cfg.color].join(" ")}>
              {cfg.icon}
              {cfg.label}
            </span>
            {isInProgress && (
              <span className="inline-block h-2 w-2 rounded-full bg-violet animate-pulse" />
            )}
          </div>
          <h4 className={["mt-1 text-sm font-medium", (isDone || isSkipped) ? "line-through opacity-70" : isInProgress ? "text-violet" : "text-foreground"].join(" ")}>
            {action.label}
          </h4>
          <p className={["mt-0.5 text-xs leading-relaxed", (isDone || isSkipped) ? "text-muted-foreground/60" : "text-muted-foreground"].join(" ")}>
            {action.description}
          </p>
        </div>
      </div>

      {/* Action buttons for available state */}
      {isAvailable && (onRun || onSkip || onComplete) && (
        <div className="mt-3 flex items-center gap-2">
          {onRun && (
            <button
              onClick={onRun}
              disabled={running}
              className={`inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium transition-colors ${
                running
                  ? "bg-violet/50 text-primary-foreground/50 cursor-wait"
                  : "bg-violet text-primary-foreground hover:bg-violet/90"
              }`}
            >
              {running ? (
                <span className="h-3 w-3 animate-spin rounded-full border-2 border-primary-foreground/30 border-t-primary-foreground" />
              ) : (
                <Play className="h-3 w-3" />
              )}
              {running ? "Dispatching..." : "Run"}
            </button>
          )}
          {onComplete && (
            <button
              onClick={onComplete}
              className="inline-flex items-center gap-1.5 rounded-md border border-[oklch(0.88_0.18_145)]/40 bg-[oklch(0.88_0.18_145)]/10 px-3 py-1.5 text-xs font-medium text-[oklch(0.88_0.18_145)] transition-colors hover:bg-[oklch(0.88_0.18_145)]/20"
            >
              <CheckCircle2 className="h-3 w-3" />
              Completed
            </button>
          )}
          {onSkip && (
            <button
              onClick={onSkip}
              className="inline-flex items-center gap-1.5 rounded-md border border-border bg-background px-3 py-1.5 text-xs text-muted-foreground transition-colors hover:text-foreground"
            >
              <SkipForward className="h-3 w-3" />
              Skip
            </button>
          )}
        </div>
      )}

      {/* Action buttons for in_progress state */}
      {isInProgress && (onComplete || onUndo) && (
        <div className="mt-3 flex items-center gap-2">
          {onComplete && (
            <button
              onClick={onComplete}
              className="inline-flex items-center gap-1.5 rounded-md border border-[oklch(0.88_0.18_145)]/40 bg-[oklch(0.88_0.18_145)]/10 px-3 py-1.5 text-xs font-medium text-[oklch(0.88_0.18_145)] transition-colors hover:bg-[oklch(0.88_0.18_145)]/20"
            >
              <CheckCircle2 className="h-3 w-3" />
              Completed
            </button>
          )}
          {onUndo && (
            <button
              onClick={onUndo}
              className="inline-flex items-center gap-1.5 rounded-md border border-border bg-background px-3 py-1.5 text-xs text-muted-foreground transition-colors hover:text-foreground"
            >
              <SkipForward className="h-3 w-3 rotate-180" />
              Undo
            </button>
          )}
        </div>
      )}

      {/* Undo for completed/skipped */}
      {(isDone || isSkipped) && onUndo && (
        <div className="mt-3">
          <button
            onClick={onUndo}
            className="inline-flex items-center gap-1.5 rounded-md border border-border bg-background px-3 py-1.5 text-xs text-muted-foreground transition-colors hover:text-foreground"
          >
            <SkipForward className="h-3 w-3 rotate-180" />
            Undo
          </button>
        </div>
      )}

      {action.completedAt && (
        <div className="mt-2 flex items-center gap-1.5 font-mono text-[10px] text-muted-foreground">
          <Clock className="h-3 w-3" />
          {action.completedAt}
          {action.completedBy && (
            <>
              <span>·</span>
              <span>{CREW.find((c) => c.id === action.completedBy)?.name ?? action.completedBy}</span>
            </>
          )}
        </div>
      )}
    </div>
  );
}

// ── Severity badge ───────────────────────────────────────────────────────────

function SeverityBadge({ severity }: { severity: Incident["severity"] }) {
  const cfg = SEVERITY_CONFIG[severity];
  return (
    <span className={["inline-flex items-center gap-1.5 rounded-md border px-2 py-1 font-mono text-[11px] font-semibold tracking-wider", cfg.bg, cfg.border, cfg.color].join(" ")}>
      <Flame className="h-3.5 w-3.5" />
      {cfg.label}
    </span>
  );
}

// ── Status badge ─────────────────────────────────────────────────────────────

function StatusBadge({ status }: { status: Incident["status"] }) {
  const cfg = STATUS_CONFIG[status];
  return (
    <span className={["inline-flex items-center gap-1.5 rounded-md border border-border/60 bg-card/60 px-2 py-1 font-mono text-[11px] font-semibold tracking-wider", cfg.color].join(" ")}>
      <span className={["h-2 w-2 rounded-full", cfg.dot, status !== "RESOLVED" && "animate-pulse"].join(" ")} />
      {cfg.label}
    </span>
  );
}

// ── Main drawer ──────────────────────────────────────────────────────────────

interface IncidentDetailsDrawerProps {
  incident: Incident | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function IncidentDetailsDrawer({ incident, open, onOpenChange }: IncidentDetailsDrawerProps) {
  const [actions, setActions] = useState<IncidentAction[]>(incident?.actions ?? []);
  const [runningIndex, setRunningIndex] = useState<number | null>(null);

  // Sync actions when incident changes
  useEffect(() => {
    if (incident) setActions(incident.actions);
    setRunningIndex(null);
  }, [incident]);

  if (!incident) return null;

  const owner = CREW.find((c) => c.id === incident.owner);
  const statusCfg = STATUS_CONFIG[incident.status];
  const completedActions = actions.filter((a) => a.status === "completed").length;
  const totalActions = actions.length;

  const saveActions = (updatedActions: IncidentAction[]) => {
    // Persist to incidents.json via the server — send only id + actions
    fetch("/api/incidents/update", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: incident.id, actions: updatedActions }),
    }).catch((err) => console.error("[IncidentDetailsDrawer] Failed to save:", err));
  };

  const updateAction = (index: number, newStatus: IncidentAction["status"], createTask = false) => {
    const updated = actions.map((a, i) =>
      i === index
        ? { ...a, status: newStatus, completedAt: newStatus !== "available" ? new Date().toISOString().replace("T", " ").slice(0, 19) : undefined, completedBy: newStatus !== "available" ? "Space Monkey" : undefined }
        : a
    );
    setActions(updated);
    saveActions(updated);
    // When "Run" is clicked, create a task from this action
    if (createTask) {
      setRunningIndex(index);
      const action = actions[index];
      const taskTitle = `[Dispatch] ${action.label}`;
      const taskNote = action.description;
      fetch("/api/tasks/add", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          id: `inc-${incident.id}-${Date.now().toString(36)}`,
          title: taskTitle,
          assignee: incident.owner,
          status: "in_progress",
          ts: "just now",
          note: taskNote,
        }),
      })
        .then((res) => res.json())
        .then((data) => {
          if (!data.ok) {
            console.warn("[IncidentDetailsDrawer] Server rejected duplicate:", data.message);
          }
        })
        .catch((err) => console.error("[IncidentDetailsDrawer] Failed to create task:", err))
        .finally(() => setRunningIndex(null));
    }
  };

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent
        side="right"
        className="w-full sm:max-w-lg overflow-y-auto border-l-border/60 bg-background"
      >
        {/* Header */}
        <SheetHeader className="space-y-4 text-left">
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0 flex-1">
              <SheetDescription className="font-mono text-[11px] text-muted-foreground tracking-wider">
                {incident.id}
              </SheetDescription>
              <SheetTitle className="mt-1 text-lg font-bold tracking-tight leading-snug text-foreground">
                {incident.title}
              </SheetTitle>
            </div>
          </div>

          {/* Badges row */}
          <div className="flex flex-wrap items-center gap-2">
            <SeverityBadge severity={incident.severity} />
            <StatusBadge status={incident.status} />
          </div>
        </SheetHeader>

        {/* Meta info */}
        <div className="mt-5 grid grid-cols-2 gap-3">
          <div className="rounded-lg border border-border/60 bg-card/30 p-3">
            <div className="flex items-center gap-1.5 text-muted-foreground">
              <User className="h-3.5 w-3.5" />
              <span className="font-mono text-[10px] uppercase tracking-wider">Owner</span>
            </div>
            <div className="mt-1.5 flex items-center gap-2">
              {owner && (
                <>
                  <img src={owner.avatar} alt={owner.name} className="h-5 w-5 rounded" />
                  <span className="text-sm font-medium text-foreground">{owner.name}</span>
                </>
              )}
            </div>
          </div>

          <div className="rounded-lg border border-border/60 bg-card/30 p-3">
            <div className="flex items-center gap-1.5 text-muted-foreground">
              <Clock className="h-3.5 w-3.5" />
              <span className="font-mono text-[10px] uppercase tracking-wider">Opened</span>
            </div>
            <div className="mt-1.5 text-sm font-medium text-foreground">
              {incident.opened}
            </div>
          </div>

          {incident.resolved && (
            <div className="rounded-lg border border-border/60 bg-card/30 p-3">
              <div className="flex items-center gap-1.5 text-muted-foreground">
                <CheckCircle2 className="h-3.5 w-3.5" />
                <span className="font-mono text-[10px] uppercase tracking-wider">Resolved</span>
              </div>
              <div className="mt-1.5 text-sm font-medium text-foreground">
                {incident.resolved}
              </div>
            </div>
          )}

          <div className="rounded-lg border border-border/60 bg-card/30 p-3">
            <div className="flex items-center gap-1.5 text-muted-foreground">
              <CheckCircle2 className="h-3.5 w-3.5" />
              <span className="font-mono text-[10px] uppercase tracking-wider">Actions</span>
            </div>
            <div className="mt-1.5 text-sm font-medium text-foreground">
              {completedActions}/{totalActions} complete
            </div>
          </div>
        </div>

        {/* Summary */}
        <div className="mt-5">
          <h3 className="font-mono text-[11px] uppercase tracking-[0.18em] text-muted-foreground/70">
            Summary
          </h3>
          <p className="mt-2 text-sm text-foreground/85 leading-relaxed">
            {incident.summary}
          </p>
        </div>

        {/* Tags */}
        {incident.tags.length > 0 && (
          <div className="mt-5">
            <h3 className="flex items-center gap-1.5 font-mono text-[11px] uppercase tracking-[0.18em] text-muted-foreground/70">
              <Tag className="h-3.5 w-3.5" />
              Tags
            </h3>
            <div className="mt-2 flex flex-wrap gap-1.5">
              {incident.tags.map((tag) => (
                <Pill key={tag}>#{tag}</Pill>
              ))}
            </div>
          </div>
        )}

        {/* Timeline */}
        {incident.timeline.length > 0 && (
          <div className="mt-6">
            <h3 className="font-mono text-[11px] uppercase tracking-[0.18em] text-muted-foreground/70">
              Timeline
            </h3>
            <div className="mt-3 pl-1">
              {incident.timeline.map((event, i) => (
                <TimelineItem
                  key={`${event.ts}-${i}`}
                  event={event}
                  isLast={i === incident.timeline.length - 1}
                />
              ))}
            </div>
          </div>
        )}

        {/* Actions */}
        {incident.actions.length > 0 && (
          <div className="mt-6 mb-6">
            <h3 className="font-mono text-[11px] uppercase tracking-[0.18em] text-muted-foreground/70">
              Response Actions
            </h3>
            <div className="mt-3 space-y-2">
              {actions.map((action, i) => (
                <ActionItem
                  key={`${action.label}-${i}`}
                  action={action}
                  running={runningIndex === i}
                  onRun={() => updateAction(i, "in_progress", true)}
                  onComplete={() => updateAction(i, "completed")}
                  onSkip={() => updateAction(i, "skipped")}
                  onUndo={() => updateAction(i, "available")}
                />
              ))}
            </div>
          </div>
        )}
      </SheetContent>
    </Sheet>
  );
}


