import { useState, useCallback, useEffect, useRef } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { PageHeader, Pill, EmptyCameo } from "@/components/PageHeader";
import { CREW, getCrew } from "@/lib/crew";
import { getTasks } from "@/lib/server-data";
import type { Task } from "@/lib/server-data-types";

async function saveTasksToDisk(tasks: Task[]): Promise<{ ok: boolean }> {
  const res = await fetch("/api/save-tasks", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(tasks),
  });
  if (!res.ok) {
    let errMsg = "Save failed";
    try { const err = await res.json(); errMsg = err.error || errMsg; } catch { /* ignore */ }
    throw new Error(errMsg);
  }
  return res.json();
}

async function dispatchTaskToQueue(task: { taskId: string; title: string; assignee: string }): Promise<{ ok: boolean; queueId?: string }> {
  const res = await fetch("/api/dispatch", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(task),
  });
  if (!res.ok) {
    let errMsg = "Dispatch failed";
    try { const err = await res.json(); errMsg = err.error || errMsg; } catch { /* ignore */ }
    throw new Error(errMsg);
  }
  return res.json();
}
import { Plus, X, User, FileText, ChevronDown, Send, Pencil, Trash2, Clock, User as UserIcon, CheckCircle } from "lucide-react";

// ── Auto-move configuration ────────────────────────────────────────────────
const AUTO_COMPLETE_DELAY_MS = 5 * 60 * 1000; // 5 minutes
import { loadState, saveState } from "@/lib/persist";

export const Route = createFileRoute("/tasks")({
  head: () => ({ meta: [{ title: "Tasks — Mission Control" }] }),
  loader: async () => {
    try {
      const tasks = await getTasks();
      console.log("[tasks loader] Loaded", tasks.length, "tasks");
      return tasks;
    } catch (err) {
      console.error("[tasks loader] Error:", err);
      return [];
    }
  },
  component: TasksPage,
  errorComponent: ({ error }) => {
    console.error("[tasks route] Error:", error);
    return (
      <div className="rounded-xl border border-destructive/40 bg-destructive/10 px-6 py-14 text-center">
        <div className="font-mono text-xs tracking-[0.25em] text-destructive">— LOADER ERROR —</div>
        <div className="mt-3 text-sm text-muted-foreground">Failed to load tasks. Check console for details.</div>
        <div className="mt-2 font-mono text-[10px] text-muted-foreground/50">{String(error)}</div>
      </div>
    );
  },
});

const COLS: { key: Task["status"]; label: string; accent: string }[] = [
  { key: "backlog", label: "Backlog", accent: "text-muted-foreground" },
  { key: "in_progress", label: "In Progress", accent: "text-[oklch(0.85_0.12_295)]" },
  { key: "done", label: "Done", accent: "text-[oklch(0.88_0.18_145)]" },
  { key: "awaiting_review", label: "Awaiting Review", accent: "text-[oklch(0.85_0.12_225)]" },
];

function generateId(): string {
  return `task-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`;
}

// ── New Task Modal ───────────────────────────────────────────────────────────

function NewTaskModal({ onClose, onAdd }: { onClose: () => void; onAdd: (t: Task) => void }) {
  const [title, setTitle] = useState("");
  const [assignee, setAssignee] = useState("monkey");
  const [priority, setPriority] = useState<"P1" | "P2" | "P3" | "P4">("P3");
  const [note, setNote] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || submitting) return;
    setSubmitting(true);
    const task: Task = {
      id: generateId(),
      title: title.trim(),
      assignee,
      status: "backlog",
      priority: "P3" as const,
      ts: "just now",
      note: note.trim() || undefined,
      history: [{ ts: new Date().toISOString(), action: "created" as const, actor: assignee, details: "Task created" }],
    };
    onAdd(task);
    setSubmitting(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="fixed inset-0 bg-background/80 backdrop-blur-sm" />
      <div
        className="relative w-full max-w-md rounded-xl border border-border bg-card shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between px-5 py-4 border-b border-border">
          <h2 className="font-mono text-sm tracking-wider">NEW TASK</h2>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground transition-colors">
            <X className="h-4 w-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          {/* Title */}
          <div>
            <label className="block font-mono text-[10px] tracking-[0.2em] text-muted-foreground mb-1.5">
              TITLE
            </label>
            <input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="What needs to be done?"
              className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm placeholder:text-muted-foreground focus:outline-none focus:border-violet/60"
              autoFocus
            />
          </div>

          {/* Priority */}
          <div>
            <label className="block font-mono text-[10px] tracking-[0.2em] text-muted-foreground mb-1.5">
              PRIORITY
            </label>
            <div className="relative">
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value as "P1" | "P2" | "P3" | "P4")}
                className="w-full appearance-none rounded-md border border-border bg-background px-3 py-2 pr-8 text-sm focus:outline-none focus:border-violet/60"
              >
                <option value="P1">P1 — Critical</option>
                <option value="P2">P2 — High</option>
                <option value="P3">P3 — Normal</option>
                <option value="P4">P4 — Background</option>
              </select>
              <ChevronDown className="pointer-events-none absolute right-2 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            </div>
          </div>

          {/* Assignee */}
          <div>
            <label className="block font-mono text-[10px] tracking-[0.2em] text-muted-foreground mb-1.5">
              ASSIGNEE
            </label>
            <div className="relative">
              <select
                value={assignee}
                onChange={(e) => setAssignee(e.target.value)}
                className="w-full appearance-none rounded-md border border-border bg-background px-3 py-2 pr-8 text-sm focus:outline-none focus:border-violet/60"
              >
                {CREW.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.emoji} {c.name} — {c.shortRole}
                  </option>
                ))}
              </select>
              <ChevronDown className="pointer-events-none absolute right-2 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            </div>
          </div>

          {/* Note */}
          <div>
            <label className="block font-mono text-[10px] tracking-[0.2em] text-muted-foreground mb-1.5">
              NOTE <span className="text-muted-foreground/50">(optional)</span>
            </label>
            <textarea
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Additional context…"
              rows={3}
              className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm placeholder:text-muted-foreground focus:outline-none focus:border-violet/60 resize-none"
            />
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="rounded-md border border-border bg-background px-4 py-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!title.trim() || submitting}
              className="rounded-md bg-violet px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-violet/90 disabled:opacity-40 disabled:cursor-not-allowed"
            >
              Add to Backlog
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

// ── Task Detail Panel ───────────────────────────────────────────────────────

function TaskDetailPanel({
  task,
  onClose,
  onUpdate,
  onDelete,
}: {
  task: Task;
  onClose: () => void;
  onUpdate: (task: Task) => void;
  onDelete: (id: string) => void;
}) {
  const [editing, setEditing] = useState(false);
  const [title, setTitle] = useState(task.title);
  const [note, setNote] = useState(task.note || "");
  const [summary, setSummary] = useState(task.summary || "");
  const [assignee, setAssignee] = useState(task.assignee);
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    setSaving(true);
    const updated = { ...task, title: title.trim(), note: note.trim() || undefined, summary: summary.trim() || undefined, assignee, ts: "just now" };
    onUpdate(updated);
    setSaving(false);
    setEditing(false);
  };

  const a = getCrew(task.assignee);
  const statusColors = {
    backlog: "text-muted-foreground",
    in_progress: "text-[oklch(0.85_0.12_295)]",
    awaiting_review: "text-amber-400",
    done: "text-[oklch(0.88_0.18_145)]",
  };
  const statusLabels = {
    backlog: "BACKLOG",
    in_progress: "IN PROGRESS",
    awaiting_review: "AWAITING REVIEW",
    done: "DONE",
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="fixed inset-0 bg-background/60 backdrop-blur-sm" />
      <div
        className="relative w-full max-w-lg max-h-[85vh] rounded-xl border border-border bg-card shadow-2xl overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
        style={{ animation: "fade-in 0.2s ease-out" }}
      >
        {/* Header */}
        <div className="sticky top-0 z-10 flex items-center justify-between px-5 py-4 border-b border-border bg-card/95 backdrop-blur rounded-t-xl">
          <div className="font-mono text-[10px] tracking-[0.25em] text-muted-foreground">TASK DETAIL</div>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground transition-colors">
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="p-5 space-y-5">
          {/* Status badge */}
          <div className="flex items-center gap-3">
            <span className={`font-mono text-[10px] tracking-[0.2em] ${statusColors[task.status]}`}>
              {statusLabels[task.status]}
            </span>
            <span className="font-mono text-[10px] text-muted-foreground/50">{task.id}</span>
          </div>

          {/* Title */}
          {editing ? (
            <div>
              <label className="block font-mono text-[10px] tracking-[0.2em] text-muted-foreground mb-1.5">TITLE</label>
              <input
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm focus:outline-none focus:border-violet/60"
                autoFocus
              />
            </div>
          ) : (
            <div>
              <h2 className="text-lg font-semibold leading-snug">{task.title}</h2>
              {task.note && <p className="mt-2 text-sm text-muted-foreground">{task.note}</p>}
            </div>
          )}

          {/* Completion Summary — prominent section for Done tasks */}
          {task.status === "done" && !editing && (
            <div className="rounded-lg border border-[oklch(0.88_0.18_145)]/30 bg-[oklch(0.88_0.18_145)]/5 p-4">
              <div className="flex items-center gap-2 mb-3">
                <CheckCircle className="h-4 w-4 text-[oklch(0.88_0.18_145)]" />
                <span className="font-mono text-[10px] tracking-[0.2em] text-[oklch(0.88_0.18_145)] font-semibold">COMPLETION SUMMARY</span>
              </div>

              {/* Original description */}
              {task.note && (
                <div className="mb-3">
                  <div className="font-mono text-[9px] tracking-[0.15em] text-muted-foreground/60 mb-1">ORIGINAL DESCRIPTION</div>
                  <p className="text-sm text-muted-foreground/80">{task.note}</p>
                </div>
              )}

              {/* What was done */}
              <div className="mb-3">
                <div className="font-mono text-[9px] tracking-[0.15em] text-muted-foreground/60 mb-1">WHAT WAS DONE</div>
                {task.summary ? (
                  <p className="text-sm text-foreground/80 whitespace-pre-wrap">{task.summary}</p>
                ) : (
                  <p className="text-sm text-muted-foreground/50 italic">No completion summary provided</p>
                )}
              </div>

              {/* Completed by & timestamp */}
              <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-muted-foreground/70">
                <div className="flex items-center gap-1.5">
                  <UserIcon className="h-3.5 w-3.5" />
                  <span>Completed by <span className="text-foreground/80">{a?.name || task.assignee}</span></span>
                </div>
                {task.completedAt && (
                  <div className="flex items-center gap-1.5">
                    <Clock className="h-3.5 w-3.5" />
                    <span>{new Date(task.completedAt).toLocaleString("en-GB", { day: "numeric", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" })}</span>
                  </div>
                )}
              </div>

              {/* Files changed / commits from note */}
              {task.note && task.note.includes("commit") && (
                <div className="mt-3 pt-3 border-t border-[oklch(0.88_0.18_145)]/20">
                  <div className="font-mono text-[9px] tracking-[0.15em] text-muted-foreground/60 mb-1">COMMITS / FILES CHANGED</div>
                  <p className="text-xs text-foreground/70 font-mono whitespace-pre-wrap">{task.note}</p>
                </div>
              )}
            </div>
          )}

          {/* Summary display for non-Done tasks (view mode) */}
          {task.status !== "done" && !editing && task.summary && (
            <div className="rounded-md border border-border/60 bg-card/30 p-3">
              <div className="font-mono text-[9px] tracking-[0.2em] text-muted-foreground mb-1">SUMMARY</div>
              <p className="text-sm text-foreground/80 whitespace-pre-wrap">{task.summary}</p>
            </div>
          )}

          {/* Note (edit mode) */}
          {editing && (
            <div>
              <label className="block font-mono text-[10px] tracking-[0.2em] text-muted-foreground mb-1.5">NOTE</label>
              <textarea
                value={note}
                onChange={(e) => setNote(e.target.value)}
                rows={4}
                className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm focus:outline-none focus:border-violet/60 resize-none"
              />
            </div>
          )}

          {/* Summary (edit mode) */}
          {editing && (
            <div>
              <label className="block font-mono text-[10px] tracking-[0.2em] text-muted-foreground mb-1.5">SUMMARY</label>
              <textarea
                value={summary}
                onChange={(e) => setSummary(e.target.value)}
                rows={3}
                placeholder="What was changed? What files were modified? How to verify?"
                className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm focus:outline-none focus:border-violet/60 resize-none"
              />
            </div>
          )}

          {/* Assignee */}
          <div>
            <label className="block font-mono text-[10px] tracking-[0.2em] text-muted-foreground mb-1.5">ASSIGNEE</label>
            {editing ? (
              <div className="relative">
                <select
                  value={assignee}
                  onChange={(e) => setAssignee(e.target.value)}
                  className="w-full appearance-none rounded-md border border-border bg-background px-3 py-2 pr-8 text-sm focus:outline-none focus:border-violet/60"
                >
                  {CREW.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.emoji} {c.name} — {c.shortRole}
                    </option>
                  ))}
                </select>
                <ChevronDown className="pointer-events-none absolute right-2 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              </div>
            ) : (
              <div className="flex items-center gap-2">
                {a && (
                  <>
                    <img src={a.avatar} alt={a.name} className="h-6 w-6 rounded border border-border object-cover" />
                    <span className="text-sm">{a.name}</span>
                    <span className="text-xs text-muted-foreground">({a.shortRole})</span>
                  </>
                )}
              </div>
            )}
          </div>

          {/* Metadata */}
          <div className="space-y-2 rounded-lg border border-border/60 bg-card/30 p-3">
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <Clock className="h-3.5 w-3.5" />
              <span>Last updated: {task.ts}</span>
            </div>
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <UserIcon className="h-3.5 w-3.5" />
              <span>Assigned to: {a?.name || task.assignee}</span>
            </div>
            {task.priority && (
              <div className="flex items-center gap-2 text-xs">
                <span className={`inline-flex items-center rounded-full border px-1.5 py-0.5 font-mono text-[8px] uppercase tracking-wider ${
                  task.priority === "P1" ? "border-destructive/50 bg-destructive/10 text-destructive" :
                  task.priority === "P2" ? "border-warning/50 bg-warning/10 text-warning" :
                  task.priority === "P3" ? "border-violet/40 bg-violet/10 text-violet" :
                  "border-border/40 bg-muted/10 text-muted-foreground"
                }`}>{task.priority}</span>
                <span className="text-muted-foreground">Priority</span>
              </div>
            )}
            {task.status === "in_progress" && (
              <div className="flex items-center gap-2 text-xs text-violet">
                <Send className="h-3.5 w-3.5" />
                <span>Dispatched to queue</span>
              </div>
            )}
          </div>

          {/* History Timeline */}
          {task.history && task.history.length > 0 && (
            <div className="space-y-2">
              <div className="font-mono text-[10px] tracking-[0.2em] text-muted-foreground">HISTORY</div>
              <div className="space-y-1.5 max-h-40 overflow-y-auto">
                {task.history.slice().reverse().map((entry) => (
                  <div key={`${entry.ts}-${entry.action}`} className="flex items-start gap-2 text-xs text-muted-foreground/80">
                    <span className="font-mono text-[9px] text-muted-foreground/50 shrink-0 w-16">
                      {new Date(entry.ts).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" })}
                    </span>
                    <span className={`font-mono text-[9px] uppercase tracking-wider shrink-0 w-20 ${
                      entry.action === "completed" ? "text-online" :
                      entry.action === "escalated" ? "text-destructive" :
                      entry.action === "stalled" ? "text-warning" :
                      entry.action === "started" ? "text-violet" :
                      "text-muted-foreground"
                    }`}>{entry.action}</span>
                    <span className="text-foreground/70">{entry.details || entry.actor || "—"}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Actions */}
          <div className="flex items-center gap-2 pt-2">
            {editing ? (
              <>
                <button
                  onClick={handleSave}
                  disabled={!title.trim() || saving}
                  className="rounded-md bg-violet px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-violet/90 disabled:opacity-40"
                >
                  {saving ? "Saving…" : "Save Changes"}
                </button>
                <button
                  onClick={() => { setEditing(false); setTitle(task.title); setNote(task.note || ""); setSummary(task.summary || ""); setAssignee(task.assignee); }}
                  className="rounded-md border border-border bg-background px-4 py-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
                >
                  Cancel
                </button>
              </>
            ) : (
              <>
                <button
                  onClick={() => setEditing(true)}
                  className="inline-flex items-center gap-1.5 rounded-md border border-border bg-background px-3 py-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
                >
                  <Pencil className="h-3.5 w-3.5" />
                  Edit
                </button>
                <button
                  onClick={() => { onDelete(task.id); onClose(); }}
                  className="inline-flex items-center gap-1.5 rounded-md border border-destructive/30 bg-background px-3 py-2 text-sm text-destructive hover:bg-destructive/10 transition-colors"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                  Delete
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Task Card ────────────────────────────────────────────────────────────────

function TaskCard({
  t,
  onDragStart,
  dragging,
  onClick,
}: {
  t: Task;
  onDragStart: (id: string) => void;
  dragging: boolean;
  onClick: () => void;
}) {
  const a = getCrew(t.assignee);
  const isInProgress = t.status === "in_progress";
  const isAwaitingReview = t.status === "awaiting_review";
  const isDone = t.status === "done";
  const isBacklog = t.status === "backlog";

  // Calculate time in current status
  const timeInStatus = t.lastUpdated
    ? getTimeAgo(t.lastUpdated)
    : t.ts;

  // Progress percentage (simulated based on time in progress)
  const progressPct = t.progress ?? (isDone ? 100 : isInProgress ? calculateProgress(t) : 0);

  return (
    <div
      draggable
      onDragStart={(e) => {
        e.dataTransfer.effectAllowed = "move";
        e.dataTransfer.setData("text/plain", t.id);
        onDragStart(t.id);
      }}
      onClick={(e) => {
        if (!dragging) onClick();
      }}
      className={`cursor-grab active:cursor-grabbing rounded-lg border p-3 transition-all hover:shadow-md ${
        dragging
          ? "opacity-40 border-violet/80 scale-95"
          : isInProgress
          ? "border-violet/50 bg-violet/5 shadow-[0_0_12px_oklch(0.62_0.22_295/0.2)] ring-1 ring-violet/20"
          : isAwaitingReview
          ? "border-warning/40 bg-warning/5 ring-1 ring-warning/20"
          : isDone
          ? "border-[oklch(0.88_0.18_145)]/30 bg-[oklch(0.88_0.18_145)]/5"
          : "border-border hover:border-violet/50"
      }`}
    >
      {/* Progress bar (in-progress only) */}
      {isInProgress && (
        <div className="mb-2 h-1 w-full rounded-full bg-muted/30 overflow-hidden">
          <div
            className="h-full rounded-full bg-gradient-to-r from-violet/60 to-violet transition-all duration-1000"
            style={{ width: `${progressPct}%` }}
          />
        </div>
      )}

      <div className="flex items-start justify-between gap-2">
        <div className="font-mono text-[10px] text-muted-foreground tracking-wider">{t.id.slice(0, 16)}</div>
        <div className="flex items-center gap-1.5">
          {t.title.startsWith("[Dispatch] ") && (
            <span className="inline-flex items-center rounded-full border border-violet/40 bg-violet/10 px-1.5 py-0.5 font-mono text-[8px] uppercase tracking-wider text-violet">
              Dispatch
            </span>
          )}
          {t.priority && (
            <span className={`inline-flex items-center rounded-full border px-1.5 py-0.5 font-mono text-[8px] uppercase tracking-wider ${
              t.priority === "P1" ? "border-destructive/50 bg-destructive/10 text-destructive" :
              t.priority === "P2" ? "border-warning/50 bg-warning/10 text-warning" :
              t.priority === "P3" ? "border-violet/40 bg-violet/10 text-violet" :
              "border-border/40 bg-muted/10 text-muted-foreground"
            }`}>{t.priority}</span>
          )}
          <div className="font-mono text-[10px] text-muted-foreground">{timeInStatus}</div>
        </div>
      </div>
      <div className={`mt-1 text-sm font-medium leading-snug ${isDone ? "line-through opacity-60" : ""}`}>
        {t.title.replace("[Dispatch] ", "")}
      </div>
      {t.note && <div className="mt-1 text-xs text-muted-foreground italic truncate">{t.note}</div>}
      {/* Completion summary for Done tasks */}
      {isDone && (
        <div className="mt-2">
          {t.summary ? (
            <p className="text-xs text-foreground/70 leading-relaxed">
              {t.summary.length > 60 ? t.summary.slice(0, 57) + "…" : t.summary}
            </p>
          ) : (
            <p className="text-xs text-muted-foreground/50 italic">No completion summary</p>
          )}
          <div className="mt-1.5 flex items-center gap-1.5 text-[10px] text-muted-foreground/50">
            <CheckCircle className="h-3 w-3" />
            <span>Done by {a?.name || t.assignee}</span>
            {t.completedAt && (
              <>
                <span>·</span>
                <span>{new Date(t.completedAt).toLocaleString("en-GB", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })}</span>
              </>
            )}
          </div>
        </div>
      )}
      <div className="mt-3 flex items-center gap-2">
        {a && (
          <>
            <div className="relative">
              <img src={a.avatar} alt={a.name} loading="lazy" width={20} height={20} className="h-5 w-5 rounded border border-border object-cover" />
              {isInProgress && (
                <span className="absolute -bottom-0.5 -right-0.5 h-2 w-2 rounded-full bg-violet animate-pulse ring-2 ring-card" />
              )}
            </div>
            <span className="text-xs text-muted-foreground">{a.name}</span>
          </>
        )}
        {isInProgress && (
          <span className="ml-auto inline-flex items-center gap-1 rounded-full border border-violet/40 bg-violet/15 px-2 py-0.5 font-mono text-[8px] text-violet font-semibold">
            <span className="h-1.5 w-1.5 rounded-full bg-violet animate-pulse" />
            WORKING
          </span>
        )}
        {isAwaitingReview && (
          <span className="ml-auto inline-flex items-center gap-1 rounded-full border border-warning/40 bg-warning/10 px-2 py-0.5 font-mono text-[8px] text-warning font-semibold">
            <Clock className="h-2.5 w-2.5" />
            AWAITING REVIEW
          </span>
        )}
        {isDone && (
          <span className={`ml-auto inline-flex items-center gap-1 rounded-full border border-[oklch(0.88_0.18_145)]/30 bg-[oklch(0.88_0.18_145)]/10 px-2 py-0.5 font-mono text-[8px] text-[oklch(0.88_0.18_145)] font-semibold ${t.ts === "just now" ? "celebration" : ""}`}>
            <CheckCircle className="h-2.5 w-2.5" />
            DONE
          </span>
        )}
        {isBacklog && t.lastUpdated && (
          <span className="ml-auto font-mono text-[9px] text-muted-foreground/50">
            idle {timeInStatus}
          </span>
        )}
      </div>
    </div>
  );
}

function getTimeAgo(ts: string): string {
  if (ts === "just now") return "just now";
  const d = new Date(ts);
  const now = new Date();
  const diff = now.getTime() - d.getTime();
  if (diff < 60000) return "just now";
  if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
  if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`;
  return d.toLocaleDateString("en-GB", { day: "numeric", month: "short" });
}

function calculateProgress(t: Task): number {
  if (!t.startedAt) return 10;
  const elapsed = Date.now() - new Date(t.startedAt).getTime();
  // Estimate: tasks progress ~10% per minute, cap at 95% until done
  const estimated = Math.min(95, Math.floor(elapsed / 60000) * 10);
  return Math.max(5, estimated);
}

// ── Main Tasks Page ──────────────────────────────────────────────────────────

function TasksPage() {
  // Toast for auto‑requeue notifications
  const [toast, setToast] = useState<{ id:string;message:string } | null>(null);
  // Timers for each in‑progress task (detect stall)
  const stallTimers = useRef<Map<string, NodeJS.Timeout>>(new Map());
  const initialTasks = Route.useLoaderData() as Task[];
  const [tasks, setTasks] = useState<Task[]>(initialTasks);
  const [dragId, setDragId] = useState<string | null>(null);
  const [overCol, setOverCol] = useState<Task["status"] | null>(null);
  const [saved, setSaved] = useState(true);
  const [showNewTask, setShowNewTask] = useState(false);
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);

  const markDirty = () => {
    setSaved(false);
    setTimeout(() => setSaved(true), 1500);
  };

  const moveTask = useCallback((id: string, status: Task["status"]) => {
    setTasks((prev) => {
      const next = prev.map((t) => {
        if (t.id !== id || t.status === status) return t;
        const now = new Date().toISOString();
        const historyEntry = {
          ts: now,
          action: status === "in_progress" ? "started" as const :
                 status === "done" ? "completed" as const :
                 status === "backlog" ? "reassigned" as const : "progress" as const,
          actor: t.assignee,
          details: `Status changed from ${t.status} to ${status}`,
        };

        // Auto-generate completion summary when moving to Done
        let autoSummary = t.summary;
        let completedAt = t.completedAt;
        if (status === "done" && !t.summary) {
          completedAt = now;
          // Find the most recent started/progress entry in history
          const relevantEntries = (t.history || []).filter(
            (h) => h.action === "started" || h.action === "progress" || h.action === "dispatched"
          );
          const lastAction = relevantEntries.length > 0
            ? relevantEntries[relevantEntries.length - 1]
            : null;
          const agentName = t.assignee;
          if (lastAction) {
            const actionLabel = lastAction.action === "dispatched" ? "dispatched to queue" : lastAction.action;
            autoSummary = `Completed by ${agentName}. Last action: ${actionLabel}`;
            if (lastAction.details) {
              autoSummary += ` — ${lastAction.details}`;
            }
          } else {
            autoSummary = `Completed by ${agentName}.`;
          }
        }

        return {
          ...t,
          status,
          ts: "just now",
          lastUpdated: now,
          startedAt: status === "in_progress" ? now : t.startedAt,
          completedAt: status === "done" ? now : t.completedAt,
          progress: status === "done" ? 100 : status === "in_progress" ? 5 : t.progress,
          summary: autoSummary,
          history: [...(t.history || []), historyEntry],
        };
      });
      const moved = next.find((t) => t.id === id);
      if (!moved) return prev;
      // Enforce summary requirement for awaiting_review
      if (status === "awaiting_review" && !moved.summary && !moved.note) {
        console.warn("[moveTask] Cannot move to awaiting_review without a summary");
        return prev; // reject the move
      }
      const result = [moved, ...next.filter((t) => t.id !== id)];
      markDirty();

      // Persist to workspace (outside updater — side effect)
      console.log("[moveTask] Calling saveTasks with", result.length, "tasks");
      saveTasksToDisk(result).then((res) => {
        console.log("[moveTask] Save succeeded:", res);
      }).catch((err: unknown) => {
        console.error("[moveTask] Save failed:", err);
      });

      // DISPATCH: When moving to In Progress, enqueue real work
      if (status === "in_progress" && moved.status !== "in_progress") {
        dispatchTaskToQueue({
          taskId: moved.id,
          title: moved.title,
          assignee: moved.assignee,
        }).then(() => {
          console.log("[moveTask] Dispatched", moved.title, "to", moved.assignee);
        }).catch((err: unknown) => {
          console.error("[moveTask] Dispatch failed:", err);
        });
      }

      // ERROR RESOLUTION: When moving a task to Done, check if it resolves a cron error
      if (status === "done" && moved.errorId) {
        // Resolve cron error via API
        fetch("/api/cron-errors", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ errorId: moved.errorId, status: "completed" }),
        }).then(() => {
          console.log("[moveTask] Resolved cron error:", moved.errorId);
        }).catch((err: unknown) => {
          console.error("[moveTask] Failed to resolve cron error:", err);
        });
      }
      return result;
    });
  }, []);

  const addTask = useCallback((task: Task) => {
    setTasks((prev) => {
      const result = [task, ...prev];
      markDirty();

      // Persist to workspace
      saveTasksToDisk(result).catch((err: unknown) => {
        console.error("[addTask] Save failed:", err);
      });

      return result;
    });
  }, []);

  const updateTask = useCallback((updated: Task) => {
    setTasks((prev) => {
      const result = prev.map((t) => (t.id === updated.id ? updated : t));
      saveTasksToDisk(result).catch((err: unknown) => {
        console.error("[updateTask] Save failed:", err);
      });
      return result;
    });
  }, []);

  const deleteTask = useCallback((id: string) => {
    setTasks((prev) => {
      const result = prev.filter((t) => t.id !== id);
      markDirty();

      // Persist to workspace
      saveTasksToDisk(result).catch((err: unknown) => {
        console.error("[deleteTask] Save failed:", err);
      });
      return result;
    });
  }, []);

  // Persist view state (selected tab, scroll position) across reloads
  useEffect(() => {
    const state = loadState();
    saveState({ lastView: "/tasks" });
  }, []);
  // Auto-complete DISABLED — tasks only move to Done manually after review
  // No automatic timer-based status changes

  const inProgressTasks = tasks.filter(t => t.status === "in_progress");

  return (
    <>
      <PageHeader
        icon="🎯"
        title="Tasks"
        meta={`${tasks.length} total · ${inProgressTasks.length} in progress${saved ? "" : " · saving…"}`}
      >
        <div className="flex items-center gap-3 mt-1">
          <span className="text-sm text-muted-foreground">Drag cards to change status. Moving to In Progress dispatches work.</span>
          <button
            onClick={() => setShowNewTask(true)}
            className="inline-flex items-center gap-1.5 rounded-md bg-violet px-3 py-1.5 text-xs font-medium text-primary-foreground transition-colors hover:bg-violet/90 shrink-0"
          >
            <Plus className="h-3.5 w-3.5" />
            New Task
          </button>
        </div>
      </PageHeader>

      {tasks.length === 0 ? (
        <div>
          <EmptyCameo
            icon="🃏"
            message="Station quiet. Crew playing cards in the mess hall."
            hint="QUEUE EMPTY"
          />
          <div className="mt-4 text-center">
            <button
              onClick={() => setShowNewTask(true)}
              className="inline-flex items-center gap-1.5 rounded-md bg-violet px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-violet/90"
            >
              <Plus className="h-4 w-4" />
              New Task
            </button>
          </div>
        </div>
      ) : (
        <div className="grid gap-4 md:grid-cols-3">
          {COLS.map((col) => {
            const items = tasks.filter((t) => t.status === col.key);
            const isOver = overCol === col.key;
            return (
              <div
                key={col.key}
                onDragOver={(e) => {
                  e.preventDefault();
                  e.dataTransfer.dropEffect = "move";
                  if (overCol !== col.key) setOverCol(col.key);
                }}
                onDragLeave={(e) => {
                  if (e.currentTarget === e.target) setOverCol(null);
                }}
                onDrop={(e) => {
                  e.preventDefault();
                  const id = e.dataTransfer.getData("text/plain") || dragId;
                  if (id) moveTask(id, col.key);
                  setOverCol(null);
                  setDragId(null);
                }}
                className={`rounded-xl border bg-card/30 p-3 transition-colors ${
                  isOver ? "border-violet/70 bg-violet/10 shadow-[0_0_0_1px_oklch(0.62_0.22_295/0.4)]" : "border-border"
                }`}
              >
                <div className="mb-3 flex items-center justify-between px-1">
                  <div className={`font-mono text-xs uppercase tracking-[0.18em] ${col.accent} flex items-center gap-1.5`}>
                    {col.key === "in_progress" && items.length > 0 && (
                      <span className="h-2 w-2 rounded-full bg-violet animate-pulse" />
                    )}
                    {col.label}
                  </div>
                  <div className="flex items-center gap-2">
                    {col.key === "done" && items.length > 0 && (() => {
                      const withSummary = items.filter((t) => t.summary).length;
                      const withoutSummary = items.length - withSummary;
                      return (
                        <span className="font-mono text-[9px] text-muted-foreground/50">
                          {withSummary} summarized{withoutSummary > 0 ? ` · ${withoutSummary} missing` : ""}
                        </span>
                      );
                    })()}
                    <Pill>{items.length}</Pill>
                  </div>
                </div>
                <div className="space-y-2 min-h-[80px]">
                  {items.length === 0 ? (
                    <div className={`rounded-md border border-dashed px-3 py-6 text-center text-xs transition-colors ${isOver ? "border-violet/60 text-foreground" : "border-border/70 text-muted-foreground"}`}>
                      {isOver ? "Drop here" : "No tasks"}
                    </div>
                  ) : (
                    items.map((t) => (
                      <TaskCard key={t.id} t={t} dragging={dragId === t.id} onDragStart={setDragId} onClick={() => setSelectedTask(t)} />
                    ))
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {showNewTask && <NewTaskModal onClose={() => setShowNewTask(false)} onAdd={addTask} />}
      {selectedTask && (
        <TaskDetailPanel
          task={selectedTask}
          onClose={() => setSelectedTask(null)}
          onUpdate={(updated) => {
            updateTask(updated);
            setSelectedTask(null);
          }}
          onDelete={(id) => {
            deleteTask(id);
            setSelectedTask(null);
          }}
        />
      )}
    </>
  );
}
