import { createFileRoute } from "@tanstack/react-router";
import { PageHeader, Pill, EmptyCameo } from "@/components/PageHeader";
import { getActivityFeed, getTasks } from "@/lib/server-data";
import type { ActivityEvent, Task } from "@/lib/server-data-types";
import { CREW } from "@/lib/crew";
import { FileText, CheckCircle, Clock, AlertTriangle, Brain, Settings, Play, Loader2 } from "lucide-react";

export const Route = createFileRoute("/activity")({
  head: () => ({ meta: [{ title: "Activity — Mission Control" }] }),
  loader: async () => {
    const [events, tasks] = await Promise.all([getActivityFeed(), getTasks()]);
    return { events, tasks };
  },
  component: ActivityPage,
});

const TYPE_CONFIG: Record<string, { icon: React.ReactNode; color: string }> = {
  task: { icon: <CheckCircle className="h-4 w-4" />, color: "text-[oklch(0.85_0.12_295)]" },
  cron: { icon: <Clock className="h-4 w-4" />, color: "text-online" },
  system: { icon: <Settings className="h-4 w-4" />, color: "text-muted-foreground" },
  memory: { icon: <Brain className="h-4 w-4" />, color: "text-[oklch(0.92_0.16_90)]" },
  project: { icon: <FileText className="h-4 w-4" />, color: "text-cyan-accent" },
  incident: { icon: <AlertTriangle className="h-4 w-4" />, color: "text-destructive" },
};

function formatTime(ts: string): string {
  const d = new Date(ts);
  const now = new Date();
  const diff = now.getTime() - d.getTime();
  if (diff < 60000) return "just now";
  if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
  if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`;
  return d.toLocaleDateString("en-GB", { day: "numeric", month: "short" });
}

function ActivityPage() {
  const { events, tasks } = Route.useLoaderData() as { events: ActivityEvent[]; tasks: Task[] };

  const inProgressTasks = tasks.filter((t) => t.status === "in_progress");
  const backlogTasks = tasks.filter((t) => t.status === "backlog");
  const doneTasks = tasks.filter((t) => t.status === "done");

  return (
    <>
      <PageHeader icon="📡" title="Activity Feed" meta={`${events.length} recent events`}>
        A chronological log of everything happening on the station.
      </PageHeader>

      {/* Now Running panel */}
      {(inProgressTasks.length > 0 || backlogTasks.length > 0) && (
        <div className="mb-6 grid gap-4 md:grid-cols-2">
          {/* In Progress */}
          {inProgressTasks.length > 0 && (
            <div className="rounded-xl border border-violet/30 bg-violet/5 p-4">
              <div className="flex items-center gap-2 mb-3">
                <Play className="h-4 w-4 text-violet" />
                <span className="font-mono text-[10px] tracking-[0.2em] text-violet uppercase">Now Running</span>
                <span className="ml-auto rounded-full bg-violet/20 px-1.5 py-0.5 font-mono text-[10px] text-violet">
                  {inProgressTasks.length}
                </span>
              </div>
              <div className="space-y-2">
                {inProgressTasks.map((task) => {
                  const crew = CREW.find((c) => c.id === task.assignee);
                  return (
                    <div key={task.id} className="flex items-center gap-2 rounded-lg border border-violet/20 bg-background/50 px-3 py-2">
                      <span className="inline-block h-2 w-2 rounded-full bg-violet animate-pulse" />
                      <span className="text-sm font-medium truncate flex-1">
                        {task.title.replace("[Dispatch] ", "")}
                      </span>
                      {crew && (
                        <div className="flex items-center gap-1.5 shrink-0">
                          <img src={crew.avatar} alt={crew.name} className="h-4 w-4 rounded object-cover" />
                          <span className="text-[10px] text-muted-foreground">{crew.name}</span>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Up Next */}
          {backlogTasks.length > 0 && (
            <div className="rounded-xl border border-border/40 bg-card/30 p-4">
              <div className="flex items-center gap-2 mb-3">
                <Clock className="h-4 w-4 text-muted-foreground" />
                <span className="font-mono text-[10px] tracking-[0.2em] text-muted-foreground uppercase">Up Next</span>
                <span className="ml-auto rounded-full bg-muted px-1.5 py-0.5 font-mono text-[10px] text-muted-foreground">
                  {backlogTasks.length}
                </span>
              </div>
              <div className="space-y-2">
                {backlogTasks.slice(0, 5).map((task) => {
                  const crew = CREW.find((c) => c.id === task.assignee);
                  return (
                    <div key={task.id} className="flex items-center gap-2 rounded-lg border border-border/30 bg-background/30 px-3 py-2">
                      <span className="text-sm text-muted-foreground truncate flex-1">
                        {task.title.replace("[Dispatch] ", "")}
                      </span>
                      {crew && (
                        <div className="flex items-center gap-1.5 shrink-0">
                          <img src={crew.avatar} alt={crew.name} className="h-4 w-4 rounded object-cover opacity-60" />
                          <span className="text-[10px] text-muted-foreground/60">{crew.name}</span>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Activity timeline */}
      {events.length === 0 ? (
        <EmptyCameo
          icon="🌌"
          message="Quiet shift. Even the stars are taking a break."
          hint="NO RECENT ACTIVITY"
        />
      ) : (
        <div className="relative">
          {/* Timeline line */}
          <div className="absolute left-[19px] top-0 bottom-0 w-px bg-border" />

          <div className="space-y-1">
            {events.map((event) => {
              const config = TYPE_CONFIG[event.type] || TYPE_CONFIG.system;
              return (
                <div key={event.id} className="relative flex items-start gap-4 py-3">
                  {/* Icon */}
                  <div className={`relative z-10 flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-card border border-border ${config.color}`}>
                    {config.icon}
                  </div>

                  {/* Content */}
                  <div className="flex-1 min-w-0 pt-1">
                    <div className="text-sm">{event.message}</div>
                    <div className="mt-0.5 flex items-center gap-2 text-xs text-muted-foreground">
                      <span>{formatTime(event.ts)}</span>
                      {event.actor && (
                        <>
                          <span>·</span>
                          <span>{event.actor}</span>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </>
  );
}
