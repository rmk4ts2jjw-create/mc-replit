import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { PageHeader, Pill, EmptyCameo } from "@/components/PageHeader";
import { IncidentDetailsDrawer } from "@/components/IncidentDetailsDrawer";
import { getIncidents } from "@/lib/server-data";
import type { Incident } from "@/lib/server-data-types";
import { CREW } from "@/lib/crew";
import { AlertTriangle, CheckCircle, Clock, ShieldAlert, Zap } from "lucide-react";

export const Route = createFileRoute("/incidents")({
  head: () => ({ meta: [{ title: "Incidents & Alerts — Mission Control" }] }),
  loader: async () => {
    return await getIncidents();
  },
  component: IncidentsPage,
});

const SEVERITY_CONFIG: Record<string, { color: string; icon: typeof AlertTriangle; label: string }> = {
  P1: { color: "border-l-destructive bg-destructive/5", icon: ShieldAlert, label: "CRITICAL" },
  P2: { color: "border-l-warning bg-warning/5", icon: AlertTriangle, label: "HIGH" },
  P3: { color: "border-l-violet bg-violet/5", icon: Zap, label: "ELEVATED" },
  P4: { color: "border-l-border bg-card/30", icon: Clock, label: "LOW" },
};

const STATUS_CONFIG: Record<string, { color: string; label: string }> = {
  TRIAGE: { color: "bg-warning/15 text-warning border-warning/30", label: "TRIAGE" },
  MITIGATING: { color: "bg-violet/15 text-violet border-violet/30", label: "INVESTIGATING" },
  RESOLVED: { color: "bg-online/15 text-online border-online/30", label: "RESOLVED" },
};

function IncidentsPage() {
  const INCIDENTS = Route.useLoaderData() as Incident[];
  const [selected, setSelected] = useState<Incident | null>(null);
  const [drawerOpen, setDrawerOpen] = useState(false);

  const open = INCIDENTS.filter((i) => i.status !== "RESOLVED").length;
  const critical = INCIDENTS.filter((i) => i.severity === "P1" && i.status !== "RESOLVED").length;

  function handleClick(inc: Incident) {
    setSelected(inc);
    setDrawerOpen(true);
  }

  function timeAgo(ts: string): string {
    const d = new Date(ts);
    const now = new Date();
    const diff = now.getTime() - d.getTime();
    if (diff < 60000) return "just now";
    if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
    if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`;
    return d.toLocaleDateString("en-GB", { day: "numeric", month: "short" });
  }

  return (
    <>
      <PageHeader
        icon="⚠"
        title="Incidents & Alerts"
        meta={`${INCIDENTS.length} tracked · ${open} open${critical > 0 ? ` · ${critical} critical` : ""}`}
      />

      {INCIDENTS.length === 0 ? (
        <EmptyCameo
          icon="🛡️"
          message="All systems nominal. Life Support is bored (that's a good thing)."
          hint="NO OPEN INCIDENTS"
        />
      ) : (
        <div className="space-y-3">
          {INCIDENTS.map((inc) => {
            const owner = CREW.find((c) => c.id === inc.owner);
            const sev = SEVERITY_CONFIG[inc.severity] || SEVERITY_CONFIG.P4;
            const stat = STATUS_CONFIG[inc.status] || STATUS_CONFIG.TRIAGE;
            const SevIcon = sev.icon;
            const completedActions = inc.actions?.filter((a) => a.status === "completed").length || 0;
            const totalActions = inc.actions?.length || 0;
            const isStale = inc.lastActivity && (Date.now() - new Date(inc.lastActivity).getTime()) > 3600000;

            return (
              <button
                key={inc.id}
                type="button"
                onClick={() => handleClick(inc)}
                className={`w-full text-left rounded-xl border border-border bg-card/60 border-l-4 p-4 transition-colors hover:bg-card/80 cursor-pointer focus:outline-none focus:ring-2 focus:ring-violet/40 focus:ring-offset-2 focus:ring-offset-background ${sev.color}`}
              >
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <SevIcon className="h-3.5 w-3.5 text-muted-foreground" />
                      <span className="font-mono text-[11px] text-muted-foreground tracking-wider">{inc.id}</span>
                      <span className={`inline-flex items-center rounded-full border px-1.5 py-0.5 font-mono text-[8px] uppercase tracking-wider ${inc.severity === "P1" ? "border-destructive/50 bg-destructive/10 text-destructive animate-pulse" : inc.severity === "P2" ? "border-warning/50 bg-warning/10 text-warning" : "border-violet/40 bg-violet/10 text-violet"}`}>
                        {inc.severity}
                      </span>
                      <span className={`inline-flex items-center rounded-full border px-1.5 py-0.5 font-mono text-[8px] uppercase tracking-wider ${stat.color}`}>
                        {stat.label}
                      </span>
                      {inc.acknowledged && (
                        <CheckCircle className="h-3 w-3 text-online" />
                      )}
                      {isStale && inc.status !== "RESOLVED" && (
                        <span className="inline-flex items-center gap-1 rounded-full border border-warning/30 bg-warning/10 px-1.5 py-0.5 font-mono text-[8px] text-warning">
                          <Clock className="h-2.5 w-2.5" /> STALE
                        </span>
                      )}
                    </div>
                    <h3 className="mt-1 text-sm font-semibold text-foreground">{inc.title}</h3>
                  </div>
                  <div className="text-right shrink-0">
                    <div className="font-mono text-[11px] text-muted-foreground tracking-wider">opened {timeAgo(inc.opened)}</div>
                    {inc.lastActivity && inc.status !== "RESOLVED" && (
                      <div className="font-mono text-[10px] text-muted-foreground/60">last activity {timeAgo(inc.lastActivity)}</div>
                    )}
                    {owner && (
                      <div className="mt-1 flex items-center gap-2 justify-end">
                        <img src={owner.avatar} alt={owner.name} className="h-5 w-5 rounded" />
                        <span className="font-mono text-[11px] text-foreground/80">{owner.name}</span>
                      </div>
                    )}
                  </div>
                </div>
                <p className="mt-3 text-sm text-foreground/85 leading-relaxed line-clamp-2">{inc.summary}</p>
                <div className="mt-3 flex flex-wrap items-center gap-3">
                  <div className="flex flex-wrap gap-1.5">
                    {inc.tags?.slice(0, 3).map((t: string) => (
                      <Pill key={t}>#{t}</Pill>
                    ))}
                    {inc.tags && inc.tags.length > 3 && (
                      <span className="font-mono text-[10px] text-muted-foreground">+{inc.tags.length - 3}</span>
                    )}
                  </div>
                  {totalActions > 0 && (
                    <span className="ml-auto font-mono text-[10px] text-muted-foreground">
                      {completedActions}/{totalActions} actions
                    </span>
                  )}
                </div>
              </button>
            );
          })}
        </div>
      )}

      <IncidentDetailsDrawer
        incident={selected}
        open={drawerOpen}
        onOpenChange={setDrawerOpen}
      />
    </>
  );
}
