import { createFileRoute } from "@tanstack/react-router";
import { PageHeader, Pill } from "@/components/PageHeader";
import { getAgentStatus, getSystemStats } from "@/lib/server-data";
import type { AgentStatus, SystemStats } from "@/lib/server-data-types";
import { CREW, MISSION_STATEMENT } from "@/lib/crew";

export const Route = createFileRoute("/team")({
  head: () => ({ meta: [{ title: "Team — Mission Control" }] }),
  loader: async () => {
    const [agents, stats] = await Promise.all([getAgentStatus(), getSystemStats()]);
    return { agents, stats };
  },
  component: TeamPage,
});

const statusVariant: Record<string, "online" | "warning" | "default"> = {
  active: "online",
  standby: "warning",
  error: "default",
};

const statusDot: Record<string, string> = {
  active: "online",
  standby: "warning",
  error: "error",
};

function TeamPage() {
  const { agents, stats } = Route.useLoaderData() as { agents: AgentStatus[]; stats: SystemStats };

  return (
    <>
      <PageHeader icon="👥" title="Team" meta={`${agents.filter((a) => a.status === "active").length} active · ${agents.length} total`}>
        {MISSION_STATEMENT}
      </PageHeader>

      {/* System Stats Bar */}
      <div className="mb-6 rounded-xl border border-border bg-card/40 p-4">
        <div className="font-mono text-[10px] tracking-[0.25em] text-muted-foreground mb-3">SYSTEM STATUS</div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Stat label="MODEL" value={stats.model.split("/").pop() || stats.model} />
          <Stat label="CRONS" value={`${stats.activeCrons}/${stats.totalCrons} active`} />
          <Stat label="GATEWAY" value={stats.gatewayStatus} accent="online" />
          <Stat label="WORKSPACE" value={`${stats.workspaceFiles} files`} />
        </div>
      </div>

      {/* Agent Cards */}
      <div className="grid gap-4 md:grid-cols-2">
        {agents.map((agent) => {
          const crew = CREW.find((c) => c.id === agent.id);
          return (
            <div
              key={agent.id}
              className="rounded-xl border border-border bg-card/60 p-5"
            >
              <div className="flex items-start gap-4">
                {crew && (
                  <img
                    src={crew.avatar}
                    alt={agent.name}
                    className="h-14 w-14 rounded-lg border border-border object-cover pixelated"
                  />
                )}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="font-bold text-lg">{agent.emoji} {agent.name}</h3>
                    <Pill variant={statusVariant[agent.status]}>{agent.status}</Pill>
                  </div>
                  <div className="font-mono text-xs text-muted-foreground mt-0.5">{agent.role}</div>
                  <div className="mt-3 grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <span className="text-muted-foreground">model: </span>
                      <span className="font-mono">{agent.model.split("/").pop()}</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">last active: </span>
                      <span className="font-mono">{agent.lastActive}</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">active tasks: </span>
                      <span className="font-mono">{agent.tasksActive}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <span className={`status-dot ${statusDot[agent.status]}`} />
                      <span className="text-muted-foreground">{agent.status}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </>
  );
}

function Stat({ label, value, accent }: { label: string; value: string; accent?: string }) {
  return (
    <div>
      <div className="font-mono text-[10px] tracking-[0.2em] text-muted-foreground">{label}</div>
      <div className={`mt-1 font-mono text-sm ${accent ? `text-[oklch(0.88_0.18_145)]` : "text-foreground"}`}>{value}</div>
    </div>
  );
}
