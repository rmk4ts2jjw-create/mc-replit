import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { useEffect } from "react";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";

import appCss from "../styles.css?url";
import { AppSidebar } from "@/components/AppSidebar";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <div className="text-5xl mb-3 opacity-70">🚪</div>
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold text-foreground">
          This corridor doesn't exist
        </h2>
        <p className="mt-2 text-sm text-muted-foreground">
          Space Monkey suggests turning back. The page you're looking for isn't on the station map.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Return to Mission Control
          </Link>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <div className="relative inline-flex items-center justify-center mb-3">
          <span className="absolute inset-0 rounded-full bg-destructive/20 animate-pulse blur-xl" />
          <span className="relative text-5xl">📡</span>
        </div>
        <h1 className="text-xl font-semibold tracking-tight text-foreground">
          Houston, we have a problem
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Sensors offline. Life Support is investigating. Try a reload, or head back to the bridge.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button
            onClick={() => {
              router.invalidate();
              reset();
            }}
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Try again
          </button>
          <a
            href="/"
            className="inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent"
          >
            Go home
          </a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "Mission Control — OpenClaw" },
      { name: "description", content: "Mission Control: real-time visibility into an OpenClaw AI agent operation." },
      { name: "author", content: "OpenClaw" },
      { property: "og:title", content: "Mission Control — OpenClaw" },
      { property: "og:description", content: "Real-time visibility into an OpenClaw AI agent operation." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "twitter:site", content: "@Lovable" },
    ],
    links: [
      {
        rel: "stylesheet",
        href: appCss,
      },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

import { BUILD_HASH, getBuildLabel } from "@/lib/build-info";

function RootComponent() {
  const router = useRouter();
  // Auto‑refresh the whole app every 60 seconds (data‑driven pages)
  // Pages with live data (Agent Office, Dashboard) poll independently at 10s
  useEffect(() => {
    const id = setInterval(() => {
      router.invalidate();
    }, 60000);
    return () => clearInterval(id);
  }, [router]);
  const { queryClient } = Route.useRouteContext();

  return (
    <QueryClientProvider client={queryClient}>
      <div className="min-h-screen flex w-full">
        <AppSidebar />
        <main className="flex-1 min-w-0">
          <div key={router.state.location.pathname} className="mx-auto max-w-[1650px] px-6 py-8 md:px-10 md:py-10 page-transition">
            <Outlet />
          </div>
          {/* Build version footer */}
          <div className="mx-auto max-w-[1650px] px-6 pb-4 md:px-10">
            <div className="border-t border-border/30 pt-3 flex items-center justify-between">
              <span className="font-mono text-[8px] text-muted-foreground/40 tracking-wider">
                BUILD {BUILD_HASH}
              </span>
              <span className="font-mono text-[8px] text-muted-foreground/40 tracking-wider">
                {getBuildLabel()}
              </span>
            </div>
          </div>
        </main>
      </div>
    </QueryClientProvider>
  );
}
