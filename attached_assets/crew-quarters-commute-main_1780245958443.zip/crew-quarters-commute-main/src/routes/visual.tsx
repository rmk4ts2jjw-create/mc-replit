// src/routes/visual.tsx
// Agent Office — the living, animated station view

import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/PageHeader";
import { AgentOffice } from "@/components/AgentOffice";
import { getAgentStatus, getSystemStats, getIncidents } from "@/lib/server-data";

export const Route = createFileRoute("/visual")({
  head: () => ({ meta: [{ title: "Agent Office — Mission Control" }] }),
  loader: async () => {
    const [agents, stats, incidents] = await Promise.all([
      getAgentStatus(),
      getSystemStats(),
      getIncidents(),
    ]);
    return { agents, stats, incidents };
  },
  component: VisualPage,
});

function VisualPage() {
  const { agents, stats, incidents } = Route.useLoaderData();
  return (
    <>
      <PageHeader
        icon="🎮"
        title="Agent Office"
        right={
          <span className="font-mono text-xs text-muted-foreground">
            Live pixel-art station view
          </span>
        }
      >
        A persistent orbital workspace where the AI crew works, collaborates, and maintains the station in real time.
      </PageHeader>

      <AgentOffice
        initialAgents={agents}
        initialStats={stats}
        initialIncidents={incidents}
      />
    </>
  );
}
