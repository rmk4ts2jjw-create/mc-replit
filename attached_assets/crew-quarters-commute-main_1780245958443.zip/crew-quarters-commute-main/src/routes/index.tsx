import { createFileRoute } from "@tanstack/react-router";
import { Dashboard } from "@/components/Dashboard";
import { getSystemStats, getAgentStatus, getActivityFeed } from "@/lib/server-data";
import type { ActivityEvent } from "@/lib/server-data-types";

export const Route = createFileRoute("/")({
  head: () => ({ meta: [{ title: "Mission Control — Dashboard" }] }),
  loader: async () => {
    const [stats, agents] = await Promise.all([
      getSystemStats(),
      getAgentStatus(),
    ]);
    let activity: ActivityEvent[] = [];
    try { activity = await getActivityFeed(); } catch { /* ignore */ }

    return { agents, stats, activity };
  },
  component: HomePage,
});

function HomePage() {
  const { agents, stats, activity } = Route.useLoaderData();
  return (
    <Dashboard
      agents={agents}
      systemStats={stats}
      activity={activity}
    />
  );
}
