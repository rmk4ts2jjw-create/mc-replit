import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { PageHeader, Pill } from "@/components/PageHeader";
import { useCronData } from "@/components/scheduler/useCronData";
import type { CronError } from "@/components/scheduler/useCronData";
import { CronJobCard } from "@/components/scheduler/CronJobCard";
import { Power, Clock, AlertTriangle, CheckCircle, Loader2, Play, SkipForward, CheckCircle2, RotateCcw } from "lucide-react";

export const Route = createFileRoute("/scheduler")({
  head: () => ({ meta: [{ title: "Scheduler — Mission Control" }] }),
  component: SchedulerPage,
});

// ── Main Page ────────────────────────────────────────────────────────────────

type Tab = "jobs" | "errors";

function SchedulerPage() {
  const [activeTab, setActiveTab] = useState<Tab>("jobs");
  const {
    jobs,
    errors,
    loading,
    toggling,
    result,
    handleToggle,
    updateErrorStatus,
  } = useCronData();

  const enabledCount = jobs.filter((j) => j.enabled).length;
  const errorCount = errors.filter((e) => e.status === "new" || e.status === "in_progress").length;
  const unresolvedErrors = errors.filter((e) => e.status === "new" || e.status === "in_progress").length;

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <>
      <PageHeader icon="📅" title="Scheduler" meta={`${jobs.length} jobs · ${enabledCount} active · ${errorCount} errors`}>
        All scheduled automation for the station. Toggle jobs on or off.
      </PageHeader>

      {/* Tabs */}
      <div className="flex items-center gap-1 mb-6 border-b border-border">
        <button
          onClick={() => setActiveTab("jobs")}
          className={`px-4 py-2.5 text-sm font-medium transition-colors border-b-2 -mb-px ${
            activeTab === "jobs"
              ? "border-violet text-foreground"
              : "border-transparent text-muted-foreground hover:text-foreground"
          }`}
        >
          Cron Jobs
          <span className="ml-2 rounded-full bg-muted px-1.5 py-0.5 text-[10px]">{jobs.length}</span>
        </button>
        <button
          onClick={() => setActiveTab("errors")}
          className={`px-4 py-2.5 text-sm font-medium transition-colors border-b-2 -mb-px ${
            activeTab === "errors"
              ? "border-violet text-foreground"
              : "border-transparent text-muted-foreground hover:text-foreground"
          }`}
        >
          Error Feed
          {unresolvedErrors > 0 && (
            <span className="ml-2 rounded-full bg-warning/20 text-warning px-1.5 py-0.5 text-[10px]">
              {unresolvedErrors}
            </span>
          )}
        </button>
      </div>

      {activeTab === "jobs" && (
        <JobsTab
          jobs={jobs}
          errors={errors}
          toggling={toggling}
          result={result}
          onToggle={handleToggle}
        />
      )}

      {activeTab === "errors" && (
        <ErrorsTab
          errors={errors}
          onUpdateStatus={updateErrorStatus}
        />
      )}
    </>
  );
}

// ── Jobs Tab ─────────────────────────────────────────────────────────────────

type JobFilter = "all" | "active" | "disabled" | "errors";

function JobsTab({
  jobs,
  errors,
  toggling,
  result,
  onToggle,
}: {
  jobs: ReturnType<typeof useCronData>["jobs"];
  errors: CronError[];
  toggling: string | null;
  result: { id: string; message: string } | null;
  onToggle: (job: any) => void;
}) {
  const [filter, setFilter] = useState<JobFilter>("all");
  const enabledCount = jobs.filter((j) => j.enabled).length;
  const disabledCount = jobs.length - enabledCount;
  // Only count jobs that have an active unresolved error in the Error Feed
  const activeErrorJobIds = new Set(
    errors
      .filter((e) => e.status === "new" || e.status === "in_progress")
      .map((e) => e.jobId)
  );
  const errorCount = jobs.filter((j) => activeErrorJobIds.has(j.id)).length;

  const filteredJobs = jobs.filter((j) => {
    if (filter === "active") return j.enabled;
    if (filter === "disabled") return !j.enabled;
    if (filter === "errors") return activeErrorJobIds.has(j.id);
    return true;
  });

  const filterBtn = (f: JobFilter, label: string, count: number, activeColor: string) => (
    <button
      onClick={() => setFilter(f)}
      className={`flex items-center gap-1.5 rounded-md px-2.5 py-1 text-xs transition-colors ${
        filter === f
          ? `${activeColor} border`
          : "text-muted-foreground hover:text-foreground border border-transparent"
      }`}
    >
      {label}
      <span className="font-mono text-[10px]">{count}</span>
    </button>
  );

  return (
    <>
      {/* Filter bar */}
      <div className="flex items-center gap-2 mb-4 flex-wrap">
        {filterBtn("all", "All", jobs.length, "bg-muted text-foreground")}
        {filterBtn("active", "Active", enabledCount, "bg-[oklch(0.88_0.18_145)]/10 text-[oklch(0.88_0.18_145)] border-[oklch(0.88_0.18_145)]/30")}
        {filterBtn("disabled", "Disabled", disabledCount, "bg-muted text-foreground")}
        {filterBtn("errors", "Errors", errorCount, "bg-warning/10 text-warning border-warning/30")}
      </div>

      {/* Summary bar */}
      <div className="flex items-center gap-4 mb-4">
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <CheckCircle className="h-3.5 w-3.5 text-[oklch(0.88_0.18_145)]" />
          <span>{enabledCount} active</span>
        </div>
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <Power className="h-3.5 w-3.5 text-muted-foreground/50" />
          <span>{disabledCount} disabled</span>
        </div>
        {errorCount > 0 && (
          <div className="flex items-center gap-2 text-xs text-warning">
            <AlertTriangle className="h-3.5 w-3.5" />
            <span>{errorCount} error{errorCount > 1 ? "s" : ""}</span>
          </div>
        )}
      </div>

      {filteredJobs.length === 0 ? (
        <div className="rounded-xl border border-dashed border-border/80 bg-card/30 px-6 py-14 text-center">
          <div className="font-mono text-xs tracking-[0.25em] text-muted-foreground">— NO JOBS —</div>
          <div className="mt-3 text-sm text-muted-foreground">{filter !== "all" ? `No ${filter} jobs.` : "No cron jobs configured."}</div>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredJobs.map((job) => {
            const isToggling = toggling === job.id;
            const hasResult = result?.id === job.id;
            const hasActiveError = activeErrorJobIds.has(job.id);
            return (
              <CronJobCard
                key={job.id}
                job={job}
                isToggling={isToggling}
                hasResult={hasResult}
                resultMessage={hasResult ? result?.message ?? null : null}
                hasActiveError={hasActiveError}
                onToggle={onToggle}
              />
            );
          })}
        </div>
      )}
    </>
  );
}

// ── Errors Tab ───────────────────────────────────────────────────────────────

function ErrorsTab({
  errors,
  onUpdateStatus,
}: {
  errors: CronError[];
  onUpdateStatus: (errorId: string, status: CronError["status"]) => void;
}) {
  if (errors.length === 0) {
    return (
      <div className="rounded-xl border border-dashed border-border/80 bg-card/30 px-6 py-14 text-center">
        <div className="font-mono text-xs tracking-[0.25em] text-muted-foreground">— NO ERRORS —</div>
        <div className="mt-3 text-sm text-muted-foreground">All cron jobs running smoothly.</div>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {errors.map((error) => {
        const isNew = error.status === "new";
        const isInProgress = error.status === "in_progress";

        return (
          <div
            key={error.id}
            className={`rounded-xl border bg-card/60 px-5 py-4 transition-all ${
              isInProgress
                ? "border-violet/40 bg-violet/5"
                : "border-warning/40 bg-warning/5"
            }`}
          >
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <AlertTriangle className={`h-4 w-4 ${isInProgress ? "text-violet" : "text-warning"}`} />
                  <h3 className="font-semibold">{error.jobName}</h3>
                  <Pill variant={error.jobEnabled ? "online" : "default"}>
                    {error.jobEnabled ? "ACTIVE" : "DISABLED"}
                  </Pill>
                  {isNew && <Pill variant="warning">NEW ERROR</Pill>}
                  {isInProgress && <Pill variant="violet">INVESTIGATING</Pill>}
                  <span className="font-mono text-[10px] text-warning">
                    {error.consecutiveErrors} consecutive error{error.consecutiveErrors > 1 ? "s" : ""}
                  </span>
                </div>

                <div className="mt-2 rounded-lg border border-border/40 bg-background/50 px-3 py-2">
                  <div className="font-mono text-[10px] text-muted-foreground mb-1">Error</div>
                  <div className="text-xs text-destructive font-mono break-all">{error.lastError}</div>
                  {error.lastErrorReason && (
                    <div className="text-[10px] text-muted-foreground mt-1">Reason: {error.lastErrorReason}</div>
                  )}
                </div>

                <div className="mt-2 flex items-center gap-4 font-mono text-[10px] text-muted-foreground/50">
                  {error.lastRunAt !== "—" && (
                    <span>Last run: {new Date(error.lastRunAt).toLocaleString("en-GB", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" })}</span>
                  )}
                </div>
              </div>
            </div>

            {/* Action buttons — clear, non-confusing labels */}
            <div className="mt-3 flex items-center gap-2 flex-wrap">
              {isNew && (
                <>
                  <button
                    onClick={() => onUpdateStatus(error.id, "in_progress")}
                    className="inline-flex items-center gap-1.5 rounded-md bg-violet px-3 py-1.5 text-xs font-medium text-primary-foreground transition-colors hover:bg-violet/90"
                  >
                    <Play className="h-3 w-3" />
                    Investigate
                  </button>
                  <button
                    onClick={() => onUpdateStatus(error.id, "completed")}
                    className="inline-flex items-center gap-1.5 rounded-md border border-[oklch(0.88_0.18_145)]/40 bg-[oklch(0.88_0.18_145)]/10 px-3 py-1.5 text-xs font-medium text-[oklch(0.88_0.18_145)] transition-colors hover:bg-[oklch(0.88_0.18_145)]/20"
                  >
                    <CheckCircle2 className="h-3 w-3" />
                    Mark Resolved
                  </button>
                  <button
                    onClick={() => onUpdateStatus(error.id, "skipped")}
                    className="inline-flex items-center gap-1.5 rounded-md border border-border bg-background px-3 py-1.5 text-xs text-muted-foreground transition-colors hover:text-foreground"
                  >
                    <SkipForward className="h-3 w-3" />
                    Skip
                  </button>
                </>
              )}
              {isInProgress && (
                <>
                  <button
                    onClick={() => onUpdateStatus(error.id, "completed")}
                    className="inline-flex items-center gap-1.5 rounded-md bg-[oklch(0.88_0.18_145)] px-3 py-1.5 text-xs font-medium text-primary-foreground transition-colors hover:bg-[oklch(0.88_0.18_145)]/90"
                  >
                    <CheckCircle2 className="h-3 w-3" />
                    Mark Resolved
                  </button>
                  <button
                    onClick={() => onUpdateStatus(error.id, "new")}
                    className="inline-flex items-center gap-1.5 rounded-md border border-border bg-background px-3 py-1.5 text-xs text-muted-foreground transition-colors hover:text-foreground"
                  >
                    <RotateCcw className="h-3 w-3" />
                    Undo
                  </button>
                </>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}
