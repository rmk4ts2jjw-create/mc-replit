// src/lib/dreaming.ts
// Dreaming (memory consolidation) toggle for Quick Actions

import { createServerFn } from "@tanstack/react-start";
import { readFileSync, writeFileSync, existsSync } from "node:fs";
import { join } from "node:path";

const WORKSPACE = process.env.OPENCLAW_WORKSPACE || "/Users/spacemonkey/.openclaw/workspace";
const DREAMING_FLAG = join(WORKSPACE, "data", "dreaming-enabled.flag");

export const getDreamingState = createServerFn({ method: "GET" }).handler(async () => {
  try {
    const enabled = existsSync(DREAMING_FLAG);
    return { ok: true, enabled };
  } catch (err) {
    return { ok: false, enabled: false, error: String(err) };
  }
});

export const toggleDreaming = createServerFn({ method: "POST" }).handler(async () => {
  try {
    const currentlyEnabled = existsSync(DREAMING_FLAG);
    if (currentlyEnabled) {
      // Disable dreaming — remove the flag
      const { unlinkSync } = await import("node:fs");
      try { unlinkSync(DREAMING_FLAG); } catch { /* already gone */ }
      return { ok: true, enabled: false, message: "Dreaming disabled" };
    } else {
      // Enable dreaming — create the flag
      writeFileSync(DREAMING_FLAG, new Date().toISOString(), "utf-8");
      return { ok: true, enabled: true, message: "Dreaming enabled" };
    }
  } catch (err) {
    return { ok: false, enabled: false, message: String(err) };
  }
});
