// src/lib/server-data/tasks.ts

import { createServerFn } from "@tanstack/react-start";
import { readFileSync, writeFileSync, renameSync } from "node:fs";
import { join } from "node:path";
import { WORKSPACE, type Task, type QueueItem } from "./types";
import { readJsonOrNull } from "./helpers";

// ── Tasks ──────────────────────────────────────────────────────────────────────

export const getTasks = createServerFn({ method: "GET" }).handler(async () => {
  const data = readJsonOrNull<Task[]>(join(WORKSPACE, "data", "tasks.json"));
  return data ?? [];
});

export const saveTasks = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => d as Task[])
  .handler(async ({ data: tasks }) => {
    const path = join(WORKSPACE, "data", "tasks.json");
    console.log("[saveTasks] Writing", tasks.length, "tasks to", path);
    const tmpPath = path + ".tmp";
    writeFileSync(tmpPath, JSON.stringify(tasks, null, 2), "utf-8");
    renameSync(tmpPath, path);
    console.log("[saveTasks] Saved successfully");
    return "ok";
  });

// ── Queue Dispatch ──────────────────────────────────────────────────────────

export const dispatchTask = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => d as { taskId: string; title: string; assignee: string })
  .handler(async ({ data }) => {
    const queuePath = join(WORKSPACE, "data", "queue.json");
    const queue = readJsonOrNull<QueueItem[]>(queuePath) || [];
    const item: QueueItem = {
      id: `q-${Date.now()}`,
      taskId: data.taskId,
      title: data.title,
      assignee: data.assignee,
      dispatchedAt: new Date().toISOString(),
      status: "pending",
    };
    queue.push(item);
    writeFileSync(queuePath, JSON.stringify(queue, null, 2), "utf-8");
    return { ok: true, queueId: item.id };
  });

export const getQueue = createServerFn({ method: "GET" }).handler(async () => {
  return readJsonOrNull<QueueItem[]>(join(WORKSPACE, "data", "queue.json")) || [];
});
