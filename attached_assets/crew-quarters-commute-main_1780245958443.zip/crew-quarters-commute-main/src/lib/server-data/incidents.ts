// src/lib/server-data/incidents.ts

import { createServerFn } from "@tanstack/react-start";
import { writeFileSync } from "node:fs";
import { join } from "node:path";
import { WORKSPACE, type Incident, type CreateIncidentInput, type IncidentEvent, type IncidentAction } from "./types";
import { readJsonOrNull } from "./helpers";

export const getIncidents = createServerFn({ method: "GET" }).handler(async () => {
  const data = readJsonOrNull<Incident[]>(join(WORKSPACE, "data", "incidents.json"));
  return data ?? [];
});

// ── Internal helpers (not exported as server fns) ─────────────────────────────

function readIncidentsList(): Incident[] {
  return readJsonOrNull<Incident[]>(join(WORKSPACE, "data", "incidents.json")) || [];
}

function writeIncidentsList(incs: Incident[]) {
  writeFileSync(join(WORKSPACE, "data", "incidents.json"), JSON.stringify(incs, null, 2), "utf-8");
}

function nextIncidentId(incs: Incident[]): string {
  const nums = incs.map(i => {
    const m = i.id.match(/INC-(\d+)/);
    return m ? parseInt(m[1]) : 0;
  });
  return `INC-${String(Math.max(0, ...nums) + 1).padStart(3, "0")}`;
}

export const createIncident = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => d as CreateIncidentInput)
  .handler(async ({ data }) => {
    const incs = readIncidentsList();
    const now = new Date().toISOString();
    const dup = incs.find(i =>
      i.status !== "RESOLVED" &&
      i.title === data.title &&
      i.tags?.includes(data.source)
    );
    if (dup) return { ok: true, id: dup.id, duplicate: true };
    const incident: Incident = {
      id: nextIncidentId(incs),
      title: data.title,
      severity: data.severity,
      status: "TRIAGE",
      owner: data.owner,
      acknowledged: false,
      escalated: false,
      opened: now,
      lastActivity: now,
      summary: data.summary,
      tags: [...data.tags, data.source],
      timeline: [
        { ts: now, message: `Auto-detected by ${data.source}`, actor: "system" },
      ],
      actions: [],
    };
    incs.unshift(incident);
    writeIncidentsList(incs);
    return { ok: true, id: incident.id };
  });
