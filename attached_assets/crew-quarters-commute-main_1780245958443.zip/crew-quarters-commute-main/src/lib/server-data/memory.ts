// src/lib/server-data/memory.ts

import { createServerFn } from "@tanstack/react-start";
import { readFileSync, existsSync, readdirSync } from "node:fs";
import { join } from "node:path";
import { WORKSPACE, type MemoryEntry } from "./types";
import { readFileOrNull, extractTitle } from "./helpers";

export const getDailyLogs = createServerFn({ method: "GET" }).handler(async () => {
  const memDir = join(WORKSPACE, "memory");
  if (!existsSync(memDir)) return [];
  const files = readdirSync(memDir)
    .filter((f) => /^\d{4}-\d{2}-\d{2}\.md$/.test(f))
    .sort()
    .reverse();
  return files.map((file) => {
    const body = readFileSync(join(memDir, file), "utf-8");
    const date = file.replace(".md", "");
    const words = body.split(/\s+/).filter(Boolean).length;
    return { date, words, title: extractTitle(body), body } as MemoryEntry;
  });
});

export const getLongTermMemory = createServerFn({ method: "GET" }).handler(async () => {
  return readFileOrNull(join(WORKSPACE, "MEMORY.md")) || "# Long-Term Memory\n\nNo long-term memory file found.";
});
