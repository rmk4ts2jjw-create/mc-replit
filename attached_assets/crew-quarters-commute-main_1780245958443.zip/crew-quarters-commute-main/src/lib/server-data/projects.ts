// src/lib/server-data/projects.ts

import { createServerFn } from "@tanstack/react-start";
import { join } from "node:path";
import { WORKSPACE, type Project } from "./types";
import { readJsonOrNull } from "./helpers";

export const getProjects = createServerFn({ method: "GET" }).handler(async () => {
  const data = readJsonOrNull<Project[]>(join(WORKSPACE, "data", "projects.json"));
  return data ?? [];
});
