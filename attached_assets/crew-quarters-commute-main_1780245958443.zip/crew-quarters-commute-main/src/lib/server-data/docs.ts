// src/lib/server-data/docs.ts

import { createServerFn } from "@tanstack/react-start";
import { readFileSync, existsSync, readdirSync, statSync } from "node:fs";
import { join } from "node:path";
import { WORKSPACE, type Doc } from "./types";
import { extractTitle } from "./helpers";

export const getDocs = createServerFn({ method: "GET" }).handler(async () => {
  const docs: Doc[] = [];
  const exclude = new Set(["AGENTS.md", "SOUL.md", "IDENTITY.md", "USER.md", "TOOLS.md", "MEMORY.md", "HEARTBEAT.md", "BACKUP_GUIDE.md", "RECOVERY_GUIDE.md"]);

  try {
    const files = readdirSync(WORKSPACE).filter((f) => f.endsWith(".md") && !exclude.has(f));
    for (const file of files) {
      const body = readFileSync(join(WORKSPACE, file), "utf-8");
      const stat = statSync(join(WORKSPACE, file));
      docs.push({
        id: `doc-${file}`,
        title: extractTitle(body),
        date: stat.mtime.toISOString().split("T")[0],
        type: "note",
        author: "Space Monkey",
        body,
      });
    }
  } catch { /* ignore */ }

  try {
    const memDir = join(WORKSPACE, "memory");
    if (existsSync(memDir)) {
      const memFiles = readdirSync(memDir).filter((f) => f.endsWith(".md") && !/^\d{4}-\d{2}-\d{2}\.md$/.test(f));
      for (const file of memFiles) {
        const body = readFileSync(join(memDir, file), "utf-8");
        const stat = statSync(join(memDir, file));
        docs.push({
          id: `doc-mem-${file}`,
          title: extractTitle(body),
          date: stat.mtime.toISOString().split("T")[0],
          type: "note",
          author: "Space Monkey",
          body,
        });
      }
    }
  } catch { /* ignore */ }

  return docs.sort((a, b) => b.date.localeCompare(a.date));
});
