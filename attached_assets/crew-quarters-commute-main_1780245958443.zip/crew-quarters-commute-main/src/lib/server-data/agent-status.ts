// src/lib/server-data/agent-status.ts

import { createServerFn } from "@tanstack/react-start";
import { join } from "node:path";
import { WORKSPACE, OPENCLAW_DIR, type AgentStatus, type Task } from "./types";
import { readJsonOrNull, readFileOrNull } from "./helpers";

export const getAgentStatus = createServerFn({ method: "GET" }).handler(async () => {
  try {
    const cfg = readJsonOrNull<Record<string, unknown>>(join(OPENCLAW_DIR, "openclaw.json"));
    const agents = cfg?.agents as Record<string, unknown> | undefined;
    const defaults = agents?.defaults as Record<string, unknown> | undefined;
    const modelConfig = defaults?.model as Record<string, unknown> | undefined;
    const currentModel = String(modelConfig?.primary || "unknown");

    const tasks = readJsonOrNull<Task[]>(join(WORKSPACE, "data", "tasks.json")) || [];
    const activeTasks = tasks.filter((t) => t.status === "in_progress");
    const countFor = (id: string) => activeTasks.filter((t) => t.assignee === id).length;
    const currentTaskFor = (id: string) => {
      const t = activeTasks.find(t => t.assignee === id);
      return t ? t.title : undefined;
    };

    return [
      {
        id: "monkey", name: "Space Monkey", role: "Mission Director", emoji: "🐒",
        status: "active" as const, model: currentModel, lastActive: "now",
        tasksActive: countFor("monkey"),
        currentAction: currentTaskFor("monkey") || "Monitoring station",
      },
      {
        id: "lifesupport", name: "Life Support Officer", role: "Infrastructure Controller", emoji: "🥷🏽",
        status: "active" as const, model: currentModel, lastActive: "5m ago",
        tasksActive: countFor("lifesupport"),
        currentAction: currentTaskFor("lifesupport") || "Monitoring systems",
      },
      {
        id: "engineer", name: "Systems Engineer", role: "Coder / Builder", emoji: "🔧",
        status: countFor("engineer") > 0 ? "active" as const : "standby" as const,
        model: currentModel, lastActive: countFor("engineer") > 0 ? "now" : "1h ago",
        tasksActive: countFor("engineer"),
        currentAction: currentTaskFor("engineer") || "Standing by",
      },
      {
        id: "archivist", name: "Station Archivist", role: "Memory & Knowledge", emoji: "📚",
        status: countFor("archivist") > 0 ? "active" as const : "standby" as const,
        model: currentModel, lastActive: countFor("archivist") > 0 ? "now" : "30m ago",
        tasksActive: countFor("archivist"),
        currentAction: currentTaskFor("archivist") || "Indexing memory sectors",
      },
    ] as AgentStatus[];
  } catch (e) {
    console.error("[getAgentStatus] ERROR:", e);
    throw e;
  }
});
