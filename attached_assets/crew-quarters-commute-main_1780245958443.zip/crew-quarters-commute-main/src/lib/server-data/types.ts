// src/lib/server-data/types.ts
// Shared types and constants for server data functions

export const WORKSPACE = process.env.OPENCLAW_WORKSPACE || "/Users/spacemonkey/.openclaw/workspace";
export const OPENCLAW_DIR = process.env.OPENCLAW_DIR || "/Users/spacemonkey/.openclaw";

// ── Task Types ────────────────────────────────────────────────────────────────

export interface Task {
  id: string;
  title: string;
  assignee: string;
  status: "backlog" | "in_progress" | "awaiting_review" | "done";
  priority: "P1" | "P2" | "P3" | "P4";
  ts: string;
  note?: string;
  lastUpdated?: string;
  startedAt?: string;
  completedAt?: string;
  progress?: number;
  tags?: string[];
  acknowledged?: boolean;
  escalationLevel?: number;
  history?: TaskHistoryEntry[];
  errorId?: string;
  jobId?: string;
  summary?: string;
}

export interface TaskHistoryEntry {
  ts: string;
  action: "created" | "dispatched" | "started" | "progress" | "stalled" | "escalated" | "completed" | "reassigned";
  actor?: string;
  details?: string;
}

// ── Queue Types ───────────────────────────────────────────────────────────────

export interface QueueItem {
  id: string;
  taskId: string;
  title: string;
  assignee: string;
  dispatchedAt: string;
  status: "pending" | "executing" | "completed" | "failed";
}

// ── Cron Types ────────────────────────────────────────────────────────────────

export interface CronJob {
  id: string;
  name: string;
  schedule: string;
  nextRun: string;
  enabled: boolean;
  description: string;
}

export interface OpenClawCronJob {
  id: string;
  name: string;
  schedule: string;
  enabled: boolean;
  status: string;
  lastRun: string;
  nextRun: string;
  message: string;
  lastError?: string;
  lastErrorReason?: string;
  consecutiveErrors?: number;
}

// ── System Stats Types ────────────────────────────────────────────────────────

export interface SystemStats {
  hostname: string;
  uptime: string;
  gatewayUptime: string;
  diskUsed: string;
  diskFree: string;
  diskTotal: string;
  diskPercent: number;
  wdDiskUsed: string;
  wdDiskTotal: string;
  wdDiskPercent: number;
  wdDiskMount: string;
  memoryUsed: string;
  memoryTotal: string;
  memoryPercent: number;
  cpuLoad: string;
  openclawVersion: string;
  model: string;
  gatewayStatus: string;
  activeCrons: number;
  totalCrons: number;
  workspaceFiles: number;
  lastBackup: string;
}

// ── Agent Status Types ────────────────────────────────────────────────────────

export interface AgentStatus {
  id: string;
  name: string;
  role: string;
  emoji: string;
  status: "active" | "standby" | "error";
  model: string;
  lastActive: string;
  tasksActive: number;
  currentAction?: string;
}

// ── Memory Types ──────────────────────────────────────────────────────────────

export interface MemoryEntry {
  date: string;
  words: number;
  title: string;
  body: string;
}

// ── Doc Types ─────────────────────────────────────────────────────────────────

export interface Doc {
  id: string;
  title: string;
  date: string;
  type: string;
  author: string;
  body: string;
}

// ── Project Types ─────────────────────────────────────────────────────────────

export interface Project {
  id: string;
  name: string;
  description: string;
  status: string;
  accent: string;
  updatedAt?: string;
  progress?: number;
  tasks?: number;
  lastActivity?: string;
  lead?: string;
}

// ── Incident Types ────────────────────────────────────────────────────────────

export interface IncidentEvent {
  ts: string;
  message: string;
  actor?: string;
}

export interface IncidentAction {
  label: string;
  description: string;
  status: "available" | "completed" | "skipped" | "in_progress";
  completedAt?: string;
  completedBy?: string;
}

export interface Incident {
  id: string;
  title: string;
  severity: "P1" | "P2" | "P3" | "P4";
  status: "TRIAGE" | "MITIGATING" | "RESOLVED";
  owner: string;
  acknowledged?: boolean;
  escalated?: boolean;
  opened: string;
  resolved?: string;
  lastActivity?: string;
  summary: string;
  tags: string[];
  timeline: IncidentEvent[];
  actions: IncidentAction[];
}

export interface CreateIncidentInput {
  title: string;
  severity: "P1" | "P2" | "P3" | "P4";
  owner: string;
  summary: string;
  tags: string[];
  source: string;
}

// ── Activity Types ────────────────────────────────────────────────────────────

export interface ActivityEvent {
  id: string;
  ts: string;
  message: string;
  type: "task" | "cron" | "system" | "memory" | "project" | "incident";
  actor?: string;
}

// ── Search Types ──────────────────────────────────────────────────────────────

export interface SearchResult {
  id: string;
  title: string;
  snippet: string;
  type: "task" | "doc" | "memory" | "project" | "incident" | "cron";
  url: string;
  date?: string;
}

// ── OpenClaw Status Types ─────────────────────────────────────────────────────

export interface OpenClawStatus {
  gateway: string;
  version: string;
  dashboard: string;
  channel: string;
  sessions: number;
  model: string;
  ctx: string;
  uptime: string;
  heartbeat: string;
  tasksActive: number;
  tasksQueued: number;
  memoryPlugin: string;
}

// ── Quick Action Result ───────────────────────────────────────────────────────

export interface ActionResult {
  ok: boolean;
  message: string;
  size?: string;
}

export interface SystemHealth {
  cpu: string;
  disk: string;
  memory: string;
  gateway: string;
}

export interface AwaitingReviewResult {
  count: number;
}

export interface CronToggleResult {
  ok: boolean;
  enabled: boolean;
}
