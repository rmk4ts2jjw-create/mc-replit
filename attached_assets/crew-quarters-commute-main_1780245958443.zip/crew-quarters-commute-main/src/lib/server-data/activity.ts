// src/lib/server-data/activity.ts

import { createServerFn } from "@tanstack/react-start";
import { readFileSync, existsSync, readdirSync, statSync } from "node:fs";
import { join } from "node:path";
import { WORKSPACE, type Task } from "./types";
import type { ActivityEvent } from "./types";
import { readJsonOrNull, extractTitle } from "./helpers";

export const getActivityFeed = createServerFn({ method: "GET" }).handler(async () => {
  const limit = 30;
  const events: ActivityEvent[] = [];

  // 1. In-progress and recently completed tasks
  const tasks = readJsonOrNull<Task[]>(join(WORKSPACE, "data", "tasks.json")) || [];
  for (const t of tasks.filter((t) => t.status === "in_progress").slice(0, 5)) {
    events.push({ id: `task-active-${t.id}`, ts: t.startedAt || t.ts, message: `Working: ${t.title}`, type: "task", actor: t.assignee });
  }
  for (const t of tasks.filter((t) => t.status === "done" && t.completedAt).slice(-5).reverse()) {
    events.push({ id: `task-done-${t.id}`, ts: t.completedAt!, message: `Completed: ${t.title}`, type: "task", actor: t.assignee });
  }

  // 2. Open incidents
  const incidents = readJsonOrNull<Record<string, unknown>[]>(join(WORKSPACE, "data", "incidents.json")) || [];
  for (const inc of incidents.filter((i) => i.status !== "RESOLVED").slice(0, 3)) {
    events.push({ id: `inc-${inc.id}`, ts: String(inc.updatedAt || inc.createdAt || new Date().toISOString()), message: `Incident: ${inc.title || inc.id}`, type: "incident", actor: String(inc.assignee || "system") });
  }

  // 3. Cron errors
  const cronErrors = readJsonOrNull<Record<string, unknown>[]>(join(WORKSPACE, "data", "cron-errors.json")) || [];
  for (const ce of cronErrors.filter((e) => e.status !== "completed").slice(0, 3)) {
    events.push({ id: `cron-err-${ce.id}`, ts: String(ce.createdAt || new Date().toISOString()), message: `Cron error: ${ce.jobName || ce.jobId} (${ce.consecutiveErrors}x)`, type: "cron", actor: "system" });
  }

  // 4. Recent daily logs
  const memDir = join(WORKSPACE, "memory");
  if (existsSync(memDir)) {
    const memFiles = readdirSync(memDir).filter((f) => /^\d{4}-\d{2}-\d{2}\.md$/.test(f)).sort().reverse().slice(0, 3);
    for (const file of memFiles) {
      const stat = statSync(join(memDir, file));
      events.push({ id: `mem-${file}`, ts: stat.mtime.toISOString(), message: `Log: ${extractTitle(readFileSync(join(memDir, file), "utf-8").slice(0, 80))}`, type: "memory", actor: "Space Monkey" });
    }
  }

  events.sort((a, b) => new Date(b.ts).getTime() - new Date(a.ts).getTime());
  return events.slice(0, limit) as ActivityEvent[];
});
