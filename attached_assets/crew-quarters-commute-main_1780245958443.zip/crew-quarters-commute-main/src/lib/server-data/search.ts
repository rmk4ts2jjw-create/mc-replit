// src/lib/server-data/search.ts

import { createServerFn } from "@tanstack/react-start";
import { readFileSync, existsSync, readdirSync } from "node:fs";
import { join } from "node:path";
import { WORKSPACE, OPENCLAW_DIR, type Task, type Project, type Incident, type SearchResult } from "./types";
import { readJsonOrNull, extractTitle } from "./helpers";

export const search = createServerFn({ method: "GET" })
  .inputValidator((d: unknown) => d as { query: string })
  .handler(async ({ data }) => {
    const q = data.query.toLowerCase().trim();
    if (!q) return [] as SearchResult[];
    const results: SearchResult[] = [];

    const tasks = readJsonOrNull<Task[]>(join(WORKSPACE, "data", "tasks.json")) || [];
    for (const t of tasks) {
      if (t.title.toLowerCase().includes(q) || t.id.toLowerCase().includes(q) || (t.note && t.note.toLowerCase().includes(q))) {
        results.push({ id: t.id, title: t.title, snippet: t.note || t.status, type: "task", url: "/tasks" });
      }
    }

    const projects = readJsonOrNull<Project[]>(join(WORKSPACE, "data", "projects.json")) || [];
    for (const p of projects) {
      if (p.name.toLowerCase().includes(q) || p.description.toLowerCase().includes(q)) {
        results.push({ id: p.id, title: p.name, snippet: p.description, type: "project", url: "/projects" });
      }
    }

    const incidents = readJsonOrNull<Incident[]>(join(WORKSPACE, "data", "incidents.json")) || [];
    for (const inc of incidents) {
      if (inc.title.toLowerCase().includes(q) || inc.summary.toLowerCase().includes(q)) {
        results.push({ id: inc.id, title: inc.title, snippet: inc.summary, type: "incident", url: "/incidents" });
      }
    }

    const memDir = join(WORKSPACE, "memory");
    if (existsSync(memDir)) {
      const memFiles = readdirSync(memDir).filter((f) => /^\d{4}-\d{2}-\d{2}\.md$/.test(f));
      for (const file of memFiles) {
        const body = readFileSync(join(memDir, file), "utf-8");
        const title = extractTitle(body);
        if (title.toLowerCase().includes(q) || body.toLowerCase().includes(q)) {
          const snippet = body.split("\n").find((l) => l.toLowerCase().includes(q) && !l.startsWith("#"))?.trim() || "";
          results.push({ id: file, title, snippet: snippet.slice(0, 120), type: "memory", url: "/memory", date: file.replace(".md", "") });
        }
      }
    }

    const exclude = new Set(["AGENTS.md", "SOUL.md", "IDENTITY.md", "USER.md", "TOOLS.md", "MEMORY.md", "HEARTBEAT.md", "BACKUP_GUIDE.md", "RECOVERY_GUIDE.md"]);
    const docFiles = readdirSync(WORKSPACE).filter((f) => f.endsWith(".md") && !exclude.has(f));
    for (const file of docFiles) {
      const body = readFileSync(join(WORKSPACE, file), "utf-8");
      const title = extractTitle(body);
      if (title.toLowerCase().includes(q) || body.toLowerCase().includes(q)) {
        const snippet = body.split("\n").find((l) => l.toLowerCase().includes(q) && !l.startsWith("#"))?.trim() || "";
        results.push({ id: file, title, snippet: snippet.slice(0, 120), type: "doc", url: "/docs" });
      }
    }

    const cfg = readJsonOrNull<Record<string, unknown>>(join(OPENCLAW_DIR, "openclaw.json"));
    if (cfg && Array.isArray(cfg.cron)) {
      for (const job of cfg.cron as Record<string, unknown>[]) {
        const name = String(job.name || job.schedule || "");
        if (name.toLowerCase().includes(q)) {
          results.push({ id: String(job.id || ""), title: name, snippet: String(job.schedule || ""), type: "cron", url: "/scheduler" });
        }
      }
    }

    return results.slice(0, 20) as SearchResult[];
  });
