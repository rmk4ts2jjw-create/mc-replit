import "./lib/error-capture";

import { consumeLastCapturedError } from "./lib/error-capture";
import { renderErrorPage } from "./lib/error-page";

type ServerEntry = {
  fetch: (request: Request, env: unknown, ctx: unknown) => Promise<Response> | Response;
};

let serverEntryPromise: Promise<ServerEntry> | undefined;

async function getServerEntry(): Promise<ServerEntry> {
  if (!serverEntryPromise) {
    serverEntryPromise = import("@tanstack/react-start/server-entry").then(
      (m) => ((m as { default?: ServerEntry }).default ?? (m as unknown as ServerEntry)),
    );
  }
  return serverEntryPromise;
}

function addNoCacheHeaders(response: Response): Response {
  response.headers.set("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0");
  response.headers.set("Pragma", "no-cache");
  response.headers.set("Expires", "0");
  return response;
}

function brandedErrorResponse(): Response {
  return addNoCacheHeaders(new Response(renderErrorPage(), {
    status: 500,
    headers: { "content-type": "text/html; charset=utf-8" },
  }));
}

function isCatastrophicSsrErrorBody(body: string, responseStatus: number): boolean {
  let payload: unknown;
  try {
    payload = JSON.parse(body);
  } catch {
    return false;
  }

  if (!payload || Array.isArray(payload) || typeof payload !== "object") {
    return false;
  }

  const fields = payload as Record<string, unknown>;
  const expectedKeys = new Set(["message", "status", "unhandled"]);
  if (!Object.keys(fields).every((key) => expectedKeys.has(key))) {
    return false;
  }

  return (
    fields.unhandled === true &&
    fields.message === "HTTPError" &&
    (fields.status === undefined || fields.status === responseStatus)
  );
}

// h3 swallows in-handler throws into a normal 500 Response with body
// {"unhandled":true,"message":"HTTPError"} — try/catch alone never fires for those.
async function normalizeCatastrophicSsrResponse(response: Response): Promise<Response> {
  if (response.status < 500) return response;
  const contentType = response.headers.get("content-type") ?? "";
  if (!contentType.includes("application/json")) return response;

  const body = await response.clone().text();
  if (!isCatastrophicSsrErrorBody(body, response.status)) {
    return response;
  }

  console.error(consumeLastCapturedError() ?? new Error(`h3 swallowed SSR error: ${body}`));
  return brandedErrorResponse();
}

const WORKSPACE = process.env.OPENCLAW_WORKSPACE || "/Users/spacemonkey/.openclaw/workspace";

async function handleApiRequest(request: Request, url: URL): Promise<Response | null> {
  if (url.pathname === "/api/save-tasks" && request.method === "POST") {
    try {
      const tasks = await request.json();
      const { writeFileSync, existsSync, mkdirSync } = await import("node:fs");
      const { join } = await import("node:path");
      const dir = join(WORKSPACE, "data");
      if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
      writeFileSync(join(dir, "tasks.json"), JSON.stringify(tasks, null, 2), "utf-8");
      console.log("[api/save-tasks] Saved", tasks.length, "tasks");
      return new Response(JSON.stringify({ ok: true }), {
        headers: { "Content-Type": "application/json" },
      });
    } catch (err) {
      console.error("[api/save-tasks] Error:", err);
      return new Response(JSON.stringify({ ok: false, error: String(err) }), {
        status: 500,
        headers: { "Content-Type": "application/json" },
      });
    }
  }
  if (url.pathname === "/api/dispatch" && request.method === "POST") {
    try {
      const { taskId, title, assignee } = await request.json();
      const { writeFileSync, readFileSync, existsSync, mkdirSync } = await import("node:fs");
      const { join } = await import("node:path");
      const dir = join(WORKSPACE, "data");
      if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
      const queuePath = join(dir, "queue.json");
      let queue: unknown[] = [];
      try { queue = JSON.parse(readFileSync(queuePath, "utf-8")); } catch { /* empty */ }
      const item = {
        id: `queue-${Date.now().toString(36)}`,
        taskId,
        title,
        assignee,
        dispatchedAt: new Date().toISOString(),
        status: "pending",
      };
      queue.push(item);
      writeFileSync(queuePath, JSON.stringify(queue, null, 2), "utf-8");
      console.log("[api/dispatch] Dispatched task:", title, "to", assignee);
      return new Response(JSON.stringify({ ok: true, queueId: item.id }), {
        headers: { "Content-Type": "application/json" },
      });
    } catch (err) {
      console.error("[api/dispatch] Error:", err);
      return new Response(JSON.stringify({ ok: false, error: String(err) }), {
        status: 500,
        headers: { "Content-Type": "application/json" },
      });
    }
  }
  if (url.pathname === "/api/crons" && request.method === "GET") {
    try {
      const { readFileSync, existsSync } = await import("node:fs");
      const { join } = await import("node:path");
      const openclawDir = join(WORKSPACE, "..");
      const jobsPath = join(openclawDir, "cron", "jobs.json");
      const statePath = join(openclawDir, "cron", "jobs-state.json");
      if (!existsSync(jobsPath)) {
        return new Response(JSON.stringify([]), { headers: { "Content-Type": "application/json" } });
      }
      const jobsData = JSON.parse(readFileSync(jobsPath, "utf-8"));
      const stateData = existsSync(statePath) ? JSON.parse(readFileSync(statePath, "utf-8")) : { jobs: {} };
      const jobs = (jobsData.jobs || []) as Record<string, unknown>[];
      const stateJobs = (stateData.jobs || {}) as Record<string, Record<string, unknown>>;
      const mapped = jobs.map((j) => {
        const state = (stateJobs[j.id as string]?.state || {}) as Record<string, unknown>;
        const schedule = (j.schedule || {}) as Record<string, unknown>;
        const payload = (j.payload || {}) as Record<string, unknown>;
        return {
          id: String(j.id || ""),
          name: String(j.name || "Unknown"),
          schedule: String(schedule.expr || ""),
          enabled: j.enabled !== false,
          status: String(state.lastRunStatus || "ok"),
          lastError: String(state.lastError || ""),
          lastErrorReason: String(state.lastDiagnosticSummary || state.lastError || ""),
          consecutiveErrors: Number(state.consecutiveErrors || 0),
          lastRun: state.lastRunAtMs ? new Date(Number(state.lastRunAtMs)).toISOString() : "—",
          nextRun: state.nextRunAtMs ? new Date(Number(state.nextRunAtMs)).toISOString() : "—",
          message: String(payload.message || "").slice(0, 150),
        };
      });
      return new Response(JSON.stringify(mapped), {
        headers: { "Content-Type": "application/json" },
      });
    } catch (err) {
      console.error("[api/crons] Error:", err);
      return new Response(JSON.stringify([]), {
        headers: { "Content-Type": "application/json" },
      });
    }
  }
  if (url.pathname === "/api/cron-errors" && request.method === "GET") {
    try {
      const { readFileSync, existsSync } = await import("node:fs");
      const { join } = await import("node:path");
      const errorsPath = join(WORKSPACE, "data", "cron-errors.json");
      if (!existsSync(errorsPath)) {
        return new Response(JSON.stringify([]), { headers: { "Content-Type": "application/json" } });
      }
      const errors = JSON.parse(readFileSync(errorsPath, "utf-8"));
      return new Response(JSON.stringify(errors), { headers: { "Content-Type": "application/json" } });
    } catch (err) {
      return new Response(JSON.stringify([]), { headers: { "Content-Type": "application/json" } });
    }
  }
  if (url.pathname === "/api/cron-errors" && request.method === "POST") {
    try {
      const { errorId, status } = await request.json() as { errorId: string; status: string };
      const { writeFileSync, readFileSync, existsSync, mkdirSync } = await import("node:fs");
      const { join } = await import("node:path");
      const errorsPath = join(WORKSPACE, "data", "cron-errors.json");
      const dir = join(WORKSPACE, "data");
      if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
      let errors: Record<string, unknown>[] = [];
      try { errors = JSON.parse(readFileSync(errorsPath, "utf-8")); } catch { /* empty */ }
      const idx = errors.findIndex((e) => e.id === errorId);
      if (idx !== -1) {
        errors[idx].status = status;
        errors[idx].updatedAt = new Date().toISOString();
      } else {
        errors.push({ id: errorId, status, updatedAt: new Date().toISOString() });
      }
      writeFileSync(errorsPath, JSON.stringify(errors, null, 2), "utf-8");
      return new Response(JSON.stringify({ ok: true }), { headers: { "Content-Type": "application/json" } });
    } catch (err) {
      console.error("[api/cron-errors] Error:", err);
      return new Response(JSON.stringify({ ok: false, error: String(err) }), { status: 500, headers: { "Content-Type": "application/json" } });
    }
  }
  if (url.pathname === "/api/cron-errors/update" && request.method === "POST") {
    try {
      const { errorId, status } = await request.json() as { errorId: string; status: string };
      const { writeFileSync, readFileSync, existsSync, mkdirSync } = await import("node:fs");
      const { join } = await import("node:path");
      const errorsPath = join(WORKSPACE, "data", "cron-errors.json");
      const dir = join(WORKSPACE, "data");
      if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
      let errors: Record<string, unknown>[] = [];
      try { errors = JSON.parse(readFileSync(errorsPath, "utf-8")); } catch { /* empty */ }
      const idx = errors.findIndex((e) => e.id === errorId);
      if (idx !== -1) {
        errors[idx].status = status;
        errors[idx].updatedAt = new Date().toISOString();
      } else {
        errors.push({ id: errorId, status, updatedAt: new Date().toISOString() });
      }
      writeFileSync(errorsPath, JSON.stringify(errors, null, 2), "utf-8");
      console.log("[api/cron-errors/update] Updated:", errorId, "->", status);
      return new Response(JSON.stringify({ ok: true }), { headers: { "Content-Type": "application/json" } });
    } catch (err) {
      console.error("[api/cron-errors/update] Error:", err);
      return new Response(JSON.stringify({ ok: false, error: String(err) }), { status: 500, headers: { "Content-Type": "application/json" } });
    }
  }
  if (url.pathname === "/api/incidents/update" && request.method === "POST") {
    try {
      const { id, actions } = await request.json() as { id: string; actions: unknown[] };
      const { writeFileSync, readFileSync, existsSync } = await import("node:fs");
      const { join } = await import("node:path");
      const incidentsPath = join(WORKSPACE, "data", "incidents.json");
      if (!existsSync(incidentsPath)) {
        return new Response(JSON.stringify({ ok: false, error: "incidents.json not found" }), { status: 404, headers: { "Content-Type": "application/json" } });
      }
      const incidents = JSON.parse(readFileSync(incidentsPath, "utf-8")) as Record<string, unknown>[];
      const idx = incidents.findIndex((i) => i.id === id);
      if (idx !== -1) {
        // Merge: only update the actions array, preserve all other fields
        incidents[idx] = { ...incidents[idx], actions };
        writeFileSync(incidentsPath, JSON.stringify(incidents, null, 2), "utf-8");
        console.log("[api/incidents/update] Updated actions for incident:", id);
      }
      return new Response(JSON.stringify({ ok: true }), {
        headers: { "Content-Type": "application/json" },
      });
    } catch (err) {
      console.error("[api/incidents/update] Error:", err);
      return new Response(JSON.stringify({ ok: false, error: String(err) }), {
        status: 500,
        headers: { "Content-Type": "application/json" },
      });
    }
  }
  if (url.pathname === "/api/tasks/add" && request.method === "POST") {
    try {
      const newTask = await request.json();
      const { writeFileSync, readFileSync, existsSync, mkdirSync } = await import("node:fs");
      const { join } = await import("node:path");
      const dir = join(WORKSPACE, "data");
      if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
      const tasksPath = join(dir, "tasks.json");
      let tasks: unknown[] = [];
      try { tasks = JSON.parse(readFileSync(tasksPath, "utf-8")); } catch { /* empty */ }
      // Check for duplicate — same title + assignee already exists
      const isDuplicate = (tasks as Record<string, unknown>[]).some(
        (t) => t.title === newTask.title && t.assignee === newTask.assignee
      );
      if (isDuplicate) {
        console.log("[api/tasks/add] Skipped duplicate:", newTask.title);
        return new Response(JSON.stringify({ ok: false, message: "Duplicate task — already exists" }), {
          headers: { "Content-Type": "application/json" },
        });
      }
      tasks.unshift(newTask);
      writeFileSync(tasksPath, JSON.stringify(tasks, null, 2), "utf-8");
      console.log("[api/tasks/add] Added task:", newTask.title);
      return new Response(JSON.stringify({ ok: true }), {
        headers: { "Content-Type": "application/json" },
      });
    } catch (err) {
      console.error("[api/tasks/add] Error:", err);
      return new Response(JSON.stringify({ ok: false, error: String(err) }), {
        status: 500,
        headers: { "Content-Type": "application/json" },
      });
    }
  }
  if (url.pathname === "/api/cron-toggle" && request.method === "POST") {
    try {
      const { id, action } = await request.json() as { id: string; action: string };
      const { readFileSync, writeFileSync } = await import("node:fs");
      const { join } = await import("node:path");
      const jobsPath = join(WORKSPACE, "..", "cron", "jobs.json");
      const data = JSON.parse(readFileSync(jobsPath, "utf-8"));
      const job = (data.jobs as Record<string, unknown>[]).find((j) => j.id === id);
      if (job) job.enabled = action === "enable";
      writeFileSync(jobsPath, JSON.stringify(data, null, 2), "utf-8");
      return new Response(JSON.stringify({ ok: true, message: `Cron job ${action}d` }), {
        headers: { "Content-Type": "application/json" },
      });
    } catch (err) {
      return new Response(JSON.stringify({ ok: false, error: String(err) }), {
        status: 500,
        headers: { "Content-Type": "application/json" },
      });
    }
  }
  if (url.pathname === "/api/cron/enable" && request.method === "POST") {
    try {
      const { id } = await request.json();
      const { readFileSync, writeFileSync } = await import("node:fs");
      const { join } = await import("node:path");
      const jobsPath = join(WORKSPACE, "..", "cron", "jobs.json");
      const data = JSON.parse(readFileSync(jobsPath, "utf-8"));
      const job = (data.jobs as Record<string, unknown>[]).find((j) => j.id === id);
      if (job) job.enabled = true;
      writeFileSync(jobsPath, JSON.stringify(data, null, 2), "utf-8");
      return new Response(JSON.stringify({ ok: true, message: "Cron job enabled" }), {
        headers: { "Content-Type": "application/json" },
      });
    } catch (err) {
      return new Response(JSON.stringify({ ok: false, error: String(err) }), {
        status: 500,
        headers: { "Content-Type": "application/json" },
      });
    }
  }
  if (url.pathname === "/api/cron/disable" && request.method === "POST") {
    try {
      const { id } = await request.json();
      const { readFileSync, writeFileSync } = await import("node:fs");
      const { join } = await import("node:path");
      const jobsPath = join(WORKSPACE, "..", "cron", "jobs.json");
      const data = JSON.parse(readFileSync(jobsPath, "utf-8"));
      const job = (data.jobs as Record<string, unknown>[]).find((j) => j.id === id);
      if (job) job.enabled = false;
      writeFileSync(jobsPath, JSON.stringify(data, null, 2), "utf-8");
      return new Response(JSON.stringify({ ok: true, message: "Cron job disabled" }), {
        headers: { "Content-Type": "application/json" },
      });
    } catch (err) {
      return new Response(JSON.stringify({ ok: false, error: String(err) }), {
        status: 500,
        headers: { "Content-Type": "application/json" },
      });
    }
  }
  return null;
}

export default {
  async fetch(request: Request, env: unknown, ctx: unknown) {
    try {
      const url = new URL(request.url);
      const apiResponse = await handleApiRequest(request, url);
      if (apiResponse) return addNoCacheHeaders(apiResponse);
      const handler = await getServerEntry();
      const response = await handler.fetch(request, env, ctx);
      const normalized = await normalizeCatastrophicSsrResponse(response);
      return addNoCacheHeaders(normalized);
    } catch (error) {
      console.error("[SERVER FETCH ERROR]", error);
      return brandedErrorResponse();
    }
  },
};
