// TaskProgress — small per-agent task progress indicator + truncated label.
// Renders inside an AgentOffice room over the floorplan tile.

import type { Task } from "@/lib/server-data/types";

interface TaskProgressProps {
  task: Task;
  accent: string;
}

function pickColor(task: Task, accent: string): string {
  if (task.stalledAt) return "oklch(0.78 0.16 75)"; // amber
  if (task.status === "in_progress") return "oklch(0.78 0.18 145)"; // green
  if (task.status === "awaiting_review") return accent;
  return "oklch(0.55 0.02 265)"; // grey waiting
}

export function TaskProgress({ task, accent }: TaskProgressProps) {
  const pct = Math.max(0, Math.min(100, Math.round(task.progress ?? 0)));
  const color = pickColor(task, accent);
  const label = (task.currentStep || task.title || "").slice(0, 20) +
    ((task.currentStep || task.title || "").length > 20 ? "…" : "");

  return (
    <div className="pointer-events-none absolute bottom-2 left-2 right-2 z-20 select-none">
      <div className="rounded bg-background/70 backdrop-blur-sm border border-border/40 px-1.5 py-1">
        <div className="flex items-center justify-between gap-2 mb-0.5">
          <span className="font-mono text-[7px] tracking-wider text-foreground/80 truncate">
            {label || "—"}
          </span>
          <span className="font-mono text-[7px] tabular-nums" style={{ color }}>
            {pct}%
          </span>
        </div>
        <div className="h-[3px] w-full rounded-full bg-muted/30 overflow-hidden">
          <div
            className="h-full rounded-full transition-all duration-700"
            style={{
              width: `${pct}%`,
              background: color,
              boxShadow: `0 0 6px ${color}`,
            }}
          />
        </div>
      </div>
    </div>
  );
}
