// TaskPackets — animated diamond packets travelling from hub to assigned agent room.
// Spawns one packet per newly-detected task assignment. Stacks naturally.

import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import type { Task } from "@/lib/server-data/types";

type RoomId = "command" | "security" | "workshop" | "archive";

const AGENT_HOME: Record<string, RoomId> = {
  monkey: "command",
  lifesupport: "security",
  engineer: "workshop",
  archivist: "archive",
};

const ROOM_CENTERS: Record<RoomId, { x: number; y: number }> = {
  command:  { x: 25, y: 28 },
  security: { x: 75, y: 28 },
  workshop: { x: 25, y: 78 },
  archive:  { x: 75, y: 78 },
};

const ACCENT: Record<string, string> = {
  monkey:      "oklch(0.62 0.22 295)", // violet
  lifesupport: "oklch(0.78 0.18 350)", // pink
  engineer:    "oklch(0.78 0.18 200)", // cyan
  archivist:   "oklch(0.85 0.16 90)",  // amber
};

interface Packet {
  id: string;
  agentId: string;
  color: string;
  to: { x: number; y: number };
  stackIndex: number;
}

interface TaskPacketsProps {
  tasks: Task[];
}

export function TaskPackets({ tasks }: TaskPacketsProps) {
  const [packets, setPackets] = useState<Packet[]>([]);
  const seenRef = useRef<Set<string> | null>(null);
  const liveCountRef = useRef(0);

  useEffect(() => {
    // Build current key set (taskId|assignee). Skip done tasks.
    const current = new Set<string>();
    const newOnes: Task[] = [];
    for (const t of tasks) {
      if (!t.assignee || !AGENT_HOME[t.assignee]) continue;
      if (t.status === "done") continue;
      const key = `${t.id}|${t.assignee}`;
      current.add(key);
      if (seenRef.current && !seenRef.current.has(key)) newOnes.push(t);
    }
    // First run: seed without spawning (avoids burst on mount).
    if (!seenRef.current) {
      seenRef.current = current;
      return;
    }
    seenRef.current = current;

    if (newOnes.length === 0) return;

    setPackets(prev => {
      const next = [...prev];
      newOnes.slice(0, 8).forEach((t, i) => {
        const home = AGENT_HOME[t.assignee];
        next.push({
          id: `${t.id}-${Date.now()}-${i}`,
          agentId: t.assignee,
          color: ACCENT[t.assignee] || "oklch(0.78 0.14 200)",
          to: ROOM_CENTERS[home],
          stackIndex: liveCountRef.current++ % 5,
        });
      });
      return next;
    });
  }, [tasks]);

  const onComplete = (id: string) => {
    setPackets(prev => prev.filter(p => p.id !== id));
  };

  return (
    <div className="pointer-events-none absolute inset-0 z-[17] overflow-hidden" aria-hidden>
      <AnimatePresence>
        {packets.map(p => {
          // L-shaped path: hub → mid horizontal → vertical to target
          const offsetY = (p.stackIndex - 2) * 1.2;
          const offsetX = (p.stackIndex - 2) * 1.2;
          const mid = { x: p.to.x, y: 50 + offsetY };
          return (
            <motion.div
              key={p.id}
              className="absolute"
              initial={{ left: `50%`, top: `50%`, opacity: 0, scale: 0.6 }}
              animate={{
                left: [`50%`, `${mid.x}%`, `${p.to.x + offsetX * 0.2}%`],
                top:  [`50%`, `${mid.y}%`, `${p.to.y}%`],
                opacity: [0, 1, 1, 0],
                scale: [0.6, 1, 1, 0.4],
              }}
              transition={{
                duration: 1.4,
                ease: "easeInOut",
                times: [0, 0.35, 0.85, 1],
              }}
              onAnimationComplete={() => onComplete(p.id)}
              style={{ x: "-50%", y: "-50%" }}
            >
              <div
                style={{
                  width: 8,
                  height: 8,
                  background: p.color,
                  transform: "rotate(45deg)",
                  boxShadow: `0 0 10px 2px ${p.color}, 0 0 20px 4px ${p.color}`,
                  borderRadius: 1,
                }}
              />
            </motion.div>
          );
        })}
      </AnimatePresence>
    </div>
  );
}
