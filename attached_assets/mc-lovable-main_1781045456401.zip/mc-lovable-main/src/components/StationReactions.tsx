// StationReactions — full-station ambient reactions to events:
//  - green pulse when a task completes
//  - dim/brighten "sigh" when an incident is resolved
//  - sparkle when all tasks reach Done
//  - occasional subtle "blink" when station is quiet (no tasks/incidents)

import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import type { Task, Incident } from "@/lib/server-data-types";

type Reaction =
  | { id: string; kind: "task-done" }
  | { id: string; kind: "incident-sigh" }
  | { id: string; kind: "sparkle" }
  | { id: string; kind: "blink" };

interface Props {
  tasks: Task[];
  incidents: Incident[];
}

export function StationReactions({ tasks, incidents }: Props) {
  const [reactions, setReactions] = useState<Reaction[]>([]);
  const prevDoneRef = useRef<number | null>(null);
  const prevOpenIncidentsRef = useRef<number | null>(null);
  const sparkledRef = useRef(false);

  // task done / all-done sparkle
  useEffect(() => {
    const doneCount = tasks.filter(t => t.status === "done").length;
    const activeCount = tasks.filter(t => t.status !== "done").length;
    const prev = prevDoneRef.current;
    prevDoneRef.current = doneCount;
    if (prev === null) return;
    if (doneCount > prev) {
      setReactions(rs => [...rs, { id: `td-${Date.now()}`, kind: "task-done" }]);
    }
    if (activeCount === 0 && tasks.length > 0 && !sparkledRef.current) {
      sparkledRef.current = true;
      setReactions(rs => [...rs, { id: `sp-${Date.now()}`, kind: "sparkle" }]);
    } else if (activeCount > 0) {
      sparkledRef.current = false;
    }
  }, [tasks]);

  // incident resolved sigh
  useEffect(() => {
    const open = incidents.filter(i => i.status !== "RESOLVED").length;
    const prev = prevOpenIncidentsRef.current;
    prevOpenIncidentsRef.current = open;
    if (prev !== null && open < prev) {
      setReactions(rs => [...rs, { id: `is-${Date.now()}`, kind: "incident-sigh" }]);
    }
  }, [incidents]);

  // quiet station: random subtle blink every 30–60s
  useEffect(() => {
    const isQuiet =
      tasks.filter(t => t.status !== "done").length === 0 &&
      incidents.filter(i => i.status !== "RESOLVED").length === 0;
    if (!isQuiet) return;
    let cancelled = false;
    const schedule = () => {
      const delay = 30000 + Math.random() * 30000;
      const t = setTimeout(() => {
        if (cancelled || document.hidden) { schedule(); return; }
        setReactions(rs => [...rs, { id: `bl-${Date.now()}`, kind: "blink" }]);
        schedule();
      }, delay);
      return t;
    };
    const t = schedule();
    return () => { cancelled = true; clearTimeout(t); };
  }, [tasks, incidents]);

  const drop = (id: string) =>
    setReactions(rs => rs.filter(r => r.id !== id));

  return (
    <div className="pointer-events-none absolute inset-0 z-[19] overflow-hidden" aria-hidden>
      <AnimatePresence>
        {reactions.map(r => {
          if (r.kind === "task-done") {
            return (
              <motion.div
                key={r.id}
                className="absolute inset-0 rounded-lg"
                initial={{ opacity: 0 }}
                animate={{ opacity: [0, 0.35, 0] }}
                transition={{ duration: 1.6, ease: "easeOut" }}
                onAnimationComplete={() => drop(r.id)}
                style={{
                  boxShadow: "inset 0 0 60px 6px oklch(0.78 0.18 145 / 0.45)",
                  background:
                    "radial-gradient(circle at 50% 50%, oklch(0.78 0.18 145 / 0.18), transparent 60%)",
                }}
              />
            );
          }
          if (r.kind === "incident-sigh") {
            return (
              <motion.div
                key={r.id}
                className="absolute inset-0 rounded-lg bg-black"
                initial={{ opacity: 0 }}
                animate={{ opacity: [0, 0.35, 0.05, 0] }}
                transition={{ duration: 2.2, ease: "easeInOut", times: [0, 0.35, 0.7, 1] }}
                onAnimationComplete={() => drop(r.id)}
              />
            );
          }
          if (r.kind === "sparkle") {
            return (
              <motion.div
                key={r.id}
                className="absolute inset-0"
                initial={{ opacity: 0 }}
                animate={{ opacity: [0, 1, 1, 0] }}
                transition={{ duration: 3.2 }}
                onAnimationComplete={() => drop(r.id)}
              >
                {Array.from({ length: 18 }).map((_, i) => {
                  const left = Math.random() * 100;
                  const top = Math.random() * 100;
                  const delay = Math.random() * 1.5;
                  const colors = [
                    "oklch(0.62 0.22 295)",
                    "oklch(0.78 0.18 350)",
                    "oklch(0.78 0.18 200)",
                    "oklch(0.85 0.16 90)",
                  ];
                  const c = colors[i % colors.length];
                  return (
                    <motion.div
                      key={i}
                      className="absolute rounded-full"
                      style={{
                        left: `${left}%`,
                        top: `${top}%`,
                        width: 4,
                        height: 4,
                        background: c,
                        boxShadow: `0 0 10px 2px ${c}`,
                      }}
                      initial={{ scale: 0, opacity: 0 }}
                      animate={{ scale: [0, 1.4, 0], opacity: [0, 1, 0] }}
                      transition={{ duration: 1.6, delay, repeat: 1, repeatDelay: 0.2 }}
                    />
                  );
                })}
              </motion.div>
            );
          }
          // blink — single subtle station-wide flicker
          return (
            <motion.div
              key={r.id}
              className="absolute inset-0 rounded-lg"
              initial={{ opacity: 0 }}
              animate={{ opacity: [0, 0.15, 0, 0.08, 0] }}
              transition={{ duration: 0.9, times: [0, 0.2, 0.4, 0.6, 1] }}
              onAnimationComplete={() => drop(r.id)}
              style={{
                background:
                  "radial-gradient(circle at 50% 50%, oklch(0.62 0.22 295 / 0.25), transparent 70%)",
              }}
            />
          );
        })}
      </AnimatePresence>
    </div>
  );
}
