// AgentOffice — wires live data into a StationRoom for one crew member.

import { StationRoom } from "./StationRoom";
import { TaskProgress } from "./TaskProgress";
import type { CrewMember } from "@/lib/crew";
import type { LiveAgentStatus } from "@/lib/live-data";
import type { AgentActivity } from "@/lib/station-state";
import type { Task } from "@/lib/server-data/types";

const ROOM_CONFIGS: Record<string, {
  roomId: string; label: string;
  agentPos: { xPct: number; yPct: number };
  monitors: { xPct: number; yPct: number; w: number; h: number }[];
}> = {
  monkey: {
    roomId: "command", label: "COMMAND HQ",
    agentPos: { xPct: 50, yPct: 65 },
    monitors: [
      { xPct: 15, y: 15, w: 20, h: 15 } as any,
      { xPct: 39, y: 13, w: 22, h: 18 } as any,
      { xPct: 73, y: 15, w: 18, h: 15 } as any,
    ],
  },
  lifesupport: {
    roomId: "security", label: "SECURITY BAY",
    agentPos: { xPct: 50, yPct: 68 },
    monitors: [
      { xPct: 5, y: 23, w: 85, h: 13 } as any,
      { xPct: 5, y: 42, w: 18, h: 28 } as any,
    ],
  },
  engineer: {
    roomId: "workshop", label: "WORKSHOP",
    agentPos: { xPct: 50, yPct: 65 },
    monitors: [
      { xPct: 37, y: 49, w: 29, h: 13 } as any,
      { xPct: 88, y: 41, w: 10, h: 16 } as any,
    ],
  },
  archivist: {
    roomId: "archive", label: "ARCHIVE",
    agentPos: { xPct: 50, yPct: 68 },
    monitors: [
      { xPct: 34, y: 54, w: 32, h: 14 } as any,
    ],
  },
};

const ACCENT_COLORS: Record<string, string> = {
  monkey:      "oklch(0.78 0.14 200)",
  lifesupport: "oklch(0.78 0.18 350)",
  engineer:    "oklch(0.78 0.18 200)",
  archivist:   "oklch(0.85 0.16 90)",
};

const ACCENT_HUES: Record<string, number> = {
  monkey: 295, lifesupport: 350, engineer: 200, archivist: 90,
};

function mapStatus(s: LiveAgentStatus["status"]): AgentActivity {
  switch (s) {
    case "working":       return "working";
    case "collaborating": return "collaborating";
    case "away":          return "away";
    default:              return "idle";
  }
}

interface AgentOfficeProps {
  crew: CrewMember;
  liveStatus?: LiveAgentStatus;
  isAway?: boolean;
  celebratingTaskId?: string | null;
  activeTask?: Task | null;
}

export function AgentOffice({ crew, liveStatus, isAway, celebratingTaskId, activeTask }: AgentOfficeProps) {
  const config = ROOM_CONFIGS[crew.id];
  if (!config) return null;

  const activity = liveStatus ? mapStatus(liveStatus.status) : "idle";
  const accent   = ACCENT_COLORS[crew.id] ?? "oklch(0.78 0.14 200)";
  const accentH  = ACCENT_HUES[crew.id] ?? 200;
  const taskName = liveStatus?.currentAction;
  const workload = liveStatus?.workload ?? 0;
  const energy = workload / 4; // 0..1
  const workloadLabel = ["IDLE", "LIGHT", "MEDIUM", "HEAVY", "CRITICAL"][workload];

  return (
    <div
      className="relative"
      data-workload={workload}
      style={{
        // Drives glow/pulse intensity in CSS overlays
        ["--energy" as any]: energy,
        ["--workload-accent" as any]: accent,
      }}
    >
      <StationRoom
        roomId={config.roomId}
        label={config.label}
        bgImage=""
        accent={accent}
        accentHue={accentH}
        agentId={crew.id}
        agentName={crew.name}
        agentRole={crew.shortRole}
        agentActivity={activity}
        agentPos={config.agentPos}
        monitors={config.monitors}
        useCanvas
        currentTaskName={taskName}
        isAway={isAway}
        isAlertActive={workload >= 4}
      />
      {/* Workload energy overlay — visible at medium+, intensifies through critical */}
      {workload >= 2 && (
        <div
          className="pointer-events-none absolute inset-0 rounded-sm room-energy-overlay"
          data-workload={workload}
          style={{
            boxShadow: `inset 0 0 ${12 + workload * 6}px ${Math.max(2, workload)}px ${accent}`,
            opacity: 0.18 + energy * 0.4,
          }}
          aria-hidden
        />
      )}
      {/* Workload badge */}
      <div
        className="pointer-events-none absolute top-1 right-1 z-30 rounded px-1.5 py-[1px] font-mono text-[7px] tracking-wider"
        style={{
          background: workload >= 4 ? "rgba(255,60,60,0.25)" : workload >= 3 ? "rgba(255,160,60,0.20)" : "rgba(120,120,200,0.15)",
          color: workload >= 4 ? "#ff8888" : workload >= 3 ? "#ffc080" : "#a0a8c8",
          border: `1px solid ${workload >= 4 ? "rgba(255,60,60,0.5)" : "rgba(160,160,200,0.3)"}`,
        }}
      >
        {workloadLabel}
      </div>
      {activeTask && <TaskProgress task={activeTask} accent={accent} />}
    </div>
  );
}
