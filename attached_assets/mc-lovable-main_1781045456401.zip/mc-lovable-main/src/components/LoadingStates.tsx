import { useState, useEffect } from "react";

// ── Orbiting satellite loader ────────────────────────────────────────────────
export function OrbitLoader({ message = "Establishing uplink..." }: { message?: string }) {
  return (
    <div className="flex flex-col items-center justify-center gap-4 py-12">
      <div className="relative w-16 h-16">
        <div className="absolute inset-0 rounded-full border-2 border-border/30" />
        <div className="absolute inset-0 rounded-full border-2 border-transparent border-t-violet animate-spin" />
        <div className="absolute inset-2 rounded-full border border-transparent border-b-cyan-accent animate-spin" style={{ animationDirection: "reverse", animationDuration: "1.5s" }} />
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="text-xs">🛰</span>
        </div>
      </div>
      <div className="font-mono text-[10px] tracking-[0.2em] text-muted-foreground/60 animate-pulse">
        {message}
      </div>
    </div>
  );
}

// ── Radar sweep loader ───────────────────────────────────────────────────────
export function RadarLoader() {
  return (
    <div className="flex flex-col items-center justify-center gap-4 py-12">
      <div className="relative w-12 h-12 rounded-full border border-border/30 bg-card/20 overflow-hidden">
        <div className="absolute inset-0 rounded-full border border-transparent border-t-violet/50 animate-spin" />
        <div className="absolute top-1/2 left-1/2 w-1 h-1 -translate-x-1/2 -translate-y-1/2 rounded-full bg-violet-glow" />
      </div>
      <div className="font-mono text-[10px] tracking-[0.15em] text-muted-foreground/50">
        SCANNING...
      </div>
    </div>
  );
}

// ── Terminal boot sequence ───────────────────────────────────────────────────
export function TerminalBootLoader() {
  const [lines, setLines] = useState<string[]>([]);

  const bootSequence = [
    "INITIALIZING MISSION CONTROL...",
    "LOADING CREW MANIFEST...",
    "ESTABLISHING STATION UPLINK...",
    "VERIFYING SYSTEM INTEGRITY...",
    "ALL SYSTEMS NOMINAL.",
  ];

  useEffect(() => {
    let i = 0;
    const interval = setInterval(() => {
      if (i < bootSequence.length) {
        setLines(prev => [...prev, bootSequence[i]]);
        i++;
      } else {
        clearInterval(interval);
      }
    }, 300);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex flex-col items-center justify-center gap-4 py-12">
      <div className="w-full max-w-xs rounded-lg border border-border/30 bg-[#0a0e1a] p-4 font-mono text-[10px]">
        {lines.map((line, li) => (
          <div key={`boot-${li}`} className={`${li === bootSequence.length - 1 ? "text-online" : "text-muted-foreground/60"}`}>
            <span className="text-violet/60 mr-2">[{String(li).padStart(2, "0")}]</span>
            {line}
            {li === bootSequence.length - 1 && <span className="ml-1 status-blink">_</span>}
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Empty state with personality ─────────────────────────────────────────────
export function EmptyState({
  icon = "📡",
  message = "No active missions detected.",
  subtext = "The crew is standing by.",
}: {
  icon?: string;
  message?: string;
  subtext?: string;
}) {
  return (
    <div className="empty-state">
      <div className="empty-state-icon">{icon}</div>
      <div className="font-mono text-sm tracking-wider text-muted-foreground">{message}</div>
      <div className="font-mono text-[10px] tracking-[0.15em] text-muted-foreground/50 mt-2">{subtext}</div>
    </div>
  );
}

// ── Holographic scan effect ──────────────────────────────────────────────────
export function HolographicScan({ children }: { children: React.ReactNode }) {
  return (
    <div className="relative overflow-hidden">
      {children}
      <div className="absolute inset-0 pointer-events-none bg-gradient-to-b from-transparent via-violet/5 to-transparent animate-pulse" style={{ animationDuration: "3s" }} />
    </div>
  );
}
