import { useState, useEffect } from "react";
import { CREW } from "@/lib/crew";
import { getTasks } from "@/lib/server-data";
import type { Incident, IncidentAction, IncidentEvent, Task } from "@/lib/server-data-types";
import { getRunbookForIncident, type Runbook } from "@/lib/server-data/runbooks";
import { getIncidentTimeline, type TimelineEvent } from "@/lib/server-data/timeline-data";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Pill } from "@/components/PageHeader";
import {
  AlertTriangle,
  CheckCircle2,
  Clock,
  Flame,
  Minus,
  Play,
  SkipForward,
  Tag,
  User,
  Send,
  Undo2,
  ShieldAlert,
  ListChecks,
  ArrowRight,
} from "lucide-react";
import type { ReactNode } from "react";

// ── Status config ────────────────────────────────────────────────────────────

const STATUS_CONFIG: Record<
  Incident["status"],
  { label: string; color: string; dot: string; icon: ReactNode }
> = {
  TRIAGE: {
    label: "TRIAGE",
    color: "text-warning",
    dot: "bg-warning",
    icon: <AlertTriangle className="h-4 w-4 text-warning" />,
  },
  MITIGATING: {
    label: "MITIGATING",
    color: "text-cyan-400",
    dot: "bg-cyan-400",
    icon: <Minus className="h-4 w-4 text-cyan-400" />,
  },
  AWAITING_REVIEW: {
    label: "AWAITING REVIEW",
    color: "text-violet",
    dot: "bg-violet",
    icon: <Clock className="h-4 w-4 text-violet" />,
  },
  RESOLVED: {
    label: "RESOLVED",
    color: "text-[oklch(0.88_0.18_145)]",
    dot: "bg-[oklch(0.88_0.18_145)]",
    icon: <CheckCircle2 className="h-4 w-4 text-[oklch(0.88_0.18_145)]" />,
  },
};

const SEVERITY_CONFIG: Record<
  Incident["severity"],
  { label: string; color: string; bg: string; border: string }
> = {
  P1: {
    label: "P1 — CRITICAL",
    color: "text-red-400",
    bg: "bg-red-500/10",
    border: "border-red-500/40",
  },
  P2: {
    label: "P2 — HIGH",
    color: "text-warning",
    bg: "bg-warning/10",
    border: "border-warning/40",
  },
  P3: {
    label: "P3 — STANDARD",
    color: "text-cyan-400",
    bg: "bg-cyan-500/10",
    border: "border-cyan-500/40",
  },
  P4: {
    label: "P4 — LOW",
    color: "text-gray-400",
    bg: "bg-gray-500/10",
    border: "border-gray-500/40",
  },
};

const ACTION_STATUS_CONFIG: Record<
  IncidentAction["status"],
  { icon: ReactNode; label: string; color: string; bg: string; border: string }
> = {
  suggested: {
    icon: <Tag className="h-3.5 w-3.5" />,
    label: "Suggested",
    color: "text-muted-foreground",
    bg: "bg-card/40",
    border: "border-border",
  },
  queued: {
    icon: <Clock className="h-3.5 w-3.5" />,
    label: "Queued",
    color: "text-cyan-400",
    bg: "bg-cyan-500/5",
    border: "border-cyan-500/30",
  },
  in_progress: {
    icon: <Play className="h-3.5 w-3.5" />,
    label: "In Progress",
    color: "text-violet",
    bg: "bg-violet/10",
    border: "border-violet/40",
  },
  awaiting_review: {
    icon: <ShieldAlert className="h-3.5 w-3.5" />,
    label: "Awaiting Review",
    color: "text-warning",
    bg: "bg-warning/10",
    border: "border-warning/30",
  },
  completed: {
    icon: <CheckCircle2 className="h-3.5 w-3.5" />,
    label: "Completed",
    color: "text-[oklch(0.88_0.18_145)]",
    bg: "bg-[oklch(0.88_0.18_145)]/5",
    border: "border-[oklch(0.88_0.18_145)]/20",
  },
  skipped: {
    icon: <SkipForward className="h-3.5 w-3.5" />,
    label: "Skipped",
    color: "text-muted-foreground/60",
    bg: "bg-card/20",
    border: "border-border/40",
  },
  failed: {
    icon: <AlertTriangle className="h-3.5 w-3.5" />,
    label: "Failed",
    color: "text-destructive",
    bg: "bg-destructive/10",
    border: "border-destructive/30",
  },
};

// ── Timeline item ────────────────────────────────────────────────────────────

function TimelineItem({ event, isLast }: { event: IncidentEvent; isLast: boolean }) {
  const actor = event.actor ? CREW.find((c) => c.id === event.actor) : null;

  return (
    <div className="flex gap-3">
      <div className="flex flex-col items-center pt-1">
        <div className="h-2.5 w-2.5 rounded-full bg-violet/60 ring-2 ring-violet/20 shrink-0" />
        {!isLast && <div className="w-px flex-1 bg-border/60 mt-1" />}
      </div>
      <div className="pb-4 min-w-0 flex-1">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="font-mono text-[11px] text-muted-foreground tracking-wider">
            {event.ts}
          </span>
          {actor && (
            <span className="flex items-center gap-1.5">
              <span className="h-4 w-4 rounded flex items-center justify-center text-xs leading-none">{actor.avatar}</span>
              <span className="font-mono text-[10px] text-foreground/70">{actor.name}</span>
            </span>
          )}
        </div>
        <p className="mt-0.5 text-sm text-foreground/85 leading-relaxed">
          {event.message}
        </p>
      </div>
    </div>
  );
}

// ── Action item ──────────────────────────────────────────────────────────────

function ActionItem({
  action,
  index,
  onQueue,
  onRun,
  onComplete,
  onSubmitReview,
  onSkip,
  onUndo,
  onFail,
  running,
  linkedTask,
}: {
  action: IncidentAction;
  index: number;
  onQueue?: () => void;
  onRun?: () => void;
  onComplete?: () => void;
  onSubmitReview?: () => void;
  onSkip?: () => void;
  onUndo?: (newStatus: IncidentAction["status"]) => void;
  onFail?: () => void;
  running?: boolean;
  linkedTask?: { id: string; status: string; assignee: string } | null;
}) {
  const cfg = ACTION_STATUS_CONFIG[action.status];
  const assignee = action.assignee ? CREW.find(c => c.id === action.assignee) : null;

  return (
    <div
      className={[
        "rounded-lg border p-3 transition-colors",
        cfg.bg, cfg.border,
      ].join(" ")}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className={["flex items-center gap-1 font-mono text-[10px] uppercase tracking-wider", cfg.color].join(" ")}>
              {cfg.icon}
              {cfg.label}
            </span>
            {action.status === "in_progress" && (
              <span className="inline-block h-2 w-2 rounded-full bg-violet animate-pulse" />
            )}
            {action.status === "awaiting_review" && (
              <span className="inline-block h-2 w-2 rounded-full bg-warning animate-pulse" />
            )}
            {assignee && (
              <span className="flex items-center gap-1">
                <span className="h-4 w-4 rounded flex items-center justify-center text-xs leading-none">{assignee.avatar}</span>
                <span className="font-mono text-[10px] text-foreground/60">{assignee.name}</span>
              </span>
            )}
          </div>
          <h4 className={["mt-1 text-sm font-medium",
            action.status === "completed" ? "line-through opacity-70" :
            action.status === "skipped" ? "line-through opacity-50" :
            action.status === "failed" ? "text-destructive" :
            action.status === "in_progress" ? "text-violet" :
            action.status === "awaiting_review" ? "text-warning" :
            "text-foreground"
          ].join(" ")}>
            {action.label}
          </h4>
          <p className={["mt-0.5 text-xs leading-relaxed",
            (action.status === "completed" || action.status === "skipped") ? "text-muted-foreground/60" : "text-muted-foreground"
          ].join(" ")}>
            {action.description}
          </p>

          {/* Linked task indicator */}
          {linkedTask && (
            <div className="mt-2 flex items-center gap-1.5 text-xs">
              <ArrowRight className="h-3 w-3 text-muted-foreground/50" />
              <span className="font-mono text-[10px] text-muted-foreground/70">
                Task: {linkedTask.id}
              </span>
              <Pill variant={
                linkedTask.status === "done" ? "online" :
                linkedTask.status === "in_progress" ? "violet" :
                linkedTask.status === "awaiting_review" ? "warning" :
                "default"
              }>
                {linkedTask.status === "in_progress" ? "WORKING" :
                 linkedTask.status === "awaiting_review" ? "REVIEW" :
                 linkedTask.status.toUpperCase()}
              </Pill>
            </div>
          )}
        </div>
      </div>

      {/* Action buttons — suggested: Queue */}
      {action.status === "suggested" && (onQueue || onSkip) && (
        <div className="mt-3 flex items-center gap-2">
          {onQueue && (
            <button
              onClick={onQueue}
              className="inline-flex items-center gap-1.5 rounded-md border border-cyan-500/30 bg-cyan-500/10 px-3 py-1.5 text-xs font-medium text-cyan-400 transition-colors hover:bg-cyan-500/20"
            >
              <Send className="h-3 w-3" />
              Queue
            </button>
          )}
          {onSkip && (
            <button
              onClick={onSkip}
              className="inline-flex items-center gap-1.5 rounded-md border border-border bg-background px-3 py-1.5 text-xs text-muted-foreground transition-colors hover:text-foreground"
            >
              <SkipForward className="h-3 w-3" />
              Skip
            </button>
          )}
        </div>
      )}

      {/* Action buttons — queued: Run / Skip */}
      {action.status === "queued" && (onRun || onSkip) && (
        <div className="mt-3 flex items-center gap-2">
          {onRun && (
            <button
              onClick={onRun}
              disabled={running}
              className={`inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium transition-colors ${
                running
                  ? "bg-violet/50 text-primary-foreground/50 cursor-wait"
                  : "bg-violet text-primary-foreground hover:bg-violet/90"
              }`}
            >
              {running ? (
                <span className="h-3 w-3 animate-spin rounded-full border-2 border-primary-foreground/30 border-t-primary-foreground" />
              ) : (
                <Play className="h-3 w-3" />
              )}
              {running ? "Dispatching..." : "Run"}
            </button>
          )}
          {onSkip && (
            <button
              onClick={onSkip}
              className="inline-flex items-center gap-1.5 rounded-md border border-border bg-background px-3 py-1.5 text-xs text-muted-foreground transition-colors hover:text-foreground"
            >
              <SkipForward className="h-3 w-3" />
              Skip
            </button>
          )}
        </div>
      )}

      {/* Action buttons — in_progress: Submit for Review / Fail */}
      {action.status === "in_progress" && (onSubmitReview || onFail || onUndo) && (
        <div className="mt-3 flex items-center gap-2">
          {onSubmitReview && (
            <button
              onClick={onSubmitReview}
              className="inline-flex items-center gap-1.5 rounded-md border border-warning/40 bg-warning/10 px-3 py-1.5 text-xs font-medium text-warning transition-colors hover:bg-warning/20"
            >
              <ShieldAlert className="h-3 w-3" />
              Submit for Review
            </button>
          )}
          {onFail && (
            <button
              onClick={onFail}
              className="inline-flex items-center gap-1.5 rounded-md border border-destructive/30 bg-destructive/10 px-3 py-1.5 text-xs font-medium text-destructive transition-colors hover:bg-destructive/20"
            >
              <AlertTriangle className="h-3 w-3" />
              Mark Failed
            </button>
          )}
          {onUndo && (
            <button
              onClick={() => onUndo("queued")}
              className="inline-flex items-center gap-1.5 rounded-md border border-border bg-background px-3 py-1.5 text-xs text-muted-foreground transition-colors hover:text-foreground"
            >
              <Undo2 className="h-3 w-3" />
              Undo
            </button>
          )}
        </div>
      )}

      {/* Action buttons — awaiting_review: Approve / Reject */}
      {action.status === "awaiting_review" && (onComplete || onUndo) && (
        <div className="mt-3 flex items-center gap-2">
          {onComplete && (
            <button
              onClick={onComplete}
              className="inline-flex items-center gap-1.5 rounded-md bg-[oklch(0.88_0.18_145)] px-3 py-1.5 text-xs font-medium text-primary-foreground transition-colors hover:bg-[oklch(0.88_0.18_145)]/90"
            >
              <CheckCircle2 className="h-3 w-3" />
              Approve & Complete
            </button>
          )}
          {onUndo && (
            <button
              onClick={() => onUndo("in_progress")}
              className="inline-flex items-center gap-1.5 rounded-md border border-violet/30 bg-violet/10 px-3 py-1.5 text-xs font-medium text-violet transition-colors hover:bg-violet/20"
            >
              <Undo2 className="h-3 w-3" />
              Send Back
            </button>
          )}
        </div>
      )}

      {/* Undo for completed/skipped/failed */}
      {(action.status === "completed" || action.status === "skipped" || action.status === "failed") && onUndo && (
        <div className="mt-3">
          <button
            onClick={() => onUndo("suggested")}
            className="inline-flex items-center gap-1.5 rounded-md border border-border bg-background px-3 py-1.5 text-xs text-muted-foreground transition-colors hover:text-foreground"
          >
            <Undo2 className="h-3 w-3" />
            Undo
          </button>
        </div>
      )}

      {action.completedAt && (
        <div className="mt-2 flex items-center gap-1.5 font-mono text-[10px] text-muted-foreground">
          <Clock className="h-3 w-3" />
          {action.completedAt}
          {action.completedBy && (
            <>
              <span>·</span>
              <span>{CREW.find((c) => c.id === action.completedBy)?.name ?? action.completedBy}</span>
            </>
          )}
        </div>
      )}
    </div>
  );
}

// ── Severity badge ───────────────────────────────────────────────────────────

function SeverityBadge({ severity }: { severity: Incident["severity"] }) {
  const cfg = SEVERITY_CONFIG[severity];
  return (
    <span className={["inline-flex items-center gap-1.5 rounded-md border px-2 py-1 font-mono text-[11px] font-semibold tracking-wider", cfg.bg, cfg.border, cfg.color].join(" ")}>
      <Flame className="h-3.5 w-3.5" />
      {cfg.label}
    </span>
  );
}

// ── Status badge ─────────────────────────────────────────────────────────────

function StatusBadge({ status }: { status: Incident["status"] }) {
  const cfg = STATUS_CONFIG[status];
  return (
    <span className={["inline-flex items-center gap-1.5 rounded-md border border-border/60 bg-card/60 px-2 py-1 font-mono text-[11px] font-semibold tracking-wider", cfg.color].join(" ")}>
      <span className={["h-2 w-2 rounded-full", cfg.dot, status !== "RESOLVED" && "animate-pulse"].join(" ")} />
      {cfg.label}
    </span>
  );
}

// ── Main drawer ──────────────────────────────────────────────────────────────

interface IncidentDetailsDrawerProps {
  incident: Incident | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function IncidentDetailsDrawer({ incident, open, onOpenChange }: IncidentDetailsDrawerProps) {
  const [actions, setActions] = useState<IncidentAction[]>(incident?.actions ?? []);
  const [runningIndex, setRunningIndex] = useState<number | null>(null);
  const [incidentStatus, setIncidentStatus] = useState<Incident["status"]>(incident?.status ?? "TRIAGE");
  const [linkedTasks, setLinkedTasks] = useState<Task[]>([]);
  const [incidentTimeline, setIncidentTimeline] = useState<TimelineEvent[]>([]);

  // Derive linked tasks from tasks.json (source of truth: Task.linkedIncidentId)
  useEffect(() => {
    if (!incident) { setLinkedTasks([]); return; }
    let cancelled = false;
    getTasks().then((allTasks) => {
      if (cancelled) return;
      const derived = allTasks.filter((t) => t.linkedIncidentId === incident.id);
      setLinkedTasks(derived);
    }).catch(() => { if (!cancelled) setLinkedTasks([]); });
    return () => { cancelled = true; };
  }, [incident?.id]);

  const saveActions = (updatedActions: IncidentAction[]) => {
    if (!incident) return;
    fetch("/api/incidents/update", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: incident.id, actions: updatedActions }),
    }).catch((err) => console.error("[IncidentDetailsDrawer] Failed to save:", err));
  };

  const saveIncidentStatus = (newStatus: Incident["status"]) => {
    if (!incident) return;
    fetch("/api/incidents/status", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: incident.id, status: newStatus }),
    }).catch((err) => console.error("[IncidentDetailsDrawer] Failed to save status:", err));
  };

  // Sync actions when incident changes
  useEffect(() => {
    if (incident) {
      setActions(incident.actions);
      setIncidentStatus(incident.status);
    }
    setRunningIndex(null);
  }, [incident]);

  // Auto-transition to AWAITING_REVIEW when all actions are terminal
  useEffect(() => {
    if (!incident) return;
    const totalActions = (incident.actions ?? []).length;
    const terminalActions = (incident.actions ?? []).filter(
      (a) => a.status === "completed" || a.status === "skipped"
    ).length;
    if (totalActions > 0 && terminalActions === totalActions && incidentStatus === "MITIGATING") {
      setIncidentStatus("AWAITING_REVIEW");
      saveIncidentStatus("AWAITING_REVIEW");
    }
  }, [incident, incidentStatus]);

  // Load incident timeline
  useEffect(() => {
    if (!incident) return;
    getIncidentTimeline(incident.id).then(setIncidentTimeline);
  }, [incident?.id]);

  if (!incident) return null;

  const owner = CREW.find((c) => c.id === incident.owner);
  const completedActions = actions.filter((a) => a.status === "completed").length;
  const skippedActions = actions.filter((a) => a.status === "skipped").length;
  const totalActions = actions.length;
  const terminalActions = completedActions + skippedActions;
  const canResolve = totalActions > 0 && terminalActions === totalActions && incidentStatus !== "RESOLVED";

  const createTaskFromAction = (action: IncidentAction, idx: number) => {
    setRunningIndex(idx);
    const taskTitle = `[Dispatch] ${action.label}`;
    const taskNote = `Source: ${incident.id} — ${incident.title}\n${action.description}`;
    const suggestedAssignee = action.assignee || incident.owner;
    fetch("/api/tasks/add", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        id: `task-${incident.id}-${action.id}`,
        title: taskTitle,
        assignee: suggestedAssignee,
        status: "in_progress",
        ts: "just now",
        note: taskNote,
        incidentSource: incident.id,
      }),
    })
      .then((res) => res.json())
      .then((data) => {
        if (!data.ok) {
          console.warn("[IncidentDetailsDrawer] Server rejected duplicate:", data.message);
        }
      })
      .catch((err) => console.error("[IncidentDetailsDrawer] Failed to create task:", err))
      .finally(() => setRunningIndex(null));
  };

  const updateAction = (index: number, newStatus: IncidentAction["status"]) => {
    const now = new Date().toISOString().replace("T", " ").slice(0, 19);
    const updated = actions.map((a, i) => {
      if (i !== index) return a;
      return {
        ...a,
        status: newStatus,
        completedAt: (newStatus === "completed" || newStatus === "skipped" || newStatus === "failed") ? now : undefined,
        completedBy: (newStatus === "completed" || newStatus === "skipped" || newStatus === "failed") ? "Space Monkey" : undefined,
        // Link task when moving from suggested/queued to in_progress
        taskId: (newStatus === "in_progress" && !a.taskId) ? `task-${incident.id}-${a.id}` : a.taskId,
      };
    });
    setActions(updated);
    saveActions(updated);

    // Auto-transition incident status
    if (newStatus === "in_progress" && incidentStatus === "TRIAGE") {
      setIncidentStatus("MITIGATING");
      saveIncidentStatus("MITIGATING");
    }
  };

  const handleResolve = () => {
    setIncidentStatus("RESOLVED");
    saveIncidentStatus("RESOLVED");
    const now = new Date().toISOString().replace("T", " ").slice(0, 19);
    const updatedTimeline = [
      ...incident.timeline,
      { ts: now, message: `Incident resolved — ${completedActions}/${totalActions} actions completed`, actor: "Space Monkey" },
    ];
    // Also save the resolved timestamp
    fetch("/api/incidents/resolve", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: incident.id, resolved: now, timeline: updatedTimeline }),
    }).catch((err) => console.error("[IncidentDetailsDrawer] Failed to resolve:", err));
  };

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent
        side="right"
        className="w-full sm:max-w-lg overflow-y-auto border-l-border/60 bg-background"
      >
        {/* Header */}
        <SheetHeader className="space-y-4 text-left">
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0 flex-1">
              <SheetDescription className="font-mono text-[11px] text-muted-foreground tracking-wider">
                {incident.id}
              </SheetDescription>
              <SheetTitle className="mt-1 text-lg font-bold tracking-tight leading-snug text-foreground">
                {incident.title}
              </SheetTitle>
            </div>
          </div>

          {/* Badges row */}
          <div className="flex flex-wrap items-center gap-2">
            <SeverityBadge severity={incident.severity} />
            <StatusBadge status={incidentStatus} />
          </div>
        </SheetHeader>

        {/* Meta info */}
        <div className="mt-5 grid grid-cols-2 gap-3">
          <div className="rounded-lg border border-border/60 bg-card/30 p-3">
            <div className="flex items-center gap-1.5 text-muted-foreground">
              <User className="h-3.5 w-3.5" />
              <span className="font-mono text-[10px] uppercase tracking-wider">Owner</span>
            </div>
            <div className="mt-1.5 flex items-center gap-2">
              {owner && (
                <>
                  <span className="h-5 w-5 rounded flex items-center justify-center text-xs leading-none">{owner.avatar}</span>
                  <span className="text-sm font-medium text-foreground">{owner.name}</span>
                </>
              )}
            </div>
          </div>

          <div className="rounded-lg border border-border/60 bg-card/30 p-3">
            <div className="flex items-center gap-1.5 text-muted-foreground">
              <Clock className="h-3.5 w-3.5" />
              <span className="font-mono text-[10px] uppercase tracking-wider">Opened</span>
            </div>
            <div className="mt-1.5 text-sm font-medium text-foreground">
              {incident.opened}
            </div>
          </div>

          {incident.resolved && (
            <div className="rounded-lg border border-border/60 bg-card/30 p-3">
              <div className="flex items-center gap-1.5 text-muted-foreground">
                <CheckCircle2 className="h-3.5 w-3.5" />
                <span className="font-mono text-[10px] uppercase tracking-wider">Resolved</span>
              </div>
              <div className="mt-1.5 text-sm font-medium text-foreground">
                {incident.resolved}
              </div>
            </div>
          )}

          <div className="rounded-lg border border-border/60 bg-card/30 p-3">
            <div className="flex items-center gap-1.5 text-muted-foreground">
              <ListChecks className="h-3.5 w-3.5" />
              <span className="font-mono text-[10px] uppercase tracking-wider">Actions</span>
            </div>
            <div className="mt-1.5 text-sm font-medium text-foreground">
              {completedActions}/{totalActions} complete{skippedActions > 0 ? ` · ${skippedActions} skipped` : ""}
            </div>
          </div>
        </div>

        {/* Resolve button — only when all actions terminal */}
        {canResolve && (
          <div className="mt-4">
            <button
              onClick={handleResolve}
              className="w-full inline-flex items-center justify-center gap-2 rounded-lg bg-[oklch(0.88_0.18_145)] px-4 py-2.5 text-sm font-medium text-primary-foreground transition-colors hover:bg-[oklch(0.88_0.18_145)]/90"
            >
              <CheckCircle2 className="h-4 w-4" />
              Resolve Incident
            </button>
            {incidentStatus === "AWAITING_REVIEW" && (
              <p className="mt-2 text-xs text-muted-foreground text-center">
                All remediation actions verified — ready for resolution
              </p>
            )}
          </div>
        )}

        {/* Summary */}
        <div className="mt-5">
          <h3 className="font-mono text-[11px] uppercase tracking-[0.18em] text-muted-foreground/70">
            Summary
          </h3>
          <p className="mt-2 text-sm text-foreground/85 leading-relaxed">
            {incident.summary}
          </p>
        </div>

        {/* Tags */}
        {incident.tags.length > 0 && (
          <div className="mt-5">
            <h3 className="flex items-center gap-1.5 font-mono text-[11px] uppercase tracking-[0.18em] text-muted-foreground/70">
              <Tag className="h-3.5 w-3.5" />
              Tags
            </h3>
            <div className="mt-2 flex flex-wrap gap-1.5">
              {incident.tags.map((tag) => (
                <Pill key={tag}>#{tag}</Pill>
              ))}
            </div>
          </div>
        )}

        {/* Timeline */}
        {incident.timeline.length > 0 && (
          <div className="mt-6">
            <h3 className="font-mono text-[11px] uppercase tracking-[0.18em] text-muted-foreground/70">
              Timeline
            </h3>
            <div className="mt-3 pl-1">
              {incident.timeline.map((event, i) => (
                <TimelineItem
                  key={`${event.ts}-${i}`}
                  event={event}
                  isLast={i === incident.timeline.length - 1}
                />
              ))}
            </div>
          </div>
        )}

        {/* Response Actions */}
        {actions.length > 0 && (
          <div className="mt-6">
            <h3 className="font-mono text-[11px] uppercase tracking-[0.18em] text-muted-foreground/70">
              Response Actions
            </h3>
            <p className="mt-1 text-xs text-muted-foreground/60">
              Queue actions to dispatch them to the crew. Run creates a scheduler task.
            </p>
            <div className="mt-3 space-y-2">
              {actions.map((action, i) => (
                <ActionItem
                  key={`${action.id}-${i}`}
                  action={action}
                  index={i}
                  running={runningIndex === i}
                  onQueue={() => updateAction(i, "queued")}
                  onRun={() => { updateAction(i, "in_progress"); createTaskFromAction(action, i); }}
                  onSubmitReview={() => updateAction(i, "awaiting_review")}
                  onSkip={() => updateAction(i, "skipped")}
                  onFail={() => updateAction(i, "failed")}
                  onUndo={(newStatus) => updateAction(i, newStatus)}
                />
              ))}
            </div>
          </div>
        )}

        {/* Runbook — matched by incident type/title */}
        {(() => {
          const incidentType = (incident as any).type || "";
          const runbook = getRunbookForIncident(incidentType) || getRunbookForIncident(incident.title);
          if (!runbook) return null;
          return (
            <div className="mt-6 mb-6">
              <h3 className="font-mono text-[11px] uppercase tracking-[0.18em] text-muted-foreground/70 flex items-center gap-1.5">
                <ListChecks className="h-3.5 w-3.5" />
                Response Runbook
              </h3>
              <p className="mt-1 text-xs text-muted-foreground/60">
                {runbook.steps.length} steps · est. {runbook.totalEstimatedMinutes} min · {runbook.severity} severity
              </p>
              <div className="mt-3 space-y-2">
                {runbook.steps.map((step) => (
                  <div key={step.order} className="rounded-lg border border-border/60 bg-card/20 p-3">
                    <div className="flex items-start gap-2">
                      <span className="font-mono text-[10px] text-violet bg-violet/10 rounded px-1.5 py-0.5 shrink-0 mt-0.5">
                        {step.order}
                      </span>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center justify-between gap-2">
                          <span className="text-sm font-medium">{step.title}</span>
                          <span className="font-mono text-[10px] text-muted-foreground shrink-0">{step.estimatedMinutes}m · {step.owner}</span>
                        </div>
                        <p className="mt-1 text-xs text-muted-foreground/70">{step.description}</p>
                        <div className="mt-1.5 flex items-center gap-1">
                          <CheckCircle2 className="h-3 w-3 text-[oklch(0.88_0.18_145)]/50" />
                          <span className="text-[10px] text-muted-foreground/50">{step.successCriteria}</span>
                        </div>
                        {step.escalationTrigger && (
                          <div className="mt-1 flex items-center gap-1">
                            <AlertTriangle className="h-3 w-3 text-amber-500/50" />
                            <span className="text-[10px] text-amber-500/70">Escalate: {step.escalationTrigger}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              <p className="mt-2 text-[10px] text-muted-foreground/40 italic">Escalation: {runbook.escalationPath}</p>
            </div>
          );
        })()}

        {/* Incident Timeline — chronological history */}
        {incidentTimeline.length > 0 && (
          <div className="mt-6 mb-6">
            <h3 className="font-mono text-[11px] uppercase tracking-[0.18em] text-muted-foreground/70 flex items-center gap-1.5">
              <Clock className="h-3.5 w-3.5" />
              Incident Timeline
            </h3>
            <p className="mt-1 text-xs text-muted-foreground/60">
              {incidentTimeline.length} event{incidentTimeline.length > 1 ? "s" : ""}
            </p>
            <div className="mt-3 ml-2 border-l border-border/30 pl-3 space-y-2">
              {incidentTimeline.map((evt) => {
                const time = new Date(evt.ts).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" });
                return (
                  <div key={evt.id} className="flex items-start gap-2">
                    <span className="font-mono text-[10px] text-muted-foreground/40 shrink-0 mt-0.5 w-12">{time}</span>
                    <div className="min-w-0">
                      <span className="text-xs font-medium">{evt.title}</span>
                      {evt.actor && <span className="text-[10px] text-muted-foreground/50 ml-1">({evt.actor})</span>}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Linked Tasks / Operational Work — derived from Task.linkedIncidentId */}
        {linkedTasks.length > 0 && (
          <div className="mt-6 mb-6">
            <h3 className="font-mono text-[11px] uppercase tracking-[0.18em] text-muted-foreground/70">
              Operational Work
            </h3>
            <p className="mt-1 text-xs text-muted-foreground/60">
              {linkedTasks.length} task{linkedTasks.length > 1 ? "s" : ""} linked to this incident
            </p>
            <div className="mt-3 space-y-2">
              {linkedTasks.map(task => {
                const taskStatusColor =
                  task.status === "done" ? "text-[oklch(0.88_0.18_145)]" :
                  task.status === "in_progress" ? "text-violet" :
                  task.status === "awaiting_review" ? "text-amber-400" :
                  task.status === "triage" ? "text-[oklch(0.85_0.15_35)]" :
                  "text-muted-foreground";
                const taskStatusLabel =
                  task.status === "in_progress" ? "WORKING" :
                  task.status === "awaiting_review" ? "REVIEW" :
                  task.status === "triage" ? "TRIAGE" :
                  task.status.toUpperCase();
                return (
                  <div key={task.id} className="rounded-lg border border-border bg-card/30 p-3 flex items-center justify-between">
                    <div className="flex items-center gap-2 min-w-0">
                      <Play className="h-3.5 w-3.5 text-violet shrink-0" />
                      <div className="min-w-0">
                        <span className="text-sm font-medium truncate block">{task.title}</span>
                        <span className="text-[10px] font-mono text-muted-foreground">{task.id} · {task.assignee}</span>
                      </div>
                    </div>
                    <span className={`font-mono text-[10px] ${taskStatusColor} shrink-0 ml-2`}>{taskStatusLabel}</span>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </SheetContent>
    </Sheet>
  );
}
