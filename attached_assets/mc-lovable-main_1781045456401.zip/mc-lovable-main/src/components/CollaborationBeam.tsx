// CollaborationBeam — draws a pulsing dashed line between rooms of agents
// collaborating on the same incident (sharing linkedIncidentId).

import type { Task } from "@/lib/server-data/types";

type RoomId = "command" | "security" | "workshop" | "archive";

const AGENT_HOME: Record<string, RoomId> = {
  monkey: "command",
  lifesupport: "security",
  engineer: "workshop",
  archivist: "archive",
};

const ROOM_CENTERS: Record<RoomId, { x: number; y: number }> = {
  command:  { x: 25, y: 28 },
  security: { x: 75, y: 28 },
  workshop: { x: 25, y: 78 },
  archive:  { x: 75, y: 78 },
};

const ACCENT: Record<string, string> = {
  monkey:      "oklch(0.62 0.22 295)",
  lifesupport: "oklch(0.78 0.18 350)",
  engineer:    "oklch(0.78 0.18 200)",
  archivist:   "oklch(0.85 0.16 90)",
};

interface BeamProps {
  tasks: Task[];
}

interface Pair { a: string; b: string; }

export function CollaborationBeam({ tasks }: BeamProps) {
  // Group active tasks by linkedIncidentId — when ≥2 distinct agents work the
  // same incident, draw a beam between each unique pair of their rooms.
  const groups = new Map<string, Set<string>>();
  for (const t of tasks) {
    if (t.status === "done") continue;
    const key = t.linkedIncidentId || t.incidentSource;
    if (!key || !t.assignee || !AGENT_HOME[t.assignee]) continue;
    if (!groups.has(key)) groups.set(key, new Set());
    groups.get(key)!.add(t.assignee);
  }

  const pairs: Pair[] = [];
  const seen = new Set<string>();
  for (const set of groups.values()) {
    if (set.size < 2) continue;
    const ids = [...set];
    for (let i = 0; i < ids.length; i++) {
      for (let j = i + 1; j < ids.length; j++) {
        const key = [ids[i], ids[j]].sort().join("|");
        if (seen.has(key)) continue;
        seen.add(key);
        pairs.push({ a: ids[i], b: ids[j] });
      }
    }
  }

  if (pairs.length === 0) return null;

  return (
    <svg
      className="pointer-events-none absolute inset-0 z-[16] h-full w-full"
      viewBox="0 0 100 100"
      preserveAspectRatio="none"
      aria-hidden
    >
      <defs>
        {pairs.map((p, i) => {
          const ca = ACCENT[p.a];
          const cb = ACCENT[p.b];
          return (
            <linearGradient key={`g-${i}`} id={`beam-${i}`} x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor={ca} stopOpacity="0.75" />
              <stop offset="50%" stopColor="oklch(0.9 0.05 295)" stopOpacity="0.6" />
              <stop offset="100%" stopColor={cb} stopOpacity="0.75" />
            </linearGradient>
          );
        })}
      </defs>
      {pairs.map((p, i) => {
        const A = ROOM_CENTERS[AGENT_HOME[p.a]];
        const B = ROOM_CENTERS[AGENT_HOME[p.b]];
        return (
          <g key={`beam-line-${i}`} className="collab-beam">
            <line
              x1={A.x} y1={A.y} x2={B.x} y2={B.y}
              stroke={`url(#beam-${i})`}
              strokeWidth="0.35"
              strokeDasharray="1.2 1.2"
              strokeLinecap="round"
              vectorEffect="non-scaling-stroke"
            />
          </g>
        );
      })}
    </svg>
  );
}
