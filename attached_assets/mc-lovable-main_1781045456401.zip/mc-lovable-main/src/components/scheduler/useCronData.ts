import { useState, useCallback, useEffect } from "react";
import type { OpenClawCronJob } from "@/lib/server-data-types";

// ── Types ────────────────────────────────────────────────────────────────────

export interface CronError {
  id: string;
  jobName: string;
  jobId: string;
  jobEnabled: boolean;
  consecutiveErrors: number;
  lastError: string;
  lastErrorReason: string;
  lastRunAt: string;
  status: "new" | "in_progress" | "completed" | "skipped";
  createdAt: string;
}

export interface CronData {
  jobs: OpenClawCronJob[];
  errors: CronError[];
  loading: boolean;
  toggling: string | null;
  result: { id: string; message: string } | null;
  fetchCrons: () => void;
  handleToggle: (job: OpenClawCronJob) => Promise<void>;
  updateErrorStatus: (errorId: string, newStatus: CronError["status"]) => void;
}

// ── Hook ─────────────────────────────────────────────────────────────────────

export function useCronData(): CronData {
  const [jobs, setJobs] = useState<OpenClawCronJob[]>([]);
  const [errors, setErrors] = useState<CronError[]>([]);
  const [loading, setLoading] = useState(true);
  const [toggling, setToggling] = useState<string | null>(null);
  const [result, setResult] = useState<{ id: string; message: string } | null>(null);

  const fetchCrons = useCallback(() => {
    // Fetch both cron jobs and saved error statuses in parallel
    Promise.all([
      fetch("/api/crons").then((res) => res.json()),
      fetch("/api/cron-errors").then((res) => res.json()).catch(() => []),
    ])
      .then(([cronJobsData, savedErrors]) => {
        const cronJobs = cronJobsData as OpenClawCronJob[];
        setJobs(cronJobs);

        const savedMap = new Map(
          (savedErrors as Record<string, unknown>[]).map((e) => [e.id, e.status as CronError["status"]])
        );

        // Extract errors from jobs, merge with saved statuses
        // Use job ID directly as the error key (deduped by construction since we filter
        // unique jobs). Prefix with "cron-err-" to avoid collisions with other entities.
        const errorItems: CronError[] = cronJobs
          .filter((j) => (j.consecutiveErrors ?? 0) > 0 || j.status === "error")
          .map((j) => {
            // Strip legacy "err-" prefix from j.id to avoid double-prefix (cron-err-err-...)
            const cleanId = j.id.replace(/^err-/, "");
            const id = `cron-err-${cleanId}`;
            const savedStatus = savedMap.get(id) || savedMap.get(`err-${cleanId}`); // also check legacy key
            // Determine the effective status:
            // - If job is still failing AND was previously investigated → keep in_progress
            // - If job is still failing AND was resolved/skipped → the fix didn't work,
            //   show as "new" again (re-escalate)
            // - If job is still failing with no saved status → show as "new"
            let status: CronError["status"] = "new";
            if (savedStatus === "in_progress") {
              status = "in_progress"; // preserve investigation state
            }
            // Note: completed/skipped are intentionally NOT preserved here.
            // If the job fails again after being resolved, it shows as a new error.
            // This is the correct behavior — the previous resolution didn't fix it.
            return {
              id,
              jobName: j.name,
              jobId: j.id,
              jobEnabled: j.enabled,
              consecutiveErrors: j.consecutiveErrors ?? 0,
              lastError: j.lastError ?? "",
              lastErrorReason: j.lastErrorReason ?? "",
              lastRunAt: j.lastRun,
              status,
              createdAt: new Date().toISOString(),
            };
          })
          // Only show errors that are new or in_progress (not completed/skipped)
          .filter((e) => e.status === "new" || e.status === "in_progress");

        // Auto-clear + merge: remove errors whose jobs have recovered
        // (consecutiveErrors === 0 and status !== "error"), merge existing
        // in-memory statuses with fresh data, and add any new errors.
        const activeErrorJobIds = new Set(errorItems.map((e) => e.jobId));
        setErrors((prev) => {
          const freshIds = new Set(errorItems.map((e) => e.id));
          const prevIds = new Set(prev.map((e) => e.id));

          // Start with existing errors: keep only those still active,
          // merging fresh data while preserving in-memory status
          const merged = prev
            .filter((e) => {
              if (freshIds.has(e.id)) return true; // still failing, in fresh list
              if (!activeErrorJobIds.has(e.jobId)) return false; // job recovered → auto-clear
              return true;
            })
            .map((e) => {
              const fresh = errorItems.find((f) => f.id === e.id);
              return fresh ? { ...fresh, status: e.status } : e;
            });

          // Add any brand-new errors not in previous state
          const mergedIds = new Set(merged.map((e) => e.id));
          const newItems = errorItems.filter((e) => !mergedIds.has(e.id) && !prevIds.has(e.id));

          return [...merged, ...newItems];
        });

        setLoading(false);
      })
      .catch((err) => {
        console.error("[SchedulerPage] Failed to fetch crons:", err);
        setLoading(false);
      });
  }, []);

  useEffect(() => {
    fetchCrons();
    const interval = setInterval(fetchCrons, 5000);
    return () => clearInterval(interval);
  }, [fetchCrons]);

  const handleToggle = useCallback(async (job: OpenClawCronJob) => {
    setToggling(job.id);
    setResult(null);
    try {
      const res = await fetch("/api/cron-toggle", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: job.id, action: job.enabled ? "disable" : "enable" }),
      });
      const data = await res.json();
      if (data.ok) {
        setJobs((prev) =>
          prev.map((j) =>
            j.id === job.id ? { ...j, enabled: !job.enabled } : j
          )
        );
        setResult({ id: job.id, message: data.message || (job.enabled ? "Disabled" : "Enabled") });
      } else {
        setResult({ id: job.id, message: `Failed: ${data.error || "Unknown error"}` });
      }
    } catch (err) {
      setResult({ id: job.id, message: `Failed: ${err}` });
    }
    setToggling(null);
    setTimeout(() => setResult(null), 3000);
  }, []);

  const updateErrorStatus = useCallback((errorId: string, newStatus: CronError["status"]) => {
    const error = errors.find((e) => e.id === errorId);
    // If completing or skipping, remove from feed immediately (don't wait for next poll)
    if (newStatus === "completed" || newStatus === "skipped") {
      setErrors((prev) => prev.filter((e) => e.id !== errorId));
    } else {
      setErrors((prev) =>
        prev.map((e) =>
          e.id === errorId ? { ...e, status: newStatus } : e
        )
      );
    }
    // Persist to server
    fetch("/api/cron-errors", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ errorId, status: newStatus }),
    }).catch((err) => console.error("[SchedulerPage] Failed to save error status:", err));

    // When investigating, auto-create a task on the Tasks page
    if (newStatus === "in_progress" && error) {
      const taskTitle = `[Investigate] ${error.jobName}: ${error.lastErrorReason || error.lastError}`;
      const task = {
        id: `task-err-${Date.now().toString(36)}`,
        title: taskTitle,
        assignee: "monkey",
        status: "in_progress",
        priority: "P2",
        ts: "just now",
        note: `Auto-created from Scheduler Error Feed.\nCron job: ${error.jobName} (${error.jobId})\nError: ${error.lastError}\nConsecutive errors: ${error.consecutiveErrors}`,
        history: [{
          ts: new Date().toISOString(),
          action: "created",
          actor: "system",
          details: `Auto-created from error feed for ${error.jobName}`,
        }],
        errorId: errorId,
        jobId: error.jobId,
      };
      fetch("/api/tasks/add", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(task),
      }).then((res) => res.json()).then((data) => {
        if (data.ok) {
          console.log("[SchedulerPage] Created investigation task:", taskTitle);
        } else {
          console.error("[SchedulerPage] Failed to create task:", data.message);
        }
      }).catch((err) => console.error("[SchedulerPage] Failed to create task:", err));
    }

    // When marking resolved, update the error status to completed
    if (newStatus === "completed" && error) {
      console.log("[SchedulerPage] Error marked as completed:", error.jobName);
    }
  }, [errors]);

  return {
    jobs,
    errors,
    loading,
    toggling,
    result,
    fetchCrons,
    handleToggle,
    updateErrorStatus,
  };
}
