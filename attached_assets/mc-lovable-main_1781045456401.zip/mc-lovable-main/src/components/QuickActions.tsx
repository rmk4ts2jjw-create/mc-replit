import { useState, useEffect } from "react";
import {
  Download, RotateCcw, Trash2, Activity, Moon, RefreshCw,
  ExternalLink, Pause, Play, Power,
} from "lucide-react";
import {
  runBackup, restartGateway, clearCache, runFreerideRefresh,
  getSystemHealth, pauseQueue, resumeQueue, restartMissionControl,
} from "@/lib/server-data";
import { toggleDreaming, getDreamingState } from "@/lib/dreaming";

interface Action {
  id: string;
  label: string;
  description: string;
  icon: React.ReactNode;
  variant?: "default" | "warning" | "error" | "info";
  confirm?: boolean;
  action: () => Promise<{ ok: boolean; message: string }>;
}

export function QuickActions() {
  const [running, setRunning] = useState<string | null>(null);
  const [confirmAction, setConfirmAction] = useState<string | null>(null);
  const [result, setResult] = useState<{ id: string; message: string } | null>(null);
  const [queuePaused, setQueuePaused] = useState(false);
  const [dreamingEnabled, setDreamingEnabled] = useState<boolean | null>(null);

  // Fetch dreaming state on mount
  useEffect(() => {
    getDreamingState().then((res) => {
      if (res.ok) setDreamingEnabled(res.enabled);
    }).catch(() => setDreamingEnabled(false));
  }, []);

  const handleAction = async (action: Action) => {
    if (action.confirm && confirmAction !== action.id) {
      setConfirmAction(action.id);
      return;
    }
    setConfirmAction(null);
    setRunning(action.id);
    setResult(null);

    try {
      const res = await action.action();
      setResult({ id: action.id, message: res.message });
      if (action.id === "queue-toggle") {
        setQueuePaused((p) => !p);
      }
      if (action.id === "toggle-dreaming") {
        setDreamingEnabled(res.ok ? !dreamingEnabled : dreamingEnabled);
      }
    } catch (err) {
      setResult({ id: action.id, message: `Failed: ${err}` });
    }
    setRunning(null);
    setTimeout(() => setResult(null), 4000);
  };

  const makeActions = (): Action[] => [
    {
      id: "health",
      label: "System Health",
      description: "CPU, disk, memory snapshot",
      icon: <Activity className="h-4 w-4" />,
      variant: "info",
      action: async () => {
        const h = await getSystemHealth();
        return { ok: true, message: `Disk: ${h.disk} | CPU: ${h.cpu} | ${h.gateway}` };
      },
    },
    {
      id: "open-control-ui",
      label: "Open Control UI",
      description: "Launch localhost:18789",
      icon: <ExternalLink className="h-4 w-4" />,
      variant: "info",
      action: async () => {
        window.open("http://localhost:18789", "_blank");
        return { ok: true, message: "Control UI opened" };
      },
    },
    {
      id: "restart-mission-control",
      label: "Restart Mission Control",
      description: "Restart the dev server on port 3000",
      icon: <RotateCcw className="h-4 w-4" />,
      variant: "warning",
      confirm: true,
      action: async () => {
        const res = await restartMissionControl();
        return { ok: res.ok, message: res.message };
      },
    },
    {
      id: "queue-toggle",
      label: queuePaused ? "Resume Queue" : "Pause Queue",
      description: queuePaused ? "Resume task dispatch" : "Pause all task dispatch",
      icon: queuePaused ? <Play className="h-4 w-4" /> : <Pause className="h-4 w-4" />,
      variant: "default",
      action: async () => {
        if (queuePaused) {
          const res = await resumeQueue();
          return { ok: res.ok, message: res.message };
        } else {
          const res = await pauseQueue();
          return { ok: res.ok, message: res.message };
        }
      },
    },
    {
      id: "toggle-dreaming",
      label: dreamingEnabled ? "Dreaming: ON" : "Dreaming: OFF",
      description: dreamingEnabled
        ? "Memory consolidation active — click to disable"
        : "Memory consolidation paused — click to enable",
      icon: <Moon className={`h-4 w-4 ${dreamingEnabled ? "text-[oklch(0.88_0.18_145)]" : "text-muted-foreground"}`} />,
      variant: dreamingEnabled ? "info" : "default",
      action: async () => {
        const res = await toggleDreaming();
        return { ok: res.ok, message: res.message };
      },
    },
    {
      id: "refresh-models",
      label: "Refresh Models",
      description: "Re-run freeride model auto",
      icon: <RefreshCw className="h-4 w-4" />,
      action: async () => {
        const res = await runFreerideRefresh();
        return { ok: res.ok, message: res.message };
      },
    },
    {
      id: "backup",
      label: "Run Backup",
      description: "Full backup to WD MyCloud",
      icon: <Download className="h-4 w-4" />,
      action: async () => {
        const res = await runBackup();
        return { ok: res.ok, message: res.size };
      },
    },
    {
      id: "clear-cache",
      label: "Clear Cache",
      description: "Clear freeride and API caches",
      icon: <Trash2 className="h-4 w-4" />,
      action: async () => {
        const res = await clearCache();
        return { ok: res.ok, message: res.message };
      },
    },
    {
      id: "restart",
      label: "Restart Gateway",
      description: "Restart the OpenClaw gateway",
      icon: <RotateCcw className="h-4 w-4" />,
      variant: "warning",
      confirm: true,
      action: async () => {
        const res = await restartGateway();
        return { ok: res.ok, message: res.message };
      },
    },
  ];

  const ACTIONS = makeActions();

  return (
    <div className="space-y-2">
      {/* Dreaming status indicator */}
      {dreamingEnabled !== null && (
        <div className={`flex items-center gap-2 rounded-lg border px-3 py-2 text-xs ${
          dreamingEnabled
            ? "border-[oklch(0.30_0.04_265)] bg-[oklch(0.82_0.21_145)]/10"
            : "border-border/40 bg-card/20"
        }`}>
          <Power className={`h-3 w-3 ${dreamingEnabled ? "text-[oklch(0.88_0.18_145)]" : "text-muted-foreground/50"}`} />
          <span className={dreamingEnabled ? "text-[oklch(0.88_0.18_145)]" : "text-muted-foreground"}>
            Dreaming is {dreamingEnabled ? "ON" : "OFF"}
          </span>
          <span className="text-muted-foreground/50 ml-auto">
            {dreamingEnabled ? "Memory consolidation active" : "Paused"}
          </span>
        </div>
      )}

      {ACTIONS.map((action) => (
        <div key={action.id}>
          <button
            onClick={() => handleAction(action)}
            disabled={running !== null}
            className={[
              "w-full flex items-center gap-3 rounded-lg border px-3 py-2.5 text-sm transition-colors text-left",
              running === action.id
                ? "border-violet/60 bg-violet/10"
                : action.variant === "warning"
                ? "border-warning/30 bg-card/40 hover:border-warning/60 hover:bg-warning/5"
                : action.variant === "info"
                ? "border-cyan-accent/20 bg-card/40 hover:border-cyan-accent/50 hover:bg-cyan-accent/5"
                : "border-border bg-card/40 hover:border-violet/40 hover:bg-violet/5",
              running && running !== action.id ? "opacity-50" : "",
            ].join(" ")}
          >
            <span className={
              action.variant === "warning" ? "text-warning" :
              action.variant === "info" ? "text-cyan-accent" :
              "text-muted-foreground"
            }>
              {action.icon}
            </span>
            <div className="flex-1 min-w-0">
              <div className="font-medium">{action.label}</div>
              <div className="text-xs text-muted-foreground truncate">{action.description}</div>
            </div>
            {running === action.id && (
              <span className="text-xs text-violet animate-pulse shrink-0">running…</span>
            )}
            {result?.id === action.id && (
              <span className="text-xs text-[oklch(0.88_0.18_145)] shrink-0 max-w-[120px] truncate">{result.message}</span>
            )}
          </button>
          {confirmAction === action.id && (
            <div className="mt-1 rounded-md border border-warning/40 bg-warning/5 px-3 py-2 text-xs">
              <div className="text-warning font-medium mb-1">Are you sure?</div>
              <div className="flex gap-2">
                <button
                  onClick={() => handleAction(action)}
                  className="rounded bg-warning/20 px-2 py-1 text-warning hover:bg-warning/30"
                >
                  Yes, run
                </button>
                <button
                  onClick={() => setConfirmAction(null)}
                  className="rounded bg-muted px-2 py-1 text-muted-foreground hover:bg-muted/80"
                >
                  Cancel
                </button>
              </div>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}
