// src/lib/api.ts
// Direct API client for server operations that bypass createServerFn RPC issues

const API_BASE = "";

export async function apiSaveTasks(tasks: unknown[]): Promise<{ ok: boolean }> {
  const res = await fetch(`${API_BASE}/api/tasks`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(tasks),
  });
  if (!res.ok) throw new Error(`Save failed: ${res.status}`);
  return res.json();
}

export async function apiDispatchTask(task: {
  taskId: string;
  title: string;
  assignee: string;
}): Promise<{ ok: boolean; queueId?: string }> {
  const res = await fetch(`${API_BASE}/api/dispatch`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(task),
  });
  if (!res.ok) throw new Error(`Dispatch failed: ${res.status}`);
  return res.json();
}
