// src/lib/server-data-types.ts
// Types-only re-export — safe for client components (no node:fs leak)
export type {
  Task, TaskHistoryEntry, QueueItem, CronJob, OpenClawCronJob,
  SystemStats, AgentStatus, MemoryEntry, Doc, Project,
  Incident, IncidentEvent, IncidentAction, CreateIncidentInput,
  ActivityEvent, SearchResult, OpenClawStatus,
  ActionResult, SystemHealth, AwaitingReviewResult, CronToggleResult,
} from "./server-data/types";
export { WORKSPACE, OPENCLAW_DIR } from "./server-data/types";
