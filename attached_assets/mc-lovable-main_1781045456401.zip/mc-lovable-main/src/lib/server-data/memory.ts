// src/lib/server-data/memory.ts
// NOTE: node:fs is lazy-imported to avoid pulling it into client bundles.

import { createServerFn } from "@tanstack/react-start";
import { WORKSPACE, type MemoryEntry } from "./types";
import { readFileOrNull, extractTitle } from "./helpers";

export const getDailyLogs = createServerFn({ method: "GET" }).handler(async () => {
  try {
    const { existsSync, readdirSync, readFileSync } = await import("node:fs");
    const memDir = `${WORKSPACE}/memory`;
    if (!existsSync(memDir)) return [];
    const files = readdirSync(memDir)
      .filter((f) => /^\d{4}-\d{2}-\d{2}\.md$/.test(f))
      .sort()
      .reverse();
    return files.map((file) => {
      const body = readFileSync(`${memDir}/${file}`, "utf-8");
      const date = file.replace(".md", "");
      const words = body.split(/\s+/).filter(Boolean).length;
      return { date, words, title: extractTitle(body), body } as MemoryEntry;
    });
  } catch { return []; }
});

export const getLongTermMemory = createServerFn({ method: "GET" }).handler(async () => {
  return (await readFileOrNull(`${WORKSPACE}/MEMORY.md`)) || "# Long-Term Memory\n\nNo long-term memory file found.";
});
