// src/lib/server-data/docs.ts
// NOTE: node:fs is lazy-imported to avoid pulling it into client bundles.

import { createServerFn } from "@tanstack/react-start";
import { WORKSPACE, type Doc } from "./types";
import { extractTitle } from "./helpers";

export const getDocs = createServerFn({ method: "GET" }).handler(async () => {
  const docs: Doc[] = [];
  const exclude = new Set(["AGENTS.md", "SOUL.md", "IDENTITY.md", "USER.md", "TOOLS.md", "MEMORY.md", "HEARTBEAT.md", "BACKUP_GUIDE.md", "RECOVERY_GUIDE.md"]);

  try {
    const { readdirSync, readFileSync, statSync } = await import("node:fs");
    const files = readdirSync(WORKSPACE).filter((f) => f.endsWith(".md") && !exclude.has(f));
    for (const file of files) {
      const body = readFileSync(`${WORKSPACE}/${file}`, "utf-8");
      const stat = statSync(`${WORKSPACE}/${file}`);
      docs.push({
        id: `doc-${file}`,
        title: extractTitle(body),
        date: stat.mtime.toISOString().split("T")[0],
        type: "note",
        author: "Space Monkey",
        body,
      });
    }
  } catch { /* ignore */ }

  try {
    const { existsSync, readdirSync, readFileSync, statSync } = await import("node:fs");
    const memDir = `${WORKSPACE}/memory`;
    if (existsSync(memDir)) {
      const memFiles = readdirSync(memDir).filter((f) => f.endsWith(".md") && !/^\d{4}-\d{2}-\d{2}\.md$/.test(f));
      for (const file of memFiles) {
        const body = readFileSync(`${memDir}/${file}`, "utf-8");
        const stat = statSync(`${memDir}/${file}`);
        docs.push({
          id: `doc-mem-${file}`,
          title: extractTitle(body),
          date: stat.mtime.toISOString().split("T")[0],
          type: "note",
          author: "Space Monkey",
          body,
        });
      }
    }
  } catch { /* ignore */ }

  return docs.sort((a, b) => b.date.localeCompare(a.date));
});
