// src/lib/server-data/assets.ts
// Asset tracking — systems, services, and agents as first-class entities

export type AssetType = "service" | "agent" | "cron" | "infra";
export type AssetHealth = "healthy" | "degraded" | "down" | "unknown" | "standby";

export interface Asset {
  id: string;
  name: string;
  type: AssetType;
  status: AssetHealth;
  owner: string;
  healthCheckEndpoint?: string;
  dependencies: string[]; // asset IDs
  lastCheckTimestamp: string;
  consecutiveFailures: number;
  averageDurationMs?: number;
  errorRate?: number; // 0-1, recent window
  metadata: Record<string, string>;
}

// ── Default Assets ───────────────────────────────────────────────────────────

export const DEFAULT_ASSETS: Asset[] = [
  {
    id: "asset-gateway",
    name: "OpenClaw Gateway",
    type: "service",
    status: "healthy",
    owner: "lifesupport",
    healthCheckEndpoint: "http://localhost:18789/health",
    dependencies: [],
    lastCheckTimestamp: new Date().toISOString(),
    consecutiveFailures: 0,
    metadata: { port: "18789", version: "2026.5.28" },
  },
  {
    id: "asset-mc-dashboard",
    name: "Mission Control Dashboard",
    type: "service",
    status: "healthy",
    owner: "lifesupport",
    healthCheckEndpoint: "http://localhost:3000/",
    dependencies: ["asset-gateway"],
    lastCheckTimestamp: new Date().toISOString(),
    consecutiveFailures: 0,
    metadata: { port: "3000", framework: "TanStack Start + Vite" },
  },
  {
    id: "asset-monkey",
    name: "Space Monkey",
    type: "agent",
    status: "healthy",
    owner: "monkey",
    dependencies: ["asset-gateway"],
    lastCheckTimestamp: new Date().toISOString(),
    consecutiveFailures: 0,
    metadata: { role: "coordinator", model: "owl-alpha" },
  },
  {
    id: "asset-lifesupport",
    name: "Life Support Officer",
    type: "agent",
    status: "healthy",
    owner: "lifesupport",
    dependencies: ["asset-gateway"],
    lastCheckTimestamp: new Date().toISOString(),
    consecutiveFailures: 0,
    metadata: { role: "infrastructure", model: "owl-alpha" },
  },
  {
    id: "asset-engineer",
    name: "Systems Engineer",
    type: "agent",
    status: "standby",
    owner: "engineer",
    dependencies: ["asset-gateway"],
    lastCheckTimestamp: new Date().toISOString(),
    consecutiveFailures: 0,
    metadata: { role: "code", model: "owl-alpha" },
  },
  {
    id: "asset-archivist",
    name: "Station Archivist",
    type: "agent",
    status: "standby",
    owner: "archivist",
    dependencies: ["asset-gateway"],
    lastCheckTimestamp: new Date().toISOString(),
    consecutiveFailures: 0,
    metadata: { role: "knowledge", model: "owl-alpha" },
  },
  {
    id: "asset-freeride-update",
    name: "FreeRide Auto-Update",
    type: "cron",
    status: "healthy",
    owner: "lifesupport",
    dependencies: ["asset-gateway"],
    lastCheckTimestamp: new Date().toISOString(),
    consecutiveFailures: 0,
    metadata: { schedule: "0 6 * * * Europe/London", script: "~/.freeride/auto-update.sh" },
  },
  {
    id: "asset-sessions-cleanup",
    name: "Sessions Cleanup",
    type: "cron",
    status: "healthy",
    owner: "lifesupport",
    dependencies: ["asset-gateway"],
    lastCheckTimestamp: new Date().toISOString(),
    consecutiveFailures: 0,
    metadata: { schedule: "0 2 * * * UTC" },
  },
  {
    id: "asset-session-expiry",
    name: "Session Auto-Expiry",
    type: "cron",
    status: "healthy",
    owner: "lifesupport",
    dependencies: ["asset-gateway"],
    lastCheckTimestamp: new Date().toISOString(),
    consecutiveFailures: 0,
    metadata: { schedule: "0 4 * * * UTC" },
  },
];

/** Get all assets, optionally filtered by type */
export function getAssets(filter?: { type?: AssetType; status?: AssetHealth }): Asset[] {
  let result = [...DEFAULT_ASSETS];
  if (filter?.type) result = result.filter((a) => a.type === filter.type);
  if (filter?.status) result = result.filter((a) => a.status === filter.status);
  return result;
}

/** Get a single asset by ID */
export function getAsset(id: string): Asset | undefined {
  return DEFAULT_ASSETS.find((a) => a.id === id);
}

/** Get assets sorted by health (worst first) */
export function getAssetsByHealth(): Asset[] {
  const order: Record<AssetHealth, number> = { down: 0, degraded: 1, unknown: 2, standby: 3, healthy: 4 };
  return [...DEFAULT_ASSETS].sort((a, b) => order[a.status] - order[b.status]);
}

/** Get assets that depend on a given asset */
export function getDependents(assetId: string): Asset[] {
  return DEFAULT_ASSETS.filter((a) => a.dependencies.includes(assetId));
}

/** Summary counts */
export function getAssetSummary() {
  const byType: Record<AssetType, number> = { service: 0, agent: 0, cron: 0, infra: 0 };
  const byHealth: Record<AssetHealth, number> = { healthy: 0, degraded: 0, down: 0, unknown: 0, standby: 0 };
  for (const a of DEFAULT_ASSETS) {
    byType[a.type]++;
    byHealth[a.status]++;
  }
  return { total: DEFAULT_ASSETS.length, byType, byHealth };
}
