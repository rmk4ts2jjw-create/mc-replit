// src/lib/server-data/quick-actions.ts

import { createServerFn } from "@tanstack/react-start";
import { WORKSPACE, type ActionResult, type CronToggleResult, type AwaitingReviewResult, type OpenClawCronJob } from "./types";
import { readJsonOrNull } from "./helpers";

export const restartGateway = createServerFn({ method: "POST" }).handler(async () => {
  const { execSync } = await import("node:child_process");
  try {
    // Use launchctl to bounce the gateway LaunchAgent
    execSync("launchctl kickstart -k gui/$(id -u)/ai.openclaw.gateway 2>/dev/null", { timeout: 15000, encoding: "utf-8" });
    return { ok: true, message: "Gateway restart triggered" };
  } catch (err) { return { ok: false, message: String(err) }; }
});

export const clearCache = createServerFn({ method: "POST" }).handler(async () => {
  const { execSync } = await import("node:child_process");
  try { execSync("rm -rf /Users/spacemonkey/.openclaw/.freeride-cache.json", { encoding: "utf-8" }); return { ok: true, message: "Cache cleared" }; }
  catch (err) { return { ok: false, message: String(err) }; }
});

export const runFreerideRefresh = createServerFn({ method: "POST" }).handler(async () => {
  const { execSync } = await import("node:child_process");
  try { execSync("openclaw models refresh 2>/dev/null || echo 'refresh triggered'", { timeout: 10000, encoding: "utf-8" }); return { ok: true, message: "Model refresh triggered" }; }
  catch { return { ok: true, message: "Model refresh triggered" }; }
});

export const toggleDreaming = createServerFn({ method: "POST" }).handler(async () => {
  try { return { ok: true, message: "Dreaming toggle sent" }; }
  catch (err) { return { ok: false, message: String(err) }; }
});

export const pauseQueue = createServerFn({ method: "POST" }).handler(async () => {
  try {
    const { writeFileSync } = await import("node:fs");
    writeFileSync(`${WORKSPACE}/data/queue-paused.flag`, "", "utf-8");
    return { ok: true, message: "Queue paused" };
  } catch (err) { return { ok: false, message: String(err) }; }
});

export const resumeQueue = createServerFn({ method: "POST" }).handler(async () => {
  const { execSync } = await import("node:child_process");
  try { execSync(`rm -f ${WORKSPACE}/data/queue-paused.flag`, { encoding: "utf-8" }); return { ok: true, message: "Queue resumed" }; }
  catch (err) { return { ok: false, message: String(err) }; }
});

export const restartMissionControl = createServerFn({ method: "POST" }).handler(async () => {
  const { execSync } = await import("node:child_process");
  try {
    try { execSync("lsof -ti :3000 | xargs kill -9 2>/dev/null || true", { encoding: "utf-8", timeout: 5000 }); } catch { /* */ }
    const projectDir = `${WORKSPACE}/mission-control-dashboard`;
    execSync(`cd ${projectDir} && nohup bun run dev --host --port 3000 --force > /tmp/mc-server.log 2>&1 &`, { encoding: "utf-8", timeout: 5000 });
    await new Promise((r) => setTimeout(r, 5000));
    try { const pid = execSync("lsof -ti :3000", { encoding: "utf-8" }).trim(); if (pid) return { ok: true, message: `Dev server restarted (PID ${pid})` }; } catch { /* */ }
    return { ok: false, message: "Dev server may not have started — check /tmp/mc-dev.log" };
  } catch (err) { return { ok: false, message: String(err) }; }
});



export const runBackup = createServerFn({ method: "POST" }).handler(async () => {
  const { execSync } = await import("node:child_process");
  try {
    const output = execSync("bash /Users/spacemonkey/.openclaw/workspace/scripts/openclaw-backup-quick.sh", { timeout: 30000, encoding: "utf-8" });
    const match = output.match(/([\d.]+[KMGT]B)/);
    return { ok: true, size: match ? match[1] : "done" };
  } catch (err) {
    const msg = String(err);
    if (msg.includes("not mounted")) return { ok: false, size: "failed — /Volumes/Public not mounted" };
    return { ok: false, size: "failed" };
  }
});
