// src/lib/server-data/runbooks.ts
// Structured data model for incident response runbooks

export type IncidentType =
  | "cron-failure"
  | "rate-limit"
  | "service-down"
  | "dependency-break"
  | "vite-cache"
  | "disk-space"
  | "network"
  | "unknown";

export type RunbookSeverity = "P1" | "P2" | "P3" | "P4";

export interface RunbookStep {
  order: number;
  title: string;
  description: string;
  estimatedMinutes: number;
  owner: string; // role: "monkey" | "lifesupport" | "engineer" | "archivist" | "andre"
  successCriteria: string;
  escalationTrigger?: string; // if this step fails, escalate
}

export interface Runbook {
  id: string;
  incidentType: IncidentType;
  label: string;
  severity: RunbookSeverity;
  steps: RunbookStep[];
  totalEstimatedMinutes: number;
  requiredRoles: string[];
  escalationPath: string; // who to contact if runbook steps are insufficient
  lastUpdated: string;
  version: number;
}

// Default runbooks — these are advisory. Incident response is always context-dependent.
export const RUNBOOKS: Runbook[] = [
  {
    id: "rb-cron-failure",
    incidentType: "cron-failure",
    label: "Cron Job Failure",
    severity: "P2",
    totalEstimatedMinutes: 15,
    requiredRoles: ["monkey", "lifesupport"],
    escalationPath: "If cron fails 3+ consecutive times, escalate to Andre for manual review.",
    lastUpdated: "2026-06-03T00:00:00Z",
    version: 1,
    steps: [
      {
        order: 1,
        title: "Identify failing cron job",
        description: "Check the Scheduler page or /api/crons endpoint to identify which cron job failed. Note the error message and consecutive failure count.",
        estimatedMinutes: 2,
        owner: "monkey",
        successCriteria: "Failing cron job identified with error message",
        escalationTrigger: "Cannot identify which cron job failed",
      },
      {
        order: 2,
        title: "Check recent logs",
        description: "Review the cron job's recent execution history for patterns. Check if this is a first-time failure or recurring.",
        estimatedMinutes: 3,
        owner: "monkey",
        successCriteria: "Failure pattern identified (one-time vs recurring)",
        escalationTrigger: "Error is cryptic or has no known fix pattern",
      },
      {
        order: 3,
        title: "Apply standard fix",
        description: "For timeouts: check if the job duration exceeds limits. For rate limits: check model/API availability. For script errors: check the underlying script.",
        estimatedMinutes: 8,
        owner: "lifesupport",
        successCriteria: "Fix applied and verified",
        escalationTrigger: "Standard fix does not work after one attempt",
      },
      {
        order: 4,
        title: "Verify recovery",
        description: "Run the cron job manually if possible, or wait for the next scheduled run. Confirm it succeeds.",
        estimatedMinutes: 2,
        owner: "monkey",
        successCriteria: "Cron job runs successfully on next execution",
      },
    ],
  },
  {
    id: "rb-rate-limit",
    incidentType: "rate-limit",
    label: "Rate Limit Exhaustion (429)",
    severity: "P2",
    totalEstimatedMinutes: 10,
    requiredRoles: ["monkey"],
    escalationPath: "If rate limits persist after switching models, escalate to Andre to add OpenRouter credits.",
    lastUpdated: "2026-06-03T00:00:00Z",
    version: 1,
    steps: [
      {
        order: 1,
        title: "Confirm rate limit",
        description: "Check error feed for 429 errors. Note which model(s) are affected and the error rate.",
        estimatedMinutes: 1,
        owner: "monkey",
        successCriteria: "Rate limit confirmed — model(s) identified",
      },
      {
        order: 2,
        title: "Switch to fallback model",
        description: "If primary model is rate-limited, activate fallback model for affected operations.",
        estimatedMinutes: 3,
        owner: "monkey",
        successCriteria: "Fallback model serving requests",
        escalationTrigger: "All fallback models also rate-limited",
      },
      {
        order: 3,
        title: "Pause non-critical crons",
        description: "Disable cron jobs that use the affected model tier until rate limit resets. Prioritize critical infrastructure checks.",
        estimatedMinutes: 3,
        owner: "monkey",
        successCriteria: "Non-critical crons paused, critical crons on fallback",
      },
      {
        order: 4,
        title: "Monitor recovery",
        description: "Wait for rate limit window to reset (typically 1 minute or 24 hours depending on tier). Gradually restore paused jobs.",
        estimatedMinutes: 3,
        owner: "monkey",
        successCriteria: "All cron jobs restored and running normally",
      },
    ],
  },
  {
    id: "rb-vite-cache",
    incidentType: "vite-cache",
    label: "Vite Cache Corruption",
    severity: "P3",
    totalEstimatedMinutes: 5,
    requiredRoles: ["lifesupport"],
    escalationPath: "If clearing cache doesn't fix the issue, may be a dependency problem. Escalate to Andre.",
    lastUpdated: "2026-06-03T00:00:00Z",
    version: 1,
    steps: [
      {
        order: 1,
        title: "Verify corruption",
        description: "Check if Mission Control returns 504 (Outdated Optimize Dep) or similar Vite cache errors on port 3000.",
        estimatedMinutes: 1,
        owner: "lifesupport",
        successCriteria: "Vite cache error confirmed",
      },
      {
        order: 2,
        title: "Clear Vite cache",
        description: "Run `rm -rf node_modules/.vite .vite` in the mission-control-dashboard directory, then restart Vite with `bun run dev --host --port 3000`.",
        estimatedMinutes: 3,
        owner: "lifesupport",
        successCriteria: "Vite restarted, cache cleared",
      },
      {
        order: 3,
        title: "Verify fix",
        description: "Confirm Mission Control loads on port 3000 and returns HTTP 200.",
        estimatedMinutes: 1,
        owner: "lifesupport",
        successCriteria: "App loads cleanly, no cache errors",
      },
    ],
  },
  {
    id: "rb-service-down",
    incidentType: "service-down",
    label: "Service Down",
    severity: "P1",
    totalEstimatedMinutes: 20,
    requiredRoles: ["lifesupport", "monkey"],
    escalationPath: "If critical service (gateway, MC dashboard) cannot be restored in 30 min, Andre is awake.",
    lastUpdated: "2026-06-03T00:00:00Z",
    version: 1,
    steps: [
      {
        order: 1,
        title: "Identify affected service",
        description: "Determine which service is down: OpenClaw gateway, Mission Control dashboard, or external dependency.",
        estimatedMinutes: 2,
        owner: "lifesupport",
        successCriteria: "Affected service identified",
        escalationTrigger: "Cannot determine which service is affected",
      },
      {
        order: 2,
        title: "Check process status",
        description: "Use `openclaw status` for gateway, `curl localhost:3000` for MC, `ps aux | grep vite` for dev server.",
        estimatedMinutes: 3,
        owner: "lifesupport",
        successCriteria: "Process status determined (running, crashed, or zombie)",
      },
      {
        order: 3,
        title: "Restart service",
        description: "Gateway: `openclaw gateway restart`. MC: kill stale Vite process and relaunch. Document what killed it.",
        estimatedMinutes: 5,
        owner: "lifesupport",
        successCriteria: "Service restarted and responding",
        escalationTrigger: "Service fails to restart or crashes immediately",
      },
      {
        order: 4,
        title: "Root cause check",
        description: "Check if OOM, disk full, or dependency change caused the crash. Update health-log.md.",
        estimatedMinutes: 7,
        owner: "monkey",
        successCriteria: "Root cause identified or marked as intermittent",
      },
      {
        order: 5,
        title: "Verify stability",
        description: "Monitor the service for 5 minutes to confirm it stays up. Verify dependent services are also functional.",
        estimatedMinutes: 3,
        owner: "lifesupport",
        successCriteria: "Service stable for 5+ minutes",
      },
    ],
  },
  {
    id: "rb-disk-space",
    incidentType: "disk-space",
    label: "Disk Space Low",
    severity: "P2",
    totalEstimatedMinutes: 15,
    requiredRoles: ["lifesupport", "monkey"],
    escalationPath: "If disk is critically full (>95%) and cleanup doesn't free enough space, escalate to Andre.",
    lastUpdated: "2026-06-03T00:00:00Z",
    version: 1,
    steps: [
      {
        order: 1,
        title: "Check disk usage",
        description: "Run `df -h` to check disk usage. Identify which partition is full.",
        estimatedMinutes: 1,
        owner: "lifesupport",
        successCriteria: "Disk usage confirmed, partition identified",
      },
      {
        order: 2,
        title: "Find large files/directories",
        description: "Run `du -sh /* 2>/dev/null | sort -rh | head -20` to find space hogs.",
        estimatedMinutes: 3,
        owner: "lifesupport",
        successCriteria: "Largest consumers identified",
      },
      {
        order: 3,
        title: "Safe cleanup",
        description: "Clear stale logs, node_modules in deleted projects, old backups, Vite cache. Never delete without Andre: workspace files, .openclaw config.",
        estimatedMinutes: 10,
        owner: "monkey",
        successCriteria: "Disk usage below 85%",
        escalationTrigger: "Cannot free enough space with safe cleanup alone",
      },
      {
        order: 4,
        title: "Verify and log",
        description: "Confirm disk is healthy. Update health-log.md with what was cleaned.",
        estimatedMinutes: 1,
        owner: "monkey",
        successCriteria: "Disk healthy, cleanup logged",
      },
    ],
  },
];

/** Look up the best matching runbook for an incident type */
export function getRunbookForIncident(incidentType: string): Runbook | undefined {
  // Direct match
  const direct = RUNBOOKS.find((r) => r.incidentType === incidentType);
  if (direct) return direct;

  // Fuzzy match by label
  const lower = incidentType.toLowerCase();
  const fuzzy = RUNBOOKS.find(
    (r) =>
      lower.includes(r.incidentType) ||
      r.incidentType.includes(lower) ||
      lower.includes(r.label.toLowerCase())
  );
  if (fuzzy) return fuzzy;

  return undefined;
}

/** Get all runbooks matching a severity level */
export function getRunbooksBySeverity(severity: RunbookSeverity): Runbook[] {
  return RUNBOOKS.filter((r) => r.severity === severity);
}

// ── Incident Type Classification ─────────────────────────────────────────────

interface TypePattern {
  type: IncidentType;
  severity: RunbookSeverity;
  keywords: string[];
}

const TYPE_PATTERNS: TypePattern[] = [
  { type: "cron-failure", severity: "P2", keywords: ["cron", "job", "scheduled", "timeout", "cron job", "dispatching"] },
  { type: "rate-limit", severity: "P2", keywords: ["429", "rate limit", "too many request", "throttl", "quota", "free-models-per"] },
  { type: "service-down", severity: "P1", keywords: ["down", "offline", "not responding", "connection refused", "unreachable", "crashed"] },
  { type: "dependency-break", severity: "P2", keywords: ["import", "module", "dependency", "resolve", "npm", "package", "version"] },
  { type: "vite-cache", severity: "P3", keywords: ["vite", "cache", "optimize dep", "504", "outdated optimize", "corrupt"] },
  { type: "disk-space", severity: "P2", keywords: ["disk", "space", "storage", "full", "no space", "out of space", "df"] },
  { type: "network", severity: "P2", keywords: ["network", "dns", "resolve", "timeout", "connection", "socket", "tls", "ssl"] },
];

/** Auto-detect incident type from error message and/or title. Returns best match with confidence. */
export function classifyIncident(title: string, error?: string): { type: IncidentType; severity: RunbookSeverity; confidence: number } {
  const text = `${title} ${error || ""}`.toLowerCase();
  let best: { type: IncidentType; severity: RunbookSeverity; score: number } | null = null;

  for (const pattern of TYPE_PATTERNS) {
    let score = 0;
    for (const kw of pattern.keywords) {
      if (text.includes(kw)) score += 1;
    }
    if (score > 0 && (!best || score > best.score)) {
      best = { type: pattern.type, severity: pattern.severity, score };
    }
  }

  if (best) {
    // Normalize confidence: 1 keyword = 0.5, 2+ = 0.8, 3+ = 1.0
    const confidence = best.score >= 3 ? 1.0 : best.score >= 2 ? 0.8 : 0.5;
    return { type: best.type, severity: best.severity, confidence };
  }

  return { type: "unknown", severity: "P3", confidence: 0 };
}

/** Auto-suggest a runbook based on incident title and error */
export function suggestRunbook(title: string, error?: string): { runbook: Runbook | undefined; confidence: number } {
  const { type, confidence } = classifyIncident(title, error);
  if (type === "unknown" || confidence === 0) return { runbook: undefined, confidence: 0 };
  const runbook = getRunbookForIncident(type);
  return { runbook, confidence };
}
