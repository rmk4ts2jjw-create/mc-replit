// src/lib/server-data/crons.ts

import { createServerFn } from "@tanstack/react-start";
import { OPENCLAW_DIR, type CronJob } from "./types";
import { readJsonOrNull } from "./helpers";

export const getCronJobs = createServerFn({ method: "GET" }).handler(async () => {
  const cfg = await readJsonOrNull<Record<string, unknown>>(`${OPENCLAW_DIR}/openclaw.json`);
  if (!cfg || !Array.isArray(cfg.cron)) return [];
  return (cfg.cron as Record<string, unknown>[]).map((job, i) => {
    const j = job as Record<string, unknown>;
    return {
      id: String(j.id || `cron-${i}`),
      name: String(j.name || j.schedule || `Job ${i + 1}`),
      schedule: String(j.schedule || ""),
      nextRun: j.enabled !== false ? "active" : "disabled",
      enabled: j.enabled !== false,
      description: String((j.payload as Record<string, unknown>)?.message || (j.payload as Record<string, unknown>)?.text || "").slice(0, 120),
    };
  });
});
