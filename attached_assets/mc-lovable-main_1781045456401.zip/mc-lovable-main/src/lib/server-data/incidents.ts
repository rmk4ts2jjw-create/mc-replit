// src/lib/server-data/incidents.ts

import { createServerFn } from "@tanstack/react-start";
// node:fs lazy-imported below to avoid client bundle leak
import { WORKSPACE, type Incident, type CreateIncidentInput, type IncidentEvent, type IncidentAction } from "./types";
import { readJsonOrNull } from "./helpers";
import { generateResponseActions } from "@/lib/incident-actions";

export const getIncidents = createServerFn({ method: "GET" }).handler(async () => {
  const data = await readJsonOrNull<Incident[]>(`${WORKSPACE}/data/incidents.json`);
  return data ?? [];
});

// ── Internal helpers (not exported as server fns) ─────────────────────────────
// Server-only helpers — node:fs lazy-imported to avoid client bundle leak.

async function readIncidentsList(): Promise<Incident[]> {
  const { readFileSync } = await import("node:fs");
  const p = `${WORKSPACE}/data/incidents.json`;
  try { return JSON.parse(readFileSync(p, "utf-8")) || []; } catch { return []; }
}

async function writeIncidentsList(incs: Incident[]): Promise<void> {
  const { writeFileSync } = await import("node:fs");
  writeFileSync(`${WORKSPACE}/data/incidents.json`, JSON.stringify(incs, null, 2), "utf-8");
}

function nextIncidentId(incs: Incident[]): string {
  const nums = incs.map(i => {
    const m = i.id.match(/INC-(\d+)/);
    return m ? parseInt(m[1]) : 0;
  });
  return `INC-${String(Math.max(0, ...nums) + 1).padStart(3, "0")}`;
}

export const createIncident = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => d as CreateIncidentInput)
  .handler(async ({ data }) => {
    const incs = await readIncidentsList();
    const now = new Date().toISOString();
    const dup = incs.find(i =>
      i.status !== "RESOLVED" &&
      i.title === data.title &&
      i.tags?.includes(data.source)
    );
    if (dup) return { ok: true, id: dup.id, duplicate: true };
    const incident: Incident = {
      id: nextIncidentId(incs),
      title: data.title,
      severity: data.severity,
      status: "TRIAGE",
      owner: data.owner,
      acknowledged: false,
      escalated: false,
      opened: now,
      lastActivity: now,
      summary: data.summary,
      tags: [...data.tags, data.source],
      timeline: [
        { ts: now, message: `Auto-detected by ${data.source}`, actor: "system" },
        { ts: now, message: `Generated ${generateResponseActions(data.title, data.severity, data.tags, data.owner).length} response actions`, actor: "system" },
      ],
      actions: generateResponseActions(data.title, data.severity, data.tags, data.owner),
      linkedTasks: [],
    };
    incs.unshift(incident);
    await writeIncidentsList(incs);
    return { ok: true, id: incident.id };
  });
