// src/lib/server-data/projects.ts

import { createServerFn } from "@tanstack/react-start";
import { WORKSPACE, type Project } from "./types";
import { readJsonOrNull } from "./helpers";

export const getProjects = createServerFn({ method: "GET" }).handler(async () => {
  const data = await readJsonOrNull<Project[]>(`${WORKSPACE}/data/projects.json`);
  return data ?? [];
});
