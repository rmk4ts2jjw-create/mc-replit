// src/lib/server-data.ts — barrel export for all server data functions
// Split into domain modules: server-data/{tasks,crons,memory,docs,projects,incidents,search,activity,system,agent-status,quick-actions,openclaw-status}.ts

export type {
  // Types
  Task, TaskHistoryEntry, QueueItem, CronJob, OpenClawCronJob,
  SystemStats, AgentStatus, MemoryEntry, Doc, Project,
  Incident, IncidentEvent, IncidentAction, CreateIncidentInput,
  ActivityEvent, SearchResult, OpenClawStatus,
  ActionResult, SystemHealth, AwaitingReviewResult, CronToggleResult,
} from "./server-data/types";
export { WORKSPACE, OPENCLAW_DIR } from "./server-data/types";

export { getTasks, saveTasks, dispatchTask, getQueue, getBacklogCount } from "./server-data/tasks";
export { getCronJobs } from "./server-data/crons";
export { getDailyLogs, getLongTermMemory } from "./server-data/memory";
export { getDocs } from "./server-data/docs";
export { getProjects } from "./server-data/projects";
export { getIncidents, createIncident } from "./server-data/incidents";
export { search } from "./server-data/search";
export { getActivityFeed } from "./server-data/activity";
export { getSystemStats, getSystemHealth } from "./server-data/system";
export { getAgentStatus } from "./server-data/agent-status";
export {
  restartGateway, clearCache, runFreerideRefresh, toggleDreaming,
  pauseQueue, resumeQueue, restartMissionControl, runBackup,
} from "./server-data/quick-actions";
export { getOpenClawStatus, getOpenClawCrons, getAwaitingReviewCount } from "./server-data/openclaw-status";
