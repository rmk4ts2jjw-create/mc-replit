// src/lib/build-info.ts
// Build version info — injected at build/dev time via Vite env vars

export const BUILD_HASH = import.meta.env.VITE_BUILD_HASH || "dev";
export const BUILD_TIME = import.meta.env.VITE_BUILD_TIME || new Date().toISOString();

export function getBuildLabel(): string {
  const d = new Date(BUILD_TIME);
  return d.toLocaleString("en-GB", { timeZone: "Europe/London" }) + " UTC+1";
}
