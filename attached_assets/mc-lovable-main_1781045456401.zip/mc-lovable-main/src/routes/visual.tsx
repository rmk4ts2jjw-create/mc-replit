// src/routes/visual.tsx
// Agent Office — the living, animated station view

import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/PageHeader";
import { AgentOffice } from "@/components/AgentOffice";
import { AmbientStation } from "@/components/AmbientStation";
import { StationFloorplan } from "@/components/StationFloorplan";
import { CelebrationOverlay } from "@/components/CelebrationOverlay";
import { CREW } from "@/lib/crew";
import { getAgentStatus, getSystemStats, getIncidents } from "@/lib/server-data";
import { useState } from "react";
import type { AgentStatus } from "@/lib/server-data-types";

export const Route = createFileRoute("/visual")({
  head: () => ({ meta: [{ title: "Agent Office — Mission Control" }] }),
  loader: async () => {
    const [agents, stats, incidents] = await Promise.all([
      getAgentStatus(),
      getSystemStats(),
      getIncidents(),
    ]);
    return { agents, stats, incidents };
  },
  component: VisualPage,
});

function VisualPage() {
  const { agents, stats } = Route.useLoaderData();
  const [visitingAgentId, setVisitingAgentId] = useState<string | null>(null);

  const typedAgents = agents as AgentStatus[];
  const mood: "calm" | "busy" | "alert" | "critical" =
    stats.gatewayStatus !== "running" ? "critical" :
    typedAgents.filter((a) => a.status === "active" && a.tasksActive > 0).length >= 2 ? "busy" : "calm";

  return (
    <>
      <PageHeader icon="🎮" title="Agent Office">
        A persistent orbital workspace where the AI crew works, collaborates, and maintains the station in real time.
      </PageHeader>

      <AmbientStation mood={mood}>
        <StationFloorplan enableVisits onVisitingAgentChange={setVisitingAgentId}>
          {CREW.map((member) => {
            const liveStatus = typedAgents.find((a) => a.id === member.id);
            const isAway = visitingAgentId === member.id;
            const tasksActive = liveStatus?.tasksActive ?? 0;
            const status: "idle" | "working" = liveStatus?.status === "active" && tasksActive > 0 ? "working" : "idle";
            let workload: 0 | 1 | 2 | 3 | 4 = 0;
            if (tasksActive >= 5) workload = 4;
            else if (tasksActive >= 3) workload = 3;
            else if (tasksActive === 2) workload = 2;
            else if (tasksActive === 1) workload = 1;
            return (
              <AgentOffice
                key={member.id}
                crew={member}
                liveStatus={liveStatus ? {
                  id: liveStatus.id,
                  name: liveStatus.name,
                  status,
                  currentAction: liveStatus.currentAction,
                  tasksActive,
                  workload,
                } : undefined}
                isAway={isAway}
              />
            );
          })}
        </StationFloorplan>
        <CelebrationOverlay active={false} />
      </AmbientStation>
    </>
  );
}
