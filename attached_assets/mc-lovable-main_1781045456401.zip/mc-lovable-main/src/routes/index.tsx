import { createFileRoute } from "@tanstack/react-router";
import { Dashboard } from "@/components/Dashboard";
import { getSystemStats, getAgentStatus, getActivityFeed, getIncidents, getTasks } from "@/lib/server-data";
import type { ActivityEvent } from "@/lib/server-data-types";
import type { Incident } from "@/lib/server-data-types";

export const Route = createFileRoute("/")({
  head: () => ({ meta: [{ title: "Mission Control — Dashboard" }] }),
  loader: async () => {
    const [stats, agents, incidents, allTasks] = await Promise.all([
      getSystemStats(),
      getAgentStatus(),
      getIncidents().catch(() => [] as Incident[]),
      getTasks().catch(() => []),
    ]);
    let activity: ActivityEvent[] = [];
    try { activity = await getActivityFeed(); } catch { /* ignore */ }

    return { agents, stats, activity, incidents, allTasks };
  },
  component: HomePage,
});

function HomePage() {
  const { agents, stats, activity, incidents, allTasks } = Route.useLoaderData();
  return (
    <Dashboard
      agents={agents}
      systemStats={stats}
      activity={activity}
      incidents={incidents}
      allTasks={allTasks}
    />
  );
}
