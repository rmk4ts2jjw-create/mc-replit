import { createFileRoute } from "@tanstack/react-router";
import { PageHeader, Pill } from "@/components/PageHeader";
import { getSystemStats, getAgentStatus, getOpenClawStatus } from "@/lib/server-data";
import type { SystemStats, AgentStatus, OpenClawStatus } from "@/lib/server-data-types";
import { QuickActions } from "@/components/QuickActions";
import { ExternalLink } from "lucide-react";

export const Route = createFileRoute("/settings")({
  head: () => ({ meta: [{ title: "Settings — Mission Control" }] }),
  loader: async () => {
    const [stats, agents, openclaw] = await Promise.all([getSystemStats(), getAgentStatus(), getOpenClawStatus()]);
    return { stats, agents, openclaw };
  },
  component: SettingsPage,
});

function SettingsPage() {
  const { stats, agents, openclaw } = Route.useLoaderData() as { stats: SystemStats; agents: AgentStatus[]; openclaw: OpenClawStatus };

  return (
    <>
      <PageHeader icon="⚙" title="Settings" meta="Station configuration & quick actions">
        One-click operations and system overview.
      </PageHeader>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Quick Actions — takes 1 column */}
        <div className="rounded-xl border border-border bg-card/40 p-5">
          <div className="font-mono text-[10px] tracking-[0.25em] text-muted-foreground mb-4">QUICK ACTIONS</div>
          <QuickActions />
        </div>

        {/* Right side — 2 columns */}
        <div className="lg:col-span-2 space-y-4">
          {/* OpenClaw Status Bridge */}
          <div className="rounded-xl border border-border bg-card/40 p-5">
            <div className="flex items-center justify-between mb-4">
              <div className="font-mono text-[10px] tracking-[0.25em] text-muted-foreground">OPENCLAW STATUS</div>
              <a
                href={openclaw.dashboard}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground transition-colors"
              >
                Control UI <ExternalLink className="h-3 w-3" />
              </a>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              <StatusCard label="Gateway" value={openclaw.gateway} accent="online" />
              <StatusCard label="Version" value={openclaw.version} />
              <StatusCard label="Model" value={openclaw.model.split("/").pop() || openclaw.model} />
              <StatusCard label="Context" value={openclaw.ctx} />
              <StatusCard label="Sessions" value={String(openclaw.sessions)} />
              <StatusCard label="Heartbeat" value={openclaw.heartbeat} />
              <StatusCard label="Channel" value={openclaw.channel} />
              <StatusCard label="Memory" value={openclaw.memoryPlugin} />
              <StatusCard label="Tasks" value={`${openclaw.tasksActive} active`} />
            </div>
          </div>

          {/* System Stats */}
          <div className="rounded-xl border border-border bg-card/40 p-5">
            <div className="font-mono text-[10px] tracking-[0.25em] text-muted-foreground mb-4">SYSTEM</div>
            <div className="grid grid-cols-2 gap-3">
              <InfoRow label="Hostname" value={stats.hostname} />
              <InfoRow label="OpenClaw" value={stats.openclawVersion} />
              <InfoRow label="Model" value={stats.model.split("/").pop() || stats.model} />
              <InfoRow label="Gateway" value={stats.gatewayStatus} accent="online" />
              <InfoRow label="Active Crons" value={`${stats.activeCrons}/${stats.totalCrons}`} />
              <InfoRow label="Workspace" value={`${stats.workspaceFiles} files`} />
            </div>
          </div>

          {/* Crew Status */}
          <div className="rounded-xl border border-border bg-card/40 p-5">
            <div className="font-mono text-[10px] tracking-[0.25em] text-muted-foreground mb-4">CREW STATUS</div>
            <div className="space-y-3">
              {agents.map((a) => (
                <div key={a.id} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span>{a.emoji}</span>
                    <span className="text-sm">{a.name}</span>
                    <span className="text-xs text-muted-foreground">({a.tasksActive} tasks)</span>
                  </div>
                  <Pill variant={a.status === "active" ? "online" : "warning"}>{a.status}</Pill>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

function StatusCard({ label, value, accent }: { label: string; value: string; accent?: string }) {
  return (
    <div className="rounded-lg border border-border/60 bg-card/30 p-2.5">
      <div className="font-mono text-[9px] tracking-[0.2em] text-muted-foreground uppercase">{label}</div>
      <div className={`mt-0.5 font-mono text-xs truncate ${accent === "online" ? "text-[oklch(0.88_0.18_145)]" : "text-foreground"}`}>
        {value}
      </div>
    </div>
  );
}

function InfoRow({ label, value, accent }: { label: string; value: string; accent?: string }) {
  return (
    <div className="flex items-center justify-between text-sm">
      <span className="text-muted-foreground">{label}</span>
      <span className={`font-mono ${accent ? `text-[oklch(0.88_0.18_145)]` : ""}`}>{value}</span>
    </div>
  );
}
