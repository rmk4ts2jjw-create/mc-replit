import { createFileRoute } from "@tanstack/react-router";
import { PageHeader, Pill } from "@/components/PageHeader";
import { getCrew } from "@/lib/crew";
import { getProjects } from "@/lib/server-data";
import type { Project } from "@/lib/server-data-types";

export const Route = createFileRoute("/projects")({
  head: () => ({ meta: [{ title: "Projects — Mission Control" }] }),
  loader: async () => {
    return await getProjects();
  },
  component: ProjectsPage,
});

const accentBorder: Record<string, string> = {
  violet: "border-l-violet",
  cyan: "border-l-cyan-accent",
  warning: "border-l-warning",
  pink: "border-l-pink-accent",
};

const accentBar: Record<string, string> = {
  violet: "bg-violet",
  cyan: "bg-cyan-accent",
  warning: "bg-warning",
  pink: "bg-pink-accent",
};

const statusVariant: Record<string, "online" | "violet" | "default"> = {
  active: "violet",
  shipping: "online",
  paused: "default",
};

function ProjectsPage() {
  const PROJECTS = Route.useLoaderData() as Project[];

  return (
    <>
      <PageHeader icon="🚀" title="Projects" meta={`${PROJECTS.length} active`}>
        Initiatives connecting tasks, memory, and docs.
      </PageHeader>

      {PROJECTS.length === 0 ? (
        <div className="rounded-xl border border-dashed border-border/80 bg-card/30 px-6 py-14 text-center">
          <div className="font-mono text-xs tracking-[0.25em] text-muted-foreground">— NO PROJECTS —</div>
          <div className="mt-3 text-sm text-muted-foreground">No projects found.</div>
        </div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2">
          {PROJECTS.map((p) => {
            const lead = p.lead ? getCrew(p.lead) : null;
            return (
              <div
                key={p.id}
                className={`rounded-xl border border-border bg-card/60 border-l-4 ${accentBorder[p.accent] || "border-l-violet"} p-5`}
              >
                <div className="flex items-start justify-between gap-3">
                  <h3 className="font-bold">{p.name}</h3>
                  <Pill variant={statusVariant[p.status] || "default"}>{p.status}</Pill>
                </div>
                <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{p.description}</p>
                <div className="mt-4">
                  <div className="flex items-center justify-between text-[11px] font-mono text-muted-foreground mb-1">
                    <span>progress</span>
                    <span>{p.progress}%</span>
                  </div>
                  <div className="h-1.5 w-full rounded-full bg-muted overflow-hidden">
                    <div className={`h-full ${accentBar[p.accent] || "bg-violet"}`} style={{ width: `${p.progress}%` }} />
                  </div>
                </div>
                <div className="mt-4 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2 text-muted-foreground">
                    {lead && (
                      <span className="h-5 w-5 rounded flex items-center justify-center text-xs leading-none border border-border">{lead.avatar}</span>
                    )}
                    <span>lead · {lead?.name}</span>
                  </div>
                  <div className="flex items-center gap-3 font-mono text-muted-foreground">
                    <span>{p.tasks} tasks</span>
                    <span>·</span>
                    <span>{p.lastActivity}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </>
  );
}
