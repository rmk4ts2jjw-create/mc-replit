// src/routes/assets.tsx
// Asset View — dedicated page showing all assets and their health status
import { useState, useMemo } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/PageHeader";
import {
  getAssets,
  getAssetSummary,
  type Asset,
  type AssetType,
  type AssetHealth,
} from "@/lib/server-data/assets";
import {
  Activity,
  Bot,
  Clock,
  Cpu,
  HardDrive,
  Heart,
  HeartCrack,
  HelpCircle,
  Server,
  Shield,
  Wrench,
  Zap,
} from "lucide-react";

export const Route = createFileRoute("/assets")({
  head: () => ({ meta: [{ title: "Assets — Mission Control" }] }),
  loader: async () => {
    const assets = getAssets();
    const summary = getAssetSummary();
    return { assets, summary };
  },
  component: AssetsPage,
});

const TYPE_CONFIG: Record<AssetType, { label: string; icon: typeof Activity; color: string }> = {
  service: { label: "Services", icon: Server, color: "text-violet" },
  agent: { label: "Agents", icon: Bot, color: "text-cyan" },
  cron: { label: "Cron Jobs", icon: Clock, color: "text-amber-400" },
  infra: { label: "Infrastructure", icon: Cpu, color: "text-emerald-400" },
};

const HEALTH_CONFIG: Record<AssetHealth, { label: string; icon: typeof Heart; color: string; bg: string; dot: string }> = {
  healthy: { label: "Healthy", icon: Heart, color: "text-[oklch(0.88_0.18_145)]", bg: "bg-[oklch(0.88_0.18_145)]/10", dot: "bg-[oklch(0.88_0.18_145)]" },
  degraded: { label: "Degraded", icon: Zap, color: "text-amber-400", bg: "bg-amber-400/10", dot: "bg-amber-400" },
  down: { label: "Down", icon: HeartCrack, color: "text-red-400", bg: "bg-red-400/10", dot: "bg-red-400" },
  unknown: { label: "Unknown", icon: HelpCircle, color: "text-muted-foreground", bg: "bg-muted/10", dot: "bg-muted-foreground" },
  standby: { label: "Standby", icon: HelpCircle, color: "text-muted-foreground", bg: "bg-muted/10", dot: "bg-muted-foreground" },
};

function AssetCard({ asset }: { asset: Asset }) {
  const health = HEALTH_CONFIG[asset.status];
  const type = TYPE_CONFIG[asset.type];
  const HealthIcon = health.icon;
  const TypeIcon = type.icon;

  return (
    <div className={`rounded-lg border border-border/60 bg-card/30 p-4 ${health.bg}`}>
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-2 min-w-0">
          <TypeIcon className={`h-4 w-4 ${type.color} shrink-0`} />
          <div className="min-w-0">
            <span className="text-sm font-medium block truncate">{asset.name}</span>
            <span className="text-[10px] font-mono text-muted-foreground">{asset.id}</span>
          </div>
        </div>
        <div className={`flex items-center gap-1.5 shrink-0 ${health.color}`}>
          <span className={`h-1.5 w-1.5 rounded-full ${health.dot}`} />
          <HealthIcon className="h-3.5 w-3.5" />
          <span className="font-mono text-[10px]">{health.label}</span>
        </div>
      </div>

      <div className="mt-3 flex items-center gap-3 text-[10px] text-muted-foreground/70">
        <span className="flex items-center gap-1">
          <Shield className="h-3 w-3" />
          {asset.owner}
        </span>
        {asset.consecutiveFailures > 0 && (
          <span className="text-amber-400">
            {asset.consecutiveFailures} consecutive failure{asset.consecutiveFailures > 1 ? "s" : ""}
          </span>
        )}
        {asset.dependencies.length > 0 && (
          <span className="flex items-center gap-1">
            <Wrench className="h-3 w-3" />
            {asset.dependencies.length} dep{asset.dependencies.length > 1 ? "s" : ""}
          </span>
        )}
      </div>

      {Object.keys(asset.metadata).length > 0 && (
        <div className="mt-2 flex flex-wrap gap-1">
          {Object.entries(asset.metadata).map(([k, v]) => (
            <span key={k} className="text-[9px] font-mono text-muted-foreground/50 bg-muted/20 rounded px-1.5 py-0.5">
              {k}: {v}
            </span>
          ))}
        </div>
      )}
    </div>
  );
}

function AssetsPage() {
  const { assets, summary } = Route.useLoaderData() as {
    assets: Asset[];
    summary: ReturnType<typeof getAssetSummary>;
  };
  const [filterType, setFilterType] = useState<AssetType | "all">("all");
  const [filterHealth, setFilterHealth] = useState<AssetHealth | "all">("all");

  const filtered = useMemo(() => {
    let result = assets;
    if (filterType !== "all") result = result.filter((a) => a.type === filterType);
    if (filterHealth !== "all") result = result.filter((a) => a.status === filterHealth);
    // Sort: worst health first, then by type
    const healthOrder: Record<AssetHealth, number> = { down: 0, degraded: 1, unknown: 2, standby: 3, healthy: 4 };
    result.sort((a, b) => healthOrder[a.status] - healthOrder[b.status]);
    return result;
  }, [assets, filterType, filterHealth]);

  return (
    <div className="space-y-6">
      <PageHeader
        title="Assets"
        subtitle={`${summary.total} tracked · ${summary.byHealth.healthy} healthy · ${summary.byHealth.degraded} degraded · ${summary.byHealth.down} down`}
        icon={<HardDrive className="h-5 w-5 text-violet" />}
      />

      {/* Summary badges */}
      <div className="flex flex-wrap gap-2">
        {(Object.keys(TYPE_CONFIG) as AssetType[]).map((type) => {
          const cfg = TYPE_CONFIG[type];
          const Icon = cfg.icon;
          const count = summary.byType[type];
          return (
            <button
              key={type}
              onClick={() => setFilterType(filterType === type ? "all" : type)}
              className={`flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs transition-colors ${
                filterType === type
                  ? "border-violet/50 bg-violet/10 text-violet"
                  : "border-border/60 bg-card/20 text-muted-foreground hover:border-border"
              }`}
            >
              <Icon className="h-3.5 w-3.5" />
              {cfg.label}
              <span className="font-mono text-[10px] opacity-70">{count}</span>
            </button>
          );
        })}
        <div className="w-px bg-border/40 mx-1" />
        {(Object.keys(HEALTH_CONFIG) as AssetHealth[]).map((h) => {
          const cfg = HEALTH_CONFIG[h];
          const count = summary.byHealth[h];
          if (count === 0) return null;
          return (
            <button
              key={h}
              onClick={() => setFilterHealth(filterHealth === h ? "all" : h)}
              className={`flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs transition-colors ${
                filterHealth === h
                  ? "border-violet/50 bg-violet/10"
                  : "border-border/60 bg-card/20 text-muted-foreground hover:border-border"
              } ${cfg.color}`}
            >
              <span className={`h-1.5 w-1.5 rounded-full ${cfg.dot}`} />
              {cfg.label}
              <span className="font-mono text-[10px] opacity-70">{count}</span>
            </button>
          );
        })}
      </div>

      {/* Asset grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
        {filtered.map((asset) => (
          <AssetCard key={asset.id} asset={asset} />
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-12 text-muted-foreground/50 text-sm">
          No assets match the current filter
        </div>
      )}
    </div>
  );
}
