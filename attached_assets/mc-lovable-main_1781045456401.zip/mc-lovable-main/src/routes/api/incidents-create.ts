// src/routes/api/incidents-create.tsx
// API route for creating incidents (auto-detection + manual)
import { writeFileSync, readFileSync, existsSync } from "node:fs";
import { join } from "node:path";

const WORKSPACE = process.env.OPENCLAW_WORKSPACE || "/Users/spacemonkey/.openclaw/workspace";

interface IncidentInput {
  title: string;
  severity: "P1" | "P2" | "P3" | "P4";
  owner: string;
  summary: string;
  tags: string[];
  source: string; // e.g. "health-check", "cron-monitor", "gateway-watch"
}

function readIncidents(): any[] {
  const p = join(WORKSPACE, "data", "incidents.json");
  if (!existsSync(p)) return [];
  try { return JSON.parse(readFileSync(p, "utf-8")); } catch { return []; }
}

function writeIncidents(incs: any[]) {
  const p = join(WORKSPACE, "data", "incidents.json");
  writeFileSync(p, JSON.stringify(incs, null, 2), "utf-8");
}

function nextId(incs: any[]): string {
  const nums = incs.map(i => {
    const m = i.id.match(/INC-(\d+)/);
    return m ? parseInt(m[1]) : 0;
  });
  const next = Math.max(0, ...nums) + 1;
  return `INC-${String(next).padStart(3, "0")}`;
}

// Deduplicate: don't create if an open incident with same title+source exists
function isDuplicate(incs: any[], input: IncidentInput): boolean {
  return incs.some(i =>
    i.status !== "RESOLVED" &&
    i.title === input.title &&
    i.tags?.includes(input.source)
  );
}

export async function POST({ request }: { request: Request }) {
  try {
    const input = (await request.json()) as IncidentInput;
    const incs = readIncidents();

    if (isDuplicate(incs, input)) {
      return new Response(JSON.stringify({ ok: true, duplicate: true }), {
        headers: { "Content-Type": "application/json" },
      });
    }

    const now = new Date().toISOString();
    const id = nextId(incs);
    const incident = {
      id,
      title: input.title,
      severity: input.severity,
      status: "TRIAGE",
      owner: input.owner,
      acknowledged: false,
      escalated: false,
      opened: now,
      lastActivity: now,
      summary: input.summary,
      tags: [...input.tags, input.source],
      timeline: [
        { ts: now, message: `Auto-detected by ${input.source}`, actor: "system" },
      ],
      actions: [],
    };

    incs.unshift(incident);
    writeIncidents(incs);

    return new Response(JSON.stringify({ ok: true, id }), {
      headers: { "Content-Type": "application/json" },
    });
  } catch (err) {
    console.error("[api/incidents/create] Error:", err);
    return new Response(JSON.stringify({ ok: false, error: String(err) }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }
}
