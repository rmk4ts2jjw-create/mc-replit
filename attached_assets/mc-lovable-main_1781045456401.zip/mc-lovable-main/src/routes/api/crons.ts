// src/routes/api/crons.tsx
// API route for fetching OpenClaw cron jobs
import { execSync } from "node:child_process";

export async function GET() {
  try {
    const output = execSync("/opt/homebrew/bin/openclaw cron list --all --json", {
      encoding: "utf-8",
      timeout: 10000,
      env: {
        ...process.env,
        PATH: "/opt/homebrew/bin:/opt/homebrew/sbin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin",
      },
    });
    const data = JSON.parse(output);
    const jobs = (data.jobs || []) as Record<string, unknown>[];
    const mapped = jobs.map((j) => {
      const state = (j.state || {}) as Record<string, unknown>;
      const schedule = (j.schedule || {}) as Record<string, unknown>;
      const payload = (j.payload || {}) as Record<string, unknown>;
      return {
        id: String(j.id || ""),
        name: String(j.name || "Unknown"),
        schedule: String(schedule.expr || ""),
        enabled: j.enabled !== false,
        status: String(state.lastRunStatus || "ok"),
        lastError: String(state.lastError || ""),
        lastErrorReason: String(state.lastErrorReason || ""),
        consecutiveErrors: Number(state.consecutiveErrors || 0),
        lastRun: state.lastRunAtMs ? new Date(Number(state.lastRunAtMs)).toISOString() : "—",
        nextRun: state.nextRunAtMs ? new Date(Number(state.nextRunAtMs)).toISOString() : "—",
        message: String(payload.message || "").slice(0, 150),
      };
    });
    return new Response(JSON.stringify(mapped), {
      headers: { "Content-Type": "application/json" },
    });
  } catch (err) {
    console.error("[api/crons] Error:", err);
    return new Response(JSON.stringify([]), {
      headers: { "Content-Type": "application/json" },
    });
  }
}
