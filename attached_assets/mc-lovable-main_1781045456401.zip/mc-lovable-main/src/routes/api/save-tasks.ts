// src/routes/api/save-tasks.ts
// API route for saving tasks — bypasses createServerFn RPC issues
// Uses atomic write + in-memory lock to prevent race conditions
import { writeFileSync, renameSync, existsSync, mkdirSync } from "node:fs";
import { join } from "node:path";

const WORKSPACE = process.env.OPENCLAW_WORKSPACE || "/Users/spacemonkey/.openclaw/workspace";

// Simple in-memory mutex for single-process safety
let writeLock = false;
let writeQueue: (() => void)[] = [];

function acquireLock(): Promise<void> {
  return new Promise((resolve) => {
    if (!writeLock) {
      writeLock = true;
      resolve();
    } else {
      writeQueue.push(resolve);
    }
  });
}

function releaseLock() {
  const next = writeQueue.shift();
  if (next) {
    next();
  } else {
    writeLock = false;
  }
}

export async function POST({ request }: { request: Request }) {
  await acquireLock();
  try {
    const tasks = await request.json();
    const dir = join(WORKSPACE, "data");
    if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
    const path = join(dir, "tasks.json");
    // Atomic write: write to temp, then rename
    const tmpPath = path + ".tmp";
    writeFileSync(tmpPath, JSON.stringify(tasks, null, 2), "utf-8");
    renameSync(tmpPath, path);
    console.log("[save-tasks] Saved", tasks.length, "tasks");
    return new Response(JSON.stringify({ ok: true }), {
      headers: { "Content-Type": "application/json" },
    });
  } catch (err) {
    console.error("[save-tasks] Error:", err);
    return new Response(JSON.stringify({ ok: false, error: String(err) }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  } finally {
    releaseLock();
  }
}
