// src/routes/api/incidents-timeline.ts
// Append a timeline entry to an incident (e.g. when a linked task changes status)
// Auto-resolves the incident if the linked task is marked done.
import { writeFileSync, readFileSync, existsSync } from "node:fs";
import { join } from "node:path";

const WORKSPACE = process.env.OPENCLAW_WORKSPACE || "/Users/spacemonkey/.openclaw/workspace";

export async function POST({ request }: { request: Request }) {
  try {
    const { incidentId, message, actor, taskStatus } = (await request.json()) as {
      incidentId: string;
      message: string;
      actor?: string;
      taskStatus?: string;
    };
    if (!incidentId || !message) {
      return new Response(JSON.stringify({ ok: false, error: "incidentId and message required" }), {
        status: 400,
        headers: { "Content-Type": "application/json" },
      });
    }

    const incidentsPath = join(WORKSPACE, "data", "incidents.json");
    if (!existsSync(incidentsPath)) {
      return new Response(JSON.stringify({ ok: false, error: "incidents.json not found" }), {
        status: 404,
        headers: { "Content-Type": "application/json" },
      });
    }

    const incidents = JSON.parse(readFileSync(incidentsPath, "utf-8")) as Record<string, unknown>[];
    const idx = incidents.findIndex((i) => i.id === incidentId);
    if (idx === -1) {
      return new Response(JSON.stringify({ ok: false, error: `Incident ${incidentId} not found` }), {
        status: 404,
        headers: { "Content-Type": "application/json" },
      });
    }

    const inc = incidents[idx] as Record<string, unknown>;
    const timeline = (inc.timeline as Record<string, unknown>[]) || [];
    const now = new Date().toISOString();
    timeline.push({ ts: now, message, actor: actor || "system" });
    inc.timeline = timeline;
    inc.lastActivity = now;

    // Auto-resolve: if the linked task is done, resolve the incident
    if (taskStatus === "done" && inc.status !== "RESOLVED") {
      inc.status = "RESOLVED";
      inc.resolvedAt = now;
      timeline.push({ ts: now, message: "Incident auto-resolved: linked task completed", actor: "system" });
      console.log(`[api/incidents/timeline] Auto-resolved ${incidentId}: linked task marked done`);
    }

    writeFileSync(incidentsPath, JSON.stringify(incidents, null, 2), "utf-8");

    return new Response(JSON.stringify({ ok: true, autoResolved: taskStatus === "done" && inc.status === "RESOLVED" }), {
      headers: { "Content-Type": "application/json" },
    });
  } catch (err) {
    console.error("[api/incidents/timeline] Error:", err);
    return new Response(JSON.stringify({ ok: false, error: String(err) }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }
}
