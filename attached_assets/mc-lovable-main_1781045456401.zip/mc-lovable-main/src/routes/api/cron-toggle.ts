// src/routes/api/cron-toggle.tsx
// API route for enabling/disabling cron jobs
import { execSync } from "node:child_process";

export async function POST({ request }: { request: Request }) {
  try {
    const { id, action } = (await request.json()) as { id: string; action: "enable" | "disable" };
    const cmd = action === "enable" ? "enable" : "disable";
    execSync(`/opt/homebrew/bin/openclaw cron ${cmd} ${id}`, {
      encoding: "utf-8",
      timeout: 10000,
    });
    return new Response(JSON.stringify({ ok: true, message: `Cron job ${cmd}d` }), {
      headers: { "Content-Type": "application/json" },
    });
  } catch (err) {
    return new Response(JSON.stringify({ ok: false, error: String(err) }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }
}
