// src/routes/api/retry-policy.tsx
// Retry policy enforcement: 3 retries with 5-min gaps, then auto-P2 incident
import { readFileSync, writeFileSync, existsSync } from "node:fs";
import { join } from "node:path";

const WORKSPACE = process.env.OPENCLAW_WORKSPACE || "/Users/spacemonkey/.openclaw/workspace";

interface RetryState {
  jobId: string;
  jobName: string;
  retryCount: number;
  firstFailureAt: string;
  lastRetryAt: string;
  incidentCreated: boolean;
}

const MAX_RETRIES = 3;
const RETRY_GAP_MINUTES = 5;

function readRetryState(): Record<string, RetryState> {
  const p = join(WORKSPACE, "data", "retry-state.json");
  if (!existsSync(p)) return {};
  try { return JSON.parse(readFileSync(p, "utf-8")); } catch { return {}; }
}

function writeRetryState(state: Record<string, RetryState>) {
  const p = join(WORKSPACE, "data", "retry-state.json");
  writeFileSync(p, JSON.stringify(state, null, 2), "utf-8");
}

function readIncidents(): any[] {
  const p = join(WORKSPACE, "data", "incidents.json");
  if (!existsSync(p)) return [];
  try { return JSON.parse(readFileSync(p, "utf-8")); } catch { return []; }
}

function writeIncidents(incs: any[]) {
  const p = join(WORKSPACE, "data", "incidents.json");
  writeFileSync(p, JSON.stringify(incs, null, 2), "utf-8");
}

function nextIncidentId(incs: any[]): string {
  const nums = incs.map((i) => {
    const m = i.id.match(/INC-(\d+)/);
    return m ? parseInt(m[1]) : 0;
  });
  return `INC-${String(Math.max(0, ...nums) + 1).padStart(3, "0")}`;
}

/** POST /api/retry-policy — check and enforce retry policy for a cron job */
export async function POST({ request }: { request: Request }) {
  try {
    const { jobId, jobName, consecutiveErrors } = (await request.json()) as {
      jobId: string;
      jobName: string;
      consecutiveErrors: number;
    };

    if (!jobId) {
      return new Response(JSON.stringify({ ok: false, error: "jobId required" }), {
        status: 400,
        headers: { "Content-Type": "application/json" },
      });
    }

    const now = new Date().toISOString();
    const state = readRetryState();
    const existing = state[jobId];

    // Reset retry count if job is healthy
    if (consecutiveErrors === 0) {
      if (existing) {
        delete state[jobId];
        writeRetryState(state);
      }
      return new Response(JSON.stringify({ ok: true, action: "reset", jobId }), {
        headers: { "Content-Type": "application/json" },
      });
    }

    // Track retry state
    if (!existing) {
      state[jobId] = {
        jobId,
        jobName,
        retryCount: 1,
        firstFailureAt: now,
        lastRetryAt: now,
        incidentCreated: false,
      };
      writeRetryState(state);
      return new Response(JSON.stringify({ ok: true, action: "tracking", retryCount: 1, jobId }), {
        headers: { "Content-Type": "application/json" },
      });
    }

    // Increment retry count
    existing.retryCount = Math.min(existing.retryCount + 1, MAX_RETRIES + 1);
    existing.lastRetryAt = now;

    // Check if we've hit the limit
    if (existing.retryCount >= MAX_RETRIES && !existing.incidentCreated) {
      // Auto-create P2 incident
      const incidents = readIncidents();
      const id = nextIncidentId(incidents);
      const incident = {
        id,
        title: `Cron retry limit reached: ${jobName}`,
        severity: "P2",
        status: "TRIAGE",
        owner: "lifesupport",
        acknowledged: false,
        escalated: false,
        opened: now,
        lastActivity: now,
        summary: `Cron job "${jobName}" (${jobId}) has failed ${existing.retryCount} consecutive times. Retry policy: ${MAX_RETRIES} retries with ${RETRY_GAP_MINUTES}-minute gaps. Auto-created P2 incident for human review.`,
        tags: ["cron-failure", "retry-limit", "auto-created"],
        timeline: [
          { ts: existing.firstFailureAt, message: `First failure detected`, actor: "system" },
          { ts: now, message: `Retry limit reached (${MAX_RETRIES} retries). Auto-created ${id}.`, actor: "system" },
        ],
        actions: [],
        type: "cron-failure",
        typeConfidence: 1.0,
        suggestedRunbookId: "rb-cron-failure",
        actionsGenerated: false,
      };
      incidents.unshift(incident);
      writeIncidents(incidents);
      existing.incidentCreated = true;
      writeRetryState(state);

      // Create linked task
      try {
        const tasksPath = join(WORKSPACE, "data", "tasks.json");
        let tasks: any[] = [];
        if (existsSync(tasksPath)) {
          try { tasks = JSON.parse(readFileSync(tasksPath, "utf-8")); } catch { /* ignore */ }
        }
        const taskId = `task-${id.toLowerCase()}-${Date.now().toString(36)}`;
        tasks.unshift({
          id: taskId,
          title: `Investigate: ${id}`,
          assignee: "lifesupport",
          status: "triage",
          priority: "P2",
          ts: "just now",
          note: `Auto-created from retry policy. Cron job "${jobName}" failed ${existing.retryCount} times.`,
          linkedIncidentId: id,
          tags: ["incident-response", "cron-failure"],
          history: [{ ts: now, action: "created", actor: "system", details: `Auto-created from retry policy for ${jobId}` }],
          lastActivity: now,
        });
        writeFileSync(tasksPath, JSON.stringify(tasks, null, 2), "utf-8");
      } catch (taskErr) {
        console.error("[api/retry-policy] Failed to create linked task:", taskErr);
      }

      console.log(`[api/retry-policy] Created P2 incident ${id} for cron ${jobName} after ${existing.retryCount} retries`);
      return new Response(JSON.stringify({
        ok: true,
        action: "incident_created",
        incidentId: id,
        retryCount: existing.retryCount,
        jobId,
      }), { headers: { "Content-Type": "application/json" } });
    }

    writeRetryState(state);
    return new Response(JSON.stringify({
      ok: true,
      action: "retrying",
      retryCount: existing.retryCount,
      maxRetries: MAX_RETRIES,
      nextAction: existing.retryCount >= MAX_RETRIES ? "incident_pending" : "wait",
      jobId,
    }), { headers: { "Content-Type": "application/json" } });
  } catch (err) {
    console.error("[api/retry-policy] Error:", err);
    return new Response(JSON.stringify({ ok: false, error: String(err) }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }
}

/** GET /api/retry-policy — get current retry state for all jobs */
export async function GET() {
  const state = readRetryState();
  return new Response(JSON.stringify({ ok: true, state, maxRetries: MAX_RETRIES, retryGapMinutes: RETRY_GAP_MINUTES }), {
    headers: { "Content-Type": "application/json" },
  });
}
