// src/routes/api/incidents-auto-resolve.tsx
// Bulk auto-resolve: check all open incidents with linked tasks.
// If the linked task is Done → resolve the incident.
// If the linked incident has no linked tasks and is old → close it.
import { writeFileSync, readFileSync, existsSync } from "node:fs";
import { join } from "node:path";

const WORKSPACE = process.env.OPENCLAW_WORKSPACE || "/Users/spacemonkey/.openclaw/workspace";

interface ActionResult {
  incidentId: string;
  action: "resolved" | "closed" | "skipped";
  reason: string;
}

export async function POST({ request }: { request: Request }) {
  try {
    const body = (await request.json().catch(() => ({}))) as {
      dryRun?: boolean;
      closeOldDays?: number;
    };
    const dryRun = body.dryRun ?? false;
    const closeOldDays = body.closeOldDays ?? 5;

    const incidentsPath = join(WORKSPACE, "data", "incidents.json");
    const tasksPath = join(WORKSPACE, "data", "tasks.json");

    if (!existsSync(incidentsPath)) {
      return new Response(JSON.stringify({ ok: false, error: "incidents.json not found" }), {
        status: 404,
        headers: { "Content-Type": "application/json" },
      });
    }

    const incidents = JSON.parse(readFileSync(incidentsPath, "utf-8")) as Record<string, unknown>[];
    const tasks = existsSync(tasksPath)
      ? (JSON.parse(readFileSync(tasksPath, "utf-8")) as Record<string, unknown>[])
      : [];

    const now = new Date();
    const results: ActionResult[] = [];

    for (const inc of incidents) {
      if (inc.status === "RESOLVED") continue;

      // Find tasks linked to this incident
      const linkedTasks = tasks.filter((t) => t.linkedIncidentId === inc.id);

      // Case 1: linked task is done → auto-resolve
      const doneTask = linkedTasks.find((t) => t.status === "done");
      if (doneTask) {
        results.push({
          incidentId: inc.id as string,
          action: "resolved",
          reason: `Linked task ${doneTask.id} is done`,
        });
        if (!dryRun) {
          inc.status = "RESOLVED";
          inc.resolvedAt = now.toISOString();
          const timeline = (inc.timeline as Record<string, unknown>[]) || [];
          timeline.push({
            ts: now.toISOString(),
            message: `Incident auto-resolved: linked task "${doneTask.title}" completed`,
            actor: "system",
          });
          inc.timeline = timeline;
          inc.lastActivity = now.toISOString();
        }
        continue;
      }

      // Case 2: no linked tasks and old → close
      if (linkedTasks.length === 0 && inc.opened) {
        const opened = new Date(inc.opened as string);
        const ageDays = (now.getTime() - opened.getTime()) / (1000 * 60 * 60 * 24);
        if (ageDays >= closeOldDays) {
          results.push({
            incidentId: inc.id as string,
            action: "closed",
            reason: `No linked task, ${Math.round(ageDays)} days old (threshold: ${closeOldDays})`,
          });
          if (!dryRun) {
            inc.status = "RESOLVED";
            inc.resolvedAt = now.toISOString();
            const timeline = (inc.timeline as Record<string, unknown>[]) || [];
            timeline.push({
              ts: now.toISOString(),
              message: `Incident auto-closed: no linked task, ${Math.round(ageDays)} days old`,
              actor: "system",
            });
            inc.timeline = timeline;
            inc.lastActivity = now.toISOString();
          }
          continue;
        }
      }

      results.push({
        incidentId: inc.id as string,
        action: "skipped",
        reason: linkedTasks.length > 0
          ? `Linked task still ${linkedTasks[0].status}`
          : `Too young (${Math.round((now.getTime() - new Date(inc.opened as string).getTime()) / (1000 * 60 * 60 * 24))} days)`,
      });
    }

    if (!dryRun) {
      writeFileSync(incidentsPath, JSON.stringify(incidents, null, 2), "utf-8");
    }

    const resolved = results.filter((r) => r.action === "resolved").length;
    const closed = results.filter((r) => r.action === "closed").length;
    const skipped = results.filter((r) => r.action === "skipped").length;

    console.log(
      `[api/incidents/auto-resolve] ${dryRun ? "DRY RUN: " : ""}Resolved: ${resolved}, Closed: ${closed}, Skipped: ${skipped}`
    );

    return new Response(
      JSON.stringify({
        ok: true,
        dryRun,
        summary: { resolved, closed, skipped, total: results.length },
        results,
      }),
      { headers: { "Content-Type": "application/json" } }
    );
  } catch (err) {
    console.error("[api/incidents/auto-resolve] Error:", err);
    return new Response(JSON.stringify({ ok: false, error: String(err) }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }
}

/** GET /api/incidents/auto-resolve — dry run to preview what would happen */
export async function GET() {
  // Reuse POST logic with dryRun=true
  const fakeRequest = new Request("http://localhost", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ dryRun: true }),
  });
  return POST({ request: fakeRequest } as { request: Request });
}
