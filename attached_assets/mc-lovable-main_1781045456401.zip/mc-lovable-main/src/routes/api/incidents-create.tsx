// src/routes/api/incidents-create.tsx
// API route for creating incidents (auto-detection + manual)
import { writeFileSync, readFileSync, existsSync } from "node:fs";
import { join } from "node:path";
import { generateResponseActions } from "@/lib/incident-actions";
import { classifyIncident, suggestRunbook } from "@/lib/server-data/runbooks";

const WORKSPACE = process.env.OPENCLAW_WORKSPACE || "/Users/spacemonkey/.openclaw/workspace";

interface IncidentInput {
  title: string;
  severity: "P1" | "P2" | "P3" | "P4";
  owner: string;
  summary: string;
  tags: string[];
  source: string; // e.g. "health-check", "cron-monitor", "gateway-watch"
}

function readIncidents(): any[] {
  const p = join(WORKSPACE, "data", "incidents.json");
  if (!existsSync(p)) return [];
  try { return JSON.parse(readFileSync(p, "utf-8")); } catch { return []; }
}

function writeIncidents(incs: any[]) {
  const p = join(WORKSPACE, "data", "incidents.json");
  writeFileSync(p, JSON.stringify(incs, null, 2), "utf-8");
}

function nextId(incs: any[]): string {
  const nums = incs.map(i => {
    const m = i.id.match(/INC-(\d+)/);
    return m ? parseInt(m[1]) : 0;
  });
  const next = Math.max(0, ...nums) + 1;
  return `INC-${String(next).padStart(3, "0")}`;
}

// Deduplicate: don't create if an open incident with same title+source exists
function isDuplicate(incs: any[], input: IncidentInput): boolean {
  return incs.some(i =>
    i.status !== "RESOLVED" &&
    i.title === input.title &&
    i.tags?.includes(input.source)
  );
}

export async function POST({ request }: { request: Request }) {
  try {
    const input = (await request.json()) as IncidentInput;
    const incs = readIncidents();

    if (isDuplicate(incs, input)) {
      return new Response(JSON.stringify({ ok: true, duplicate: true }), {
        headers: { "Content-Type": "application/json" },
      });
    }

    const now = new Date().toISOString();
    const id = nextId(incs);
    // Auto-detect incident type from title and summary
    const detected = classifyIncident(input.title, input.summary);
    const suggested = suggestRunbook(input.title, input.summary);
    const incidentType = input.tags.find((t) => t.startsWith("type:"))?.replace("type:", "") || detected.type;
    const incident = {
      id,
      title: input.title,
      severity: input.severity,
      status: "TRIAGE",
      owner: input.owner,
      acknowledged: false,
      escalated: false,
      opened: now,
      lastActivity: now,
      summary: input.summary,
      tags: [...input.tags, input.source],
      timeline: [
        { ts: now, message: `Auto-detected by ${input.source}`, actor: "system" },
      ],
      actions: generateResponseActions(input.title, input.severity, input.tags, input.owner),
      type: incidentType,
      typeConfidence: detected.confidence,
      suggestedRunbookId: suggested.runbook?.id || null,
    };

    incs.unshift(incident);
    writeIncidents(incs);

    // Create linked tasks from runbook steps (or fallback to single investigate task)
    try {
      const tasksPath = join(WORKSPACE, "data", "tasks.json");
      let allTasks: Record<string, unknown>[] = [];
      if (existsSync(tasksPath)) {
        try { allTasks = JSON.parse(readFileSync(tasksPath, "utf-8")); } catch { /* ignore */ }
      }

      if (suggested.runbook && suggested.runbook.steps.length > 0) {
        // Create one task per runbook step
        for (const step of suggested.runbook.steps) {
          const stepTaskId = `task-${id.toLowerCase()}-${step.order}-${Date.now().toString(36)}`;
          const stepTask = {
            id: stepTaskId,
            title: `${id}: ${step.title}`,
            assignee: step.owner || input.owner,
            status: "backlog",
            priority: input.severity,
            ts: "just now",
            note: `From runbook "${suggested.runbook.label}" for incident ${id}. Step ${step.order}: ${step.description}`,
            linkedIncidentId: id,
            tags: ["incident-response", "runbook-step", ...input.tags],
            runbookStep: step.order,
            runbookId: suggested.runbook.id,
            history: [{ ts: now, action: "created", actor: "system", details: `Auto-created from runbook step ${step.order} for incident ${id}` }],
            lastActivity: now,
          };
          allTasks.unshift(stepTask);
        }
        writeFileSync(tasksPath, JSON.stringify(allTasks, null, 2), "utf-8");
        console.log(`[api/incidents/create] Created ${suggested.runbook.steps.length} runbook tasks for incident ${id}`);
      } else {
        // Fallback: single investigate task (no matching runbook)
        const taskId = `task-${id.toLowerCase()}-${Date.now().toString(36)}`;
        const task = {
          id: taskId,
          title: `Investigate: ${id}`,
          assignee: input.owner,
          status: "triage",
          priority: input.severity,
          ts: "just now",
          note: `Auto-created from incident ${id}: ${input.summary}`,
          linkedIncidentId: id,
          tags: ["incident-response", ...input.tags],
          history: [{ ts: now, action: "created", actor: "system", details: `Auto-created from incident ${id}` }],
          lastActivity: now,
        };
        allTasks.unshift(task);
        writeFileSync(tasksPath, JSON.stringify(allTasks, null, 2), "utf-8");
        console.log(`[api/incidents/create] Created fallback investigate task ${taskId} for incident ${id}`);
      }
    } catch (taskErr) {
      console.error("[api/incidents/create] Failed to create linked tasks:", taskErr);
    }

    return new Response(JSON.stringify({ ok: true, id }), {
      headers: { "Content-Type": "application/json" },
    });
  } catch (err) {
    console.error("[api/incidents/create] Error:", err);
    return new Response(JSON.stringify({ ok: false, error: String(err) }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }
}
