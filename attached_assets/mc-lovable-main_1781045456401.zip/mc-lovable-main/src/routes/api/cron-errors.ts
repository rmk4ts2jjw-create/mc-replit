// src/routes/api/cron-errors.tsx
// API route for fetching and updating cron error statuses
import { readFileSync, writeFileSync, existsSync, mkdirSync } from "node:fs";
import { join } from "node:path";

const WORKSPACE = process.env.OPENCLAW_WORKSPACE || "/Users/spacemonkey/.openclaw/workspace";

export async function GET() {
  try {
    const errorsPath = join(WORKSPACE, "data", "cron-errors.json");
    if (!existsSync(errorsPath)) {
      return new Response(JSON.stringify([]), { headers: { "Content-Type": "application/json" } });
    }
    const errors = JSON.parse(readFileSync(errorsPath, "utf-8"));
    return new Response(JSON.stringify(errors), { headers: { "Content-Type": "application/json" } });
  } catch (err) {
    return new Response(JSON.stringify([]), { headers: { "Content-Type": "application/json" } });
  }
}

export async function POST({ request }: { request: Request }) {
  try {
    const { errorId, status } = (await request.json()) as { errorId: string; status: string };
    const errorsPath = join(WORKSPACE, "data", "cron-errors.json");
    const dir = join(WORKSPACE, "data");
    if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
    let errors: Record<string, unknown>[] = [];
    try {
      errors = JSON.parse(readFileSync(errorsPath, "utf-8"));
    } catch {
      /* empty */
    }
    const idx = errors.findIndex((e) => e.id === errorId);
    if (idx !== -1) {
      errors[idx].status = status;
      errors[idx].updatedAt = new Date().toISOString();
    } else {
      errors.push({ id: errorId, status, updatedAt: new Date().toISOString() });
    }
    writeFileSync(errorsPath, JSON.stringify(errors, null, 2), "utf-8");
    return new Response(JSON.stringify({ ok: true }), { headers: { "Content-Type": "application/json" } });
  } catch (err) {
    console.error("[api/cron-errors] Error:", err);
    return new Response(JSON.stringify({ ok: false, error: String(err) }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }
}
