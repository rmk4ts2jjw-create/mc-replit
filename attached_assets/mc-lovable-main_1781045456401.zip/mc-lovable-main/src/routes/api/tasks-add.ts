// src/routes/api/tasks-add.tsx
// API route for adding a new task
import { writeFileSync, readFileSync, existsSync, mkdirSync } from "node:fs";
import { join } from "node:path";

const WORKSPACE = process.env.OPENCLAW_WORKSPACE || "/Users/spacemonkey/.openclaw/workspace";

export async function POST({ request }: { request: Request }) {
  try {
    const newTask = await request.json();
    const dir = join(WORKSPACE, "data");
    if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
    const tasksPath = join(dir, "tasks.json");
    let tasks: unknown[] = [];
    try {
      tasks = JSON.parse(readFileSync(tasksPath, "utf-8"));
    } catch {
      /* empty */
    }
    // Check for duplicate — same title + assignee already exists
    const isDuplicate = (tasks as Record<string, unknown>[]).some(
      (t) => t.title === newTask.title && t.assignee === newTask.assignee,
    );
    if (isDuplicate) {
      return new Response(JSON.stringify({ ok: false, message: "Duplicate task — already exists" }), {
        headers: { "Content-Type": "application/json" },
      });
    }
    tasks.unshift(newTask);
    writeFileSync(tasksPath, JSON.stringify(tasks, null, 2), "utf-8");
    return new Response(JSON.stringify({ ok: true }), {
      headers: { "Content-Type": "application/json" },
    });
  } catch (err) {
    console.error("[api/tasks/add] Error:", err);
    return new Response(JSON.stringify({ ok: false, error: String(err) }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }
}
