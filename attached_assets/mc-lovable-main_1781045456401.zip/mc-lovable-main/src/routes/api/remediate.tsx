// src/routes/api/remediate.tsx
// API endpoint for auto-remediation — trigger or check remediation rules
import { runAutoRemediation, getAllRules } from "@/lib/server-data/auto-remediation";

export async function POST({ request }: { request: Request }) {
  try {
    const body = (await request.json()) as { title?: string; error?: string; ruleId?: string };

    if (body.ruleId) {
      // Execute a specific rule
      const { executeRule } = await import("@/lib/server-data/auto-remediation");
      const result = await executeRule(body.ruleId);
      return new Response(JSON.stringify({ ok: true, result }), {
        headers: { "Content-Type": "application/json" },
      });
    }

    if (!body.title && !body.error) {
      return new Response(JSON.stringify({ ok: false, error: "Provide title+error or ruleId" }), {
        status: 400,
        headers: { "Content-Type": "application/json" },
      });
    }

    const result = await runAutoRemediation(body.title || "", body.error || "");
    return new Response(JSON.stringify({ ok: true, ...result }), {
      headers: { "Content-Type": "application/json" },
    });
  } catch (err) {
    return new Response(JSON.stringify({ ok: false, error: String(err) }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }
}

export async function GET() {
  try {
    const rules = getAllRules().map((r) => ({
      id: r.id,
      label: r.label,
      description: r.description,
      requiresApproval: r.requiresApproval,
    }));
    return new Response(JSON.stringify({ ok: true, rules }), {
      headers: { "Content-Type": "application/json" },
    });
  } catch (err) {
    return new Response(JSON.stringify({ ok: false, error: String(err) }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }
}
