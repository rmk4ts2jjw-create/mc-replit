// src/routes/api/incidents-status.ts
// Update incident status (TRIAGE → MITIGATING → AWAITING_REVIEW → RESOLVED)
import { writeFileSync, readFileSync, existsSync } from "node:fs";
import { join } from "node:path";

const WORKSPACE = process.env.OPENCLAW_WORKSPACE || "/Users/spacemonkey/.openclaw/workspace";

export async function POST({ request }: { request: Request }) {
  try {
    const { id, status } = (await request.json()) as { id: string; status: string };
    const incidentsPath = join(WORKSPACE, "data", "incidents.json");
    if (!existsSync(incidentsPath)) {
      return new Response(JSON.stringify({ ok: false, error: "incidents.json not found" }), {
        status: 404,
        headers: { "Content-Type": "application/json" },
      });
    }
    const incidents = JSON.parse(readFileSync(incidentsPath, "utf-8")) as Record<string, unknown>[];
    const idx = incidents.findIndex((i) => i.id === id);
    if (idx !== -1) {
      incidents[idx] = {
        ...incidents[idx],
        status,
        lastActivity: new Date().toISOString().replace("T", " ").slice(0, 19),
      };
      writeFileSync(incidentsPath, JSON.stringify(incidents, null, 2), "utf-8");
    }
    return new Response(JSON.stringify({ ok: true }), {
      headers: { "Content-Type": "application/json" },
    });
  } catch (err) {
    console.error("[api/incidents/status] Error:", err);
    return new Response(JSON.stringify({ ok: false, error: String(err) }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }
}
