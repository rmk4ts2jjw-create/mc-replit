import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/spacestation")({
  head: () => ({ meta: [{ title: "Agent Office — Mission Control" }] }),
  beforeLoad: () => {
    throw redirect({ to: "/visual" });
  },
  component: () => null,
});
