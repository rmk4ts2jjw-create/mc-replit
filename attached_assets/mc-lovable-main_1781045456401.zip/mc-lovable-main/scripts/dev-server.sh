#!/bin/bash
# dev-server.sh - Start Mission Control dev server on port 3001
# Usage: bash scripts/dev-server.sh
#
# This runs the dev instance on port 3001 so it doesn't conflict with prod (port 3000).
# The dev instance auto-reloads on file changes via vite dev.

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

cd "$PROJECT_DIR"

# Kill any existing dev server on port 3001
if lsof -ti :3001 > /dev/null 2>&1; then
  echo "🔄 Killing existing dev server on port 3001..."
  lsof -ti :3001 | xargs kill -9 2>/dev/null || true
  sleep 1
fi

echo "🚀 Starting Mission Control DEV server on port 3001..."
echo "   URL: http://localhost:3001"
echo "   Press Ctrl+C to stop"
echo ""

npx vite dev --port 3001
