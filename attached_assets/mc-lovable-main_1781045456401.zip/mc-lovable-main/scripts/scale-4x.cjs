const { createCanvas, loadImage } = require('canvas');
const path = require('path');
const fs = require('fs');

const OUTPUT_DIR = path.join(__dirname, '..', 'src', 'assets');
const SCALE = 4;

const files = [
  'sprite-monkey-idle.png', 'sprite-monkey-working.png', 'sprite-monkey-walking.png',
  'sprite-lifesupport-idle.png', 'sprite-lifesupport-working.png', 'sprite-lifesupport-walking.png',
  'sprite-engineer-idle.png', 'sprite-engineer-working.png', 'sprite-engineer-walking.png',
  'sprite-archivist-idle.png', 'sprite-archivist-working.png', 'sprite-archivist-walking.png',
  'room-command.png', 'room-lifesupport.png', 'room-engineer.png', 'room-archivist.png',
];

(async () => {
  for (const file of files) {
    const srcPath = path.join(OUTPUT_DIR, file);
    if (!fs.existsSync(srcPath)) continue;
    
    const img = await loadImage(srcPath);
    const newW = img.width * SCALE;
    const newH = img.height * SCALE;
    
    const canvas = createCanvas(newW, newH);
    const ctx = canvas.getContext('2d');
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(img, 0, 0, newW, newH);
    
    const buffer = canvas.toBuffer('image/png');
    const baseName = file.replace('.png', '');
    const outputPath = path.join(OUTPUT_DIR, `${baseName}-4x.png`);
    fs.writeFileSync(outputPath, buffer);
    console.log(`${baseName}-4x.png: ${newW}x${newH} (${(buffer.length/1024).toFixed(1)}K)`);
  }
  console.log('Done!');
})().catch(err => { console.error(err); process.exit(1); });
