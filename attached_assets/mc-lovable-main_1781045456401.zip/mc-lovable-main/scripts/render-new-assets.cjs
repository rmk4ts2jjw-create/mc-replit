const puppeteer = require('puppeteer');
const path = require('path');
const fs = require('fs');

const OUTPUT_DIR = path.join(__dirname, '..', 'src', 'assets');
const SCALE = 4;

async function main() {
  const browser = await puppeteer.launch({
    headless: 'new',
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });

  try {
    await renderSprites(browser);
    await renderRooms(browser);
    console.log('\nDone!');
  } finally {
    await browser.close();
  }
}

async function renderSprites(browser) {
  const page = await browser.newPage();
  const htmlPath = 'file://' + path.resolve(__dirname, 'sprites-new.html');

  await page.goto(htmlPath, { waitUntil: 'networkidle0', timeout: 30000 });
  await new Promise(r => setTimeout(r, 3000));

  const canvases = await page.$$('canvas');
  console.log(`Sprites: Found ${canvases.length} canvases`);

  const characters = ['monkey', 'lifesupport', 'engineer', 'archivist'];
  const poses = ['idle', 'walking', 'working'];

  for (let i = 0; i < canvases.length; i++) {
    const canvas = canvases[i];
    const charName = characters[i] || `char${i}`;

    for (let p = 0; p < 3; p++) {
      const pose = poses[p];
      const panelW = 320;
      const panelH = 240;
      const sx = p * panelW;

      const dataUrl = await page.evaluate((canvasEl, sx, sy, sw, sh, mult) => {
        const tempCanvas = document.createElement('canvas');
        tempCanvas.width = sw * mult;
        tempCanvas.height = sh * mult;
        const ctx = tempCanvas.getContext('2d');
        ctx.imageSmoothingEnabled = false;
        ctx.drawImage(canvasEl, sx, sy, sw, sh, 0, 0, sw * mult, sh * mult);
        return tempCanvas.toDataURL('image/png');
      }, canvas, sx, 0, panelW, panelH, SCALE);

      const base64 = dataUrl.replace(/^data:image\/png;base64,/, '');
      const buffer = Buffer.from(base64, 'base64');

      const outputPath = path.join(OUTPUT_DIR, `sprite-${charName}-${pose}-4x.png`);
      fs.writeFileSync(outputPath, buffer);
      console.log(`  sprite-${charName}-${pose}-4x.png: ${panelW*SCALE}x${panelH*SCALE} (${(buffer.length/1024).toFixed(1)}K)`);
    }
  }

  await page.close();
}

async function renderRooms(browser) {
  const page = await browser.newPage();
  const htmlPath = 'file://' + path.resolve(__dirname, 'rooms-new.html');

  await page.goto(htmlPath, { waitUntil: 'networkidle0', timeout: 30000 });
  await new Promise(r => setTimeout(r, 3000));

  const canvases = await page.$$('canvas');
  console.log(`Rooms: Found ${canvases.length} canvases`);

  const roomMapping = [
    { name: 'command', file: 'room-command-4x.png' },
    { name: 'security', file: 'room-lifesupport-4x.png' },
    { name: 'workshop', file: 'room-engineer-4x.png' },
    { name: 'archive', file: 'room-archivist-4x.png' },
  ];

  for (let i = 0; i < canvases.length; i++) {
    const canvas = canvases[i];
    const mapping = roomMapping[i];
    if (!mapping) continue;

    const dims = await page.evaluate((c) => ({ w: c.width, h: c.height }), canvas);

    const dataUrl = await page.evaluate((canvasEl, mult) => {
      const tempCanvas = document.createElement('canvas');
      tempCanvas.width = canvasEl.width * mult;
      tempCanvas.height = canvasEl.height * mult;
      const ctx = tempCanvas.getContext('2d');
      ctx.imageSmoothingEnabled = false;
      ctx.drawImage(canvasEl, 0, 0, canvasEl.width, canvasEl.height, 0, 0, canvasEl.width * mult, canvasEl.height * mult);
      return tempCanvas.toDataURL('image/png');
    }, canvas, SCALE);

    const base64 = dataUrl.replace(/^data:image\/png;base64,/, '');
    const buffer = Buffer.from(base64, 'base64');

    const outputPath = path.join(OUTPUT_DIR, mapping.file);
    fs.writeFileSync(outputPath, buffer);
    console.log(`  ${mapping.file}: ${dims.w*SCALE}x${dims.h*SCALE} (${(buffer.length/1024).toFixed(1)}K)`);
  }

  await page.close();
}

main().catch(err => { console.error(err); process.exit(1); });
