# Changelog — OpenClaw Mission Control

All notable changes to the Mission Control Dashboard.

## [1.4.0] — 2026-05-13

### Spacestation — Pixel-Art Room Restoration
- **Pixel-art room backgrounds restored** — each agent now has their own dedicated room (Command HQ, Security Bay, Engineering, Archive) using the original 768×512 pixel-art images
- **2×2 room grid layout** — rooms displayed in a responsive grid, each with unique atmosphere and identity
- **Animated room monitors** — screens glow and blink when the occupant is active, dim when idle
- **Terminal cursor blink** — active rooms show blinking terminal cursors on monitors
- **Room dimming** — idle/away agents' rooms are visually dimmed to communicate status at a glance
- **Agent sprites positioned within rooms** — avatars placed at meaningful positions inside each room environment
- **Pixel-art rendering** — `image-rendering: pixelated` applied to room backgrounds and avatars for crisp pixel look
- **Station atmosphere bar** — bottom status bar with hostname and model info
- **Collaboration indicator** — shown below the room grid when 2+ agents are working simultaneously

### Task Flow — Real Queue Dispatch
- **Dispatch on In Progress** — moving a task to In Progress now creates a real queue entry in `data/queue.json`
- **Ship's log integration** — every dispatch event is logged to `memory/ship-log.md` with timestamp
- **DISPATCHED badge** — in-progress task cards show a visual "DISPATCHED" indicator
- **Queue server functions** — `dispatchTask`, `getQueue` server functions for queue management

### Search Removal
- **SearchPalette component deleted** — global search (⌘K) fully removed
- **Sidebar navigation is the only UX** — no search triggers anywhere in the app
- **Page-level filters preserved** — Docs and Memory pages retain their own inline filtering

### Persistence
- **View state persistence** — last visited page saved to localStorage via `persist.ts`
- **Task order persistence** — drag order maintained across reloads
- **Queue file persistence** — queue entries survive server restarts

### App Icon
- **Custom app icon** — OpenClaw mascot (owl creature) set as the app icon for the `.app` bundle
- **Launch agent plist updated** — fixed to use `exec` + `KeepAlive` for reliable auto-start

---
_Last updated: 2026-05-13 by Space Monkey_

## [1.3.0] — 2026-05-13

### Incident Details Drawer
- **Incident details drawer** — clicking an incident card opens a right-slide sheet with full details
- **Timeline view** — vertical timeline with actor avatars, timestamps, and event messages
- **Response actions checklist** — each incident tracks action items (available/completed/skipped) with status icons
- **Incident data model** — extended with `timeline[]`, `actions[]`, and `resolved` timestamp
- **4 seed incidents** — real data: memory index corruption, WD MyCloud permissions, Desktop zip access, cron drift
- **Action progress on cards** — incident list shows action completion (e.g. "2/4 actions")
- **Tag overflow** — cards show first 3 tags + count for remaining

## [1.0.0] — 2026-05-12

### Initial Build
- **10 pages**: Tasks, Calendar, Projects, Memory, Docs, Team, Visual, Incidents, Activity, Settings
- **Live data integration** via TanStack Start `createServerFn` — reads directly from OpenClaw workspace files
- **Global search** (⌘K) — searches across tasks, docs, memory, projects, incidents, cron jobs
- **Quick Actions panel** — Run Backup, Restart Gateway, Clear Cache
- **Mobile responsive** — hamburger menu, slide-out sidebar
- **Task write-back** — drag-and-drop persists to `data/tasks.json`
- **Activity Feed** — chronological timeline of workspace events
- **Settings page** — system info, crew status, quick actions
- **Custom app icon** — `apple-touch-icon.png` from downloads

### Data Sources
| Page | Source |
|------|--------|
| Tasks | `~/.openclaw/workspace/data/tasks.json` |
| Calendar | `~/.openclaw/openclaw.json` (cron jobs) |
| Memory | `~/.openclaw/workspace/memory/*.md` + `MEMORY.md` |
| Docs | All `.md` files in workspace |
| Projects | `~/.openclaw/workspace/data/projects.json` |
| Incidents | `~/.openclaw/workspace/data/incidents.json` |
| Team | Live from OpenClaw config + `IDENTITY.md` |
| Visual | Live agent status (active/standby) |

### Known Issues
- Visual page room images may not render in production build (asset path issue — images moved to `public/assets/`)
- Activity Feed shows file-level changes, not granular agent actions
- No auto-complete for tasks (manual drag to Done only)

## [1.3.0] — 2026-05-13

### Spacestation — Home Page & Navigation Overhaul
- **Spacestation is now the home page** — `/` loads Spacestation directly (no redirect)
- **Home button in sidebar** — dedicated Home nav item always returns to Spacestation
- **Clickable MISSION CONTROL header** — clicking the sidebar logo returns home
- **Search removed** — ⌘K palette and sidebar search button removed; sidebar nav is the intended UX
- **Bottom label fixed** — now shows "SPACE MONKEY" instead of "N commander"
- **Visual route redirects** — `/visual` now redirects to `/`

### Spacestation — Real Task-Driven Agent States
- **Agent status from real task queue** — working/idle/standby derived from actual `tasks.json` in_progress assignments
- **Collaboration detection** — only triggers when 2+ agents have in_progress tasks simultaneously
- **No fake animations** — all movement and state changes reflect real queue state
- **Real system stats** — CPU load, disk usage, memory percentage, uptime from actual shell commands
- **Engineer/Archivist dynamic status** — switch from standby→active when assigned in-progress tasks

### Task Flow — Create & Dispatch
- **+ New Task button** — modal form with title, assignee dropdown (all 4 crew), optional note
- **Tasks persist to workspace** — all changes saved to `~/.openclaw/workspace/data/tasks.json`
- **In Progress = real dispatch** — moving a task to In Progress updates agent status on the Spacestation
- **Drag-and-drop across all 3 columns** — Backlog ↔ In Progress ↔ Done

### Quick Actions — Expanded
- **System Health snapshot** — live CPU, disk, memory, gateway status
- **Open Control UI** — launches localhost:18789 in new tab
- **Pause/Resume Queue** — toggles task dispatch via flag file
- **Refresh Models** — re-runs freeride model auto
- **Toggle Dreaming** — nightly consolidation on/off
- **Run Backup** — full backup to WD MyCloud
- **Clear Cache** — clears freeride and API caches
- **Restart Gateway** — with confirmation dialog

### Persistence
- **UI state saved to localStorage** — last view, task order, collapsed sections
- **Task data persisted to disk** — survives page reloads and server restarts

### Data Model
- **Task IDs** — now use unique generated IDs (timestamp + random) instead of T-xxx format
- **Agent status logic** — Always ON agents (Monkey, Life Support) always active; ON-DEMAND (Engineer, Archivist) activate when tasks assigned

---
_Last updated: 2026-05-13 by Space Monkey_

## [1.2.0] — 2026-05-12

### Spacestation — New Landing Page
- **Spacestation is now the default landing page** — loads directly when Mission Control opens
- **2D pixel-art station view** — 4 room grid (Command HQ, Security, Workshop, Archive) with corridor
- **Animated agent sprites** — each crew member has animated states: working (bounce/hack/monitor), idle (dimmed pulse), away (grayscale)
- **Collaboration detection** — when 2+ agents are active, they move to the corridor area with collaboration indicator
- **System health bar** — CPU, disk, memory percentages with warning thresholds
- **Service status pills** — Gateway, Cron, Telegram, Memory, Wiki at a glance
- **Alerts strip** — incident/alert notifications displayed on the station
- **Scanline overlay** — subtle CRT-style effect for station aesthetic
- **Agent hover cards** — hover any agent for name, role, model, current task
- **Room decorations** — desks, monitor glows that activate when agent is working
- **Live clock** — station time display
- **Sidebar restructured** — "BRIDGE" section with Spacestation as first item, removed old "Visual" entry
- **Mobile responsive** — hamburger menu, slide-out sidebar

### Route Changes
- `/` now redirects to `/visual` (Spacestation)
- Sidebar "Visual" renamed to "Spacestation" under BRIDGE category
