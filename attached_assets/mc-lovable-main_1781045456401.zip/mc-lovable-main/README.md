# openclaw-missionscontrol

Mission Control Dashboard — a 7-screen monitoring app built with TanStack Start.

## Serving Method

**Vite dev server** (chosen for active development with hot reload).

```bash
cd ~/.openclaw/workspace/mission-control-dashboard
bun run dev --host --port 3000
```

The dev server is managed by a LaunchAgent (`com.spacemonkey.mission-control`) that auto-starts on boot and restarts on crash.

## Auto-Recovery

- **LaunchAgent**: `~/Library/LaunchAgents/com.spacemonkey.mission-control.plist` — keeps the dev server running, restarts on crash
- **Health check**: Shell script at `~/.openclaw/workspace/scripts/health-check-mc.sh` runs every 15 minutes via cron
  - Checks HTTP 200 on `localhost:3000`
  - Restarts if down, alerts via `mount-alert.txt` if restart fails
  - Logs to `~/.openclaw/logs/health-check-restart.log`
  - Pure shell — zero model calls

## Pages

- `/` — Dashboard (system stats, agent status, activity feed)
- `/visual` — Agent Office (animated station with 4 rooms)
- `/tasks` — Task management
- `/calendar` — Calendar view

## Dev/Prod Strategy

- `main` branch = prod (port 3000)
- `dev` branch = dev (port 3001)
