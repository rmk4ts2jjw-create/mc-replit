#!/usr/bin/env bun
// scripts/seed-station-memory.ts
// Seeds the SQLite Station Memory database from the existing JSON file.
// Run with: npx tsx scripts/seed-station-memory.ts

import Database from "better-sqlite3";
import { readFileSync, existsSync, mkdirSync } from "node:fs";
import { join } from "node:path";

const WORKSPACE = "/Users/spacemonkey/.openclaw/workspace";
const DB_PATH = join(WORKSPACE, "data", "station-memory.db");
const JSON_PATH = join(WORKSPACE, "data", "station-memory.json");

// ── Schema ───────────────────────────────────────────────────────────────────

function initSchema(db: Database.Database): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS records (
      id TEXT PRIMARY KEY,
      type TEXT NOT NULL CHECK(type IN (
        'architecture-decision','lesson-learned','incident-knowledge',
        'completed-task-summary','operational-decision','framework-rule',
        'runbook','known-issue','commit'
      )),
      title TEXT NOT NULL DEFAULT '',
      summary TEXT NOT NULL DEFAULT '',
      decision TEXT DEFAULT NULL,
      reason TEXT DEFAULT NULL,
      supersedes TEXT DEFAULT NULL,
      problem TEXT DEFAULT NULL,
      root_cause TEXT DEFAULT NULL,
      fix TEXT DEFAULT NULL,
      files_changed TEXT DEFAULT '[]',
      never_do_this TEXT DEFAULT NULL,
      timeline TEXT DEFAULT NULL,
      resolution TEXT DEFAULT NULL,
      prevention TEXT DEFAULT NULL,
      original_objective TEXT DEFAULT NULL,
      outcome TEXT DEFAULT NULL,
      lessons TEXT DEFAULT '[]',
      recommendations TEXT DEFAULT '[]',
      alternative_considered TEXT DEFAULT NULL,
      decision_owner TEXT DEFAULT NULL,
      review_date TEXT DEFAULT NULL,
      rule TEXT DEFAULT NULL,
      examples TEXT DEFAULT NULL,
      issue TEXT DEFAULT NULL,
      current_state TEXT DEFAULT NULL,
      workaround TEXT DEFAULT NULL,
      owner TEXT DEFAULT NULL,
      priority TEXT DEFAULT NULL CHECK(priority IS NULL OR priority IN ('P1','P2','P3','P4')),
      -- Commit metadata
      commit_hash TEXT DEFAULT NULL,
      commit_message TEXT DEFAULT NULL,
      commit_repo TEXT DEFAULT NULL,
      status TEXT DEFAULT 'current',
      date TEXT NOT NULL DEFAULT '',
      author TEXT NOT NULL DEFAULT 'unknown',
      source TEXT NOT NULL DEFAULT 'manual',
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS record_tags (
      record_id TEXT NOT NULL REFERENCES records(id) ON DELETE CASCADE,
      tag TEXT NOT NULL,
      PRIMARY KEY (record_id, tag)
    );

    CREATE TABLE IF NOT EXISTS record_relations (
      source_id TEXT NOT NULL REFERENCES records(id) ON DELETE CASCADE,
      target_id TEXT NOT NULL REFERENCES records(id) ON DELETE CASCADE,
      relation_type TEXT NOT NULL DEFAULT 'related',
      PRIMARY KEY (source_id, target_id)
    );

    CREATE INDEX IF NOT EXISTS idx_records_type ON records(type);
    CREATE INDEX IF NOT EXISTS idx_records_date ON records(date);
    CREATE INDEX IF NOT EXISTS idx_records_status ON records(status);
    CREATE INDEX IF NOT EXISTS idx_records_author ON records(author);
    CREATE INDEX IF NOT EXISTS idx_record_tags_tag ON record_tags(tag);
    CREATE INDEX IF NOT EXISTS idx_record_relations_source ON record_relations(source_id);
    CREATE INDEX IF NOT EXISTS idx_record_relations_target ON record_relations(target_id);

    CREATE VIRTUAL TABLE IF NOT EXISTS records_fts USING fts5(
      id UNINDEXED, title, summary, decision, reason, problem,
      root_cause, fix, rule, issue, workaround, resolution, outcome,
      content=records, content_rowid=rowid
    );

    CREATE TRIGGER IF NOT EXISTS records_ai AFTER INSERT ON records BEGIN
      INSERT INTO records_fts(id, title, summary, decision, reason, problem, root_cause, fix, rule, issue, workaround, resolution, outcome)
      VALUES (new.id, new.title, new.summary, new.decision, new.reason, new.problem, new.root_cause, new.fix, new.rule, new.issue, new.workaround, new.resolution, new.outcome);
    END;
    CREATE TRIGGER IF NOT EXISTS records_ad AFTER DELETE ON records BEGIN
      INSERT INTO records_fts(records_fts, rowid, id, title, summary, decision, reason, problem, root_cause, fix, rule, issue, workaround, resolution, outcome)
      VALUES ('delete', old.rowid, old.id, old.title, old.summary, old.decision, old.reason, old.problem, old.root_cause, old.fix, old.rule, old.issue, old.workaround, old.resolution, old.outcome);
    END;
    CREATE TRIGGER IF NOT EXISTS records_au AFTER UPDATE ON records BEGIN
      INSERT INTO records_fts(records_fts, rowid, id, title, summary, decision, reason, problem, root_cause, fix, rule, issue, workaround, resolution, outcome)
      VALUES ('delete', old.rowid, old.id, old.title, old.summary, old.decision, old.reason, old.problem, old.root_cause, old.fix, old.rule, old.issue, old.workaround, old.resolution, old.outcome);
      INSERT INTO records_fts(id, title, summary, decision, reason, problem, root_cause, fix, rule, issue, workaround, resolution, outcome)
      VALUES (new.id, new.title, new.summary, new.decision, new.reason, new.problem, new.root_cause, new.fix, new.rule, new.issue, new.workaround, new.resolution, new.outcome);
    END;
  `);
}

// ── Seed ─────────────────────────────────────────────────────────────────────

function seedFromJson(db: Database.Database, jsonPath: string): number {
  if (!existsSync(jsonPath)) {
    console.log(`JSON file not found: ${jsonPath}`);
    return 0;
  }

  const data = JSON.parse(readFileSync(jsonPath, "utf-8"));
  const records = data.records || [];

  const insertRecord = db.prepare(`
    INSERT OR REPLACE INTO records
    (id, type, title, summary, decision, reason, supersedes,
     problem, root_cause, fix, files_changed, never_do_this,
     timeline, resolution, prevention,
     original_objective, outcome, lessons, recommendations,
     alternative_considered, decision_owner, review_date,
     rule, examples, issue, current_state, workaround, owner, priority,
     commit_hash, commit_message, commit_repo,
     status, date, author, source, created_at, updated_at)
    VALUES
    (@id, @type, @title, @summary, @decision, @reason, @supersedes,
     @problem, @rootCause, @fix, @filesChanged, @neverDoThis,
     @timeline, @resolution, @prevention,
     @originalObjective, @outcome, @lessons, @recommendations,
     @alternativeConsidered, @decisionOwner, @reviewDate,
     @rule, @examples, @issue, @currentState, @workaround, @owner, @priority,
     @commitHash, @commitMessage, @commitRepo,
     @status, @date, @author, @source, @createdAt, @updatedAt)
  `);

  const insertTag = db.prepare("INSERT OR IGNORE INTO record_tags (record_id, tag) VALUES (?, ?)");
  const insertRel = db.prepare("INSERT OR IGNORE INTO record_relations (source_id, target_id, relation_type) VALUES (?, ?, ?)");

  db.exec("DELETE FROM record_relations");
  db.exec("DELETE FROM record_tags");
  db.exec("DELETE FROM records");

  const now = new Date().toISOString();
  let count = 0;
  // Collect relations for second pass so all target records exist first
  const pendingRelations: Array<[string, string]> = [];

  const tx = db.transaction(() => {
    for (const r of records) {
      try {
        insertRecord.run({
          id: r.id,
          type: r.type,
          title: r.title,
          summary: r.summary,
          decision: r.decision || null,
          reason: r.reason || null,
          supersedes: r.supersedes || null,
          problem: r.problem || null,
          rootCause: r.rootCause || null,
          fix: r.fix || null,
          filesChanged: JSON.stringify(r.filesChanged || []),
          neverDoThis: r.neverDoThis || null,
          timeline: r.timeline || null,
          resolution: r.resolution || null,
          prevention: r.prevention || null,
          originalObjective: r.originalObjective || null,
          outcome: r.outcome || null,
          lessons: JSON.stringify(r.lessons || []),
          recommendations: JSON.stringify(r.recommendations || []),
          alternativeConsidered: r.alternativeConsidered || null,
          decisionOwner: r.decisionOwner || null,
          reviewDate: r.reviewDate || null,
          rule: r.rule || null,
          examples: r.examples || null,
          issue: r.issue || null,
          currentState: r.currentState || null,
          workaround: r.workaround || null,
          owner: r.owner || null,
          priority: r.priority || null,
          commitHash: r.commitHash || null,
          commitMessage: r.commitMessage || null,
          commitRepo: r.commitRepo || null,
          status: r.status || "current",
          date: r.date || now.slice(0, 10),
          author: r.author || "monkey",
          source: r.source || "manual",
          createdAt: now,
          updatedAt: now,
        });

        for (const tag of r.tags || []) {
          insertTag.run(r.id, tag);
        }
        for (const targetId of r.relatedIds || []) {
          pendingRelations.push([r.id, targetId]);
        }
        count++;
      } catch (e) {
        console.error(`  ✗ Failed to seed ${r.id}: ${(e as Error).message}`);
      }
    }
  });

  tx();

  // Second pass: insert relations now that all records exist
  for (const [src, tgt] of pendingRelations) {
    try {
      insertRel.run(src, tgt, "related");
    } catch (e) {
      console.error(`  ✗ Failed relation ${src} → ${tgt}: ${(e as Error).message}`);
    }
  }

  return count;
}

// ── Main ─────────────────────────────────────────────────────────────────────

console.log("🗄️  Station Memory — SQLite Seeder");
console.log(`  DB:   ${DB_PATH}`);
console.log(`  JSON: ${JSON_PATH}`);

const db = new Database(DB_PATH);
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

initSchema(db);
const count = seedFromJson(db, JSON_PATH);
console.log(`✅ Seeded ${count} records`);

// Verify
const stats = db.prepare("SELECT COUNT(*) as n FROM records").get() as { n: number };
const tagCount = db.prepare("SELECT COUNT(*) as n FROM record_tags").get() as { n: number };
const relCount = db.prepare("SELECT COUNT(*) as n FROM record_relations").get() as { n: number };
console.log(`📊 DB: ${stats.n} records, ${tagCount.n} tags, ${relCount.n} relations`);

// Search test
const results = db.prepare(
  "SELECT id, title FROM records_fts WHERE records_fts MATCH ? LIMIT 3"
).all("LaunchAgent") as Array<{ id: string; title: string }>;
console.log(`🔍 FTS test ("LaunchAgent"): ${results.length} results`);
for (const r of results) console.log(`   → ${r.id}: ${r.title}`);

// By-type count
const byType = db.prepare("SELECT type, COUNT(*) as n FROM records GROUP BY type ORDER BY n DESC").all() as Array<{ type: string; n: number }>;
for (const t of byType) console.log(`   ${t.type}: ${t.n}`);

db.close();
console.log("✅ Done");
