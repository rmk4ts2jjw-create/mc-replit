// src/lib/server-data/tasks.ts

import { createServerFn } from "@tanstack/react-start";
// node:fs lazy-imported below to avoid client bundle leak
import { WORKSPACE, type Task, type QueueItem } from "./types";
import { readJsonOrNull, normalizeTasks } from "./helpers";

// ── Tasks ──────────────────────────────────────────────────────────────────────

export const getTasks = createServerFn({ method: "GET" }).handler(async () => {
  const data = await readJsonOrNull<unknown>(`${WORKSPACE}/data/tasks.json`);
  return (normalizeTasks(data) as Task[]) ?? [];
});

export const getBacklogCount = createServerFn({ method: "GET" }).handler(async () => {
  const data = await readJsonOrNull<unknown>(`${WORKSPACE}/data/tasks.json`);
  const tasks = normalizeTasks(data);
  const count = tasks.filter((t: any) => t.status === "backlog").length;
  return { count };
});

export const saveTasks = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => d as Task[])
  .handler(async ({ data: tasks }) => {
    const path = `${WORKSPACE}/data/tasks.json`;
    console.log("[saveTasks] Writing", tasks.length, "tasks to", path);
    const tmpPath = path + ".tmp";
    const { writeFileSync: wf, renameSync: rn } = await import("node:fs");
    wf(tmpPath, JSON.stringify(tasks, null, 2), "utf-8");
    rn(tmpPath, path);
    console.log("[saveTasks] Saved successfully");
    return "ok";
  });

// ── Queue Dispatch ──────────────────────────────────────────────────────────

export const dispatchTask = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => d as { taskId: string; title: string; assignee: string })
  .handler(async ({ data }) => {
    const queuePath = `${WORKSPACE}/data/queue.json`;
    const queue = await readJsonOrNull<QueueItem[]>(queuePath) || [];
    const item: QueueItem = {
      id: `q-${Date.now()}`,
      taskId: data.taskId,
      title: data.title,
      assignee: data.assignee,
      dispatchedAt: new Date().toISOString(),
      status: "pending",
    };
    queue.push(item);
    const { writeFileSync: wf } = await import("node:fs");
    wf(queuePath, JSON.stringify(queue, null, 2), "utf-8");
    return { ok: true, queueId: item.id };
  });

export const getQueue = createServerFn({ method: "GET" }).handler(async () => {
  return await readJsonOrNull<QueueItem[]>(`${WORKSPACE}/data/queue.json`) || [];
});
