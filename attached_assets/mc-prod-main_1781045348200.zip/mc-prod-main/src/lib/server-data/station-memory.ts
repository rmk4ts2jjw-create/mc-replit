// src/lib/server-data/station-memory.ts
// Station Memory — institutional knowledge layer for Mission Control
// Backed by SQLite (better-sqlite3) with FTS5 full-text search.
// NOTE: Uses node:sqlite (built into Node.js 22.5+) instead of better-sqlite3
// because Vite SSR can't load native .node addons. node:sqlite is a static
// import that works in both Vite SSR and regular Node.js contexts.

import { createServerFn } from "@tanstack/react-start";

const WORKSPACE = "/Users/spacemonkey/.openclaw/workspace";

// ── Types ────────────────────────────────────────────────────────────────────

export type MemoryRecordType =
  | "architecture-decision"
  | "lesson-learned"
  | "incident-knowledge"
  | "completed-task-summary"
  | "operational-decision"
  | "framework-rule"
  | "runbook"
  | "known-issue";

export interface StationMemoryRecord {
  id: string;
  type: MemoryRecordType;
  title: string;
  summary: string;
  decision: string | null;
  reason: string | null;
  supersedes: string | null;
  problem: string | null;
  rootCause: string | null;
  fix: string | null;
  filesChanged: string[];
  neverDoThis: string | null;
  timeline: string | null;
  resolution: string | null;
  prevention: string | null;
  originalObjective: string | null;
  outcome: string | null;
  lessons: string[];
  recommendations: string[];
  alternativeConsidered: string | null;
  decisionOwner: string | null;
  reviewDate: string | null;
  rule: string | null;
  examples: string | null;
  issue: string | null;
  currentState: string | null;
  workaround: string | null;
  owner: string | null;
  priority: string | null;
  status: string;
  date: string;
  author: string;
  tags: string[];
  relatedIds: string[];
  source: string;
  commitHash: string | null;
  commitMessage: string | null;
  commitRepo: string | null;
}

export interface StationMemoryStore {
  version: number;
  lastUpdated: string;
  records: StationMemoryRecord[];
}

// ── SQLite helpers (called inside handlers only) ────────────────────────────

interface DbRecord {
  id: string;
  type: string;
  title: string;
  summary: string;
  decision: string | null;
  reason: string | null;
  supersedes: string | null;
  problem: string | null;
  root_cause: string | null;
  fix: string | null;
  files_changed: string;
  never_do_this: string | null;
  timeline: string | null;
  resolution: string | null;
  prevention: string | null;
  original_objective: string | null;
  outcome: string | null;
  lessons: string;
  recommendations: string;
  alternative_considered: string | null;
  decision_owner: string | null;
  review_date: string | null;
  rule: string | null;
  examples: string | null;
  issue: string | null;
  current_state: string | null;
  workaround: string | null;
  owner: string | null;
  priority: string | null;
  status: string;
  date: string;
  author: string;
  source: string;
  commit_hash: string | null;
  commit_message: string | null;
  commit_repo: string | null;
}

async function withDb<T>(fn: (db: import("node:sqlite").DatabaseSync) => T): Promise<T> {
  const { DatabaseSync } = await import("node:sqlite");
  const { join } = await import("node:path");
  const { existsSync, mkdirSync } = await import("node:fs");
  const dir = join(WORKSPACE, "data");
  if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
  const db = new DatabaseSync(join(dir, "station-memory.db"), { open: true });
  try {
    return fn(db);
  } finally {
    db.close();
  }
}

function rowToRecord(row: DbRecord): StationMemoryRecord {
  return {
    id: row.id,
    type: row.type as MemoryRecordType,
    title: row.title,
    summary: row.summary,
    decision: row.decision,
    reason: row.reason,
    supersedes: row.supersedes,
    problem: row.problem,
    rootCause: row.root_cause,
    fix: row.fix,
    filesChanged: JSON.parse(row.files_changed || "[]"),
    neverDoThis: row.never_do_this,
    timeline: row.timeline,
    resolution: row.resolution,
    prevention: row.prevention,
    originalObjective: row.original_objective,
    outcome: row.outcome,
    lessons: JSON.parse(row.lessons || "[]"),
    recommendations: JSON.parse(row.recommendations || "[]"),
    alternativeConsidered: row.alternative_considered,
    decisionOwner: row.decision_owner,
    reviewDate: row.review_date,
    rule: row.rule,
    examples: row.examples,
    issue: row.issue,
    currentState: row.current_state,
    workaround: row.workaround,
    owner: row.owner,
    priority: row.priority,
    status: row.status,
    date: row.date,
    author: row.author,
    source: row.source,
    commitHash: row.commit_hash as string | null,
    commitMessage: row.commit_message as string | null,
    commitRepo: row.commit_repo as string | null,
  };
}

function loadRelations(db: import("better-sqlite3").Database, record: StationMemoryRecord): StationMemoryRecord {
  const tags = db.prepare("SELECT tag FROM record_tags WHERE record_id = ?").all(record.id) as { tag: string }[];
  const related = db.prepare("SELECT target_id FROM record_relations WHERE source_id = ?").all(record.id) as { target_id: string }[];
  record.tags = tags.map((t) => t.tag);
  record.relatedIds = related.map((r) => r.target_id);
  return record;
}

// ── Server Functions ─────────────────────────────────────────────────────────

export const getStationMemory = createServerFn({ method: "GET" }).handler(async () => {
  try {
    const result = await withDb((db) => {
      const rows = db.prepare("SELECT * FROM records ORDER BY date DESC").all() as DbRecord[];
      const records = rows.map((row) => {
        const rec = rowToRecord(row);
        return loadRelations(db, rec);
      });
      return { version: 2, lastUpdated: new Date().toISOString(), records } as StationMemoryStore;
    });
    return result;
  } catch (e) {
    console.error("[station-memory] getStationMemory ERROR:", e);
    return { version: 2, lastUpdated: new Date().toISOString(), records: [] } as StationMemoryStore;
  }
});

// ── Pure helpers (no I/O, safe for client bundle) ───────────────────────────

export function getMemoryRecordsByType(store: StationMemoryStore, type: MemoryRecordType): StationMemoryRecord[] {
  return store.records.filter((r) => r.type === type);
}

export function getMemoryRecord(store: StationMemoryStore, id: string): StationMemoryRecord | undefined {
  return store.records.find((r) => r.id === id);
}

export function searchMemory(store: StationMemoryStore, query: string): StationMemoryRecord[] {
  const q = query.toLowerCase().trim();
  if (!q) return store.records;
  return store.records.filter((r) => {
    const searchable = [
      r.title, r.summary, r.decision || "", r.reason || "",
      r.problem || "", r.rootCause || "", r.fix || "",
      r.neverDoThis || "", r.rule || "", r.issue || "",
      r.workaround || "", ...r.tags,
    ].join(" ").toLowerCase();
    return searchable.includes(q);
  });
}

export function getRelatedRecords(store: StationMemoryStore, record: StationMemoryRecord): StationMemoryRecord[] {
  if (!record.relatedIds || record.relatedIds.length === 0) return [];
  return store.records.filter((r) => record.relatedIds.includes(r.id));
}

export function getRecordsByTag(store: StationMemoryStore, tag: string): StationMemoryRecord[] {
  return store.records.filter((r) => r.tags.includes(tag));
}

export function getRecordsByAuthor(store: StationMemoryStore, author: string): StationMemoryRecord[] {
  return store.records.filter((r) => r.author === author);
}

export function getRecentRecords(store: StationMemoryStore, limit = 10): StationMemoryRecord[] {
  return [...store.records]
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    .slice(0, limit);
}
