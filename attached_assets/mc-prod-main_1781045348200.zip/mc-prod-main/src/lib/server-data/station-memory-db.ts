// src/lib/server-data/station-memory-db.ts
// Station Memory — SQLite-backed institutional knowledge store
// Uses better-sqlite3 for synchronous, high-performance local access.
// NOTE: This module uses Node.js built-ins (node:fs, better-sqlite3).
//       NEVER barrel-export this file. Import directly.

import Database from "better-sqlite3";
import { join } from "node:path";
import { existsSync, mkdirSync } from "node:fs";

const DB_PATH = join("/Users/spacemonkey/.openclaw/workspace", "data", "station-memory.db");

// ── Database singleton ───────────────────────────────────────────────────────

let db: Database.Database | null = null;

function getDb(): Database.Database {
  if (!db) {
    const dir = join("/Users/spacemonkey/.openclaw/workspace", "data");
    if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
    db = new Database(DB_PATH);
    db.pragma("journal_mode = WAL");
    db.pragma("foreign_keys = ON");
    initSchema(db);
  }
  return db;
}

// ── Schema ───────────────────────────────────────────────────────────────────

export function initSchema(database: Database.Database): void {
  database.exec(`
    CREATE TABLE IF NOT EXISTS records (
      id TEXT PRIMARY KEY,
      type TEXT NOT NULL CHECK(type IN (
        'architecture-decision','lesson-learned','incident-knowledge',
        'completed-task-summary','operational-decision','framework-rule',
        'runbook','known-issue','commit'
      )),
      title TEXT NOT NULL DEFAULT '',
      summary TEXT NOT NULL DEFAULT '',
      -- Architecture Decision
      decision TEXT DEFAULT NULL,
      reason TEXT DEFAULT NULL,
      supersedes TEXT DEFAULT NULL,
      -- Lesson Learned
      problem TEXT DEFAULT NULL,
      root_cause TEXT DEFAULT NULL,
      fix TEXT DEFAULT NULL,
      files_changed TEXT DEFAULT '[]',
      never_do_this TEXT DEFAULT NULL,
      -- Incident Knowledge
      timeline TEXT DEFAULT NULL,
      resolution TEXT DEFAULT NULL,
      prevention TEXT DEFAULT NULL,
      -- Completed Task
      original_objective TEXT DEFAULT NULL,
      outcome TEXT DEFAULT NULL,
      lessons TEXT DEFAULT '[]',
      recommendations TEXT DEFAULT '[]',
      -- Operational Decision
      alternative_considered TEXT DEFAULT NULL,
      decision_owner TEXT DEFAULT NULL,
      review_date TEXT DEFAULT NULL,
      -- Framework Rule
      rule TEXT DEFAULT NULL,
      examples TEXT DEFAULT NULL,
      -- Known Issue
      issue TEXT DEFAULT NULL,
      current_state TEXT DEFAULT NULL,
      workaround TEXT DEFAULT NULL,
      owner TEXT DEFAULT NULL,
      priority TEXT DEFAULT NULL CHECK(priority IS NULL OR priority IN ('P1','P2','P3','P4')),
      -- Commit metadata
      commit_hash TEXT DEFAULT NULL,
      commit_message TEXT DEFAULT NULL,
      commit_repo TEXT DEFAULT NULL,
      -- Common
      status TEXT DEFAULT 'current',
      date TEXT NOT NULL DEFAULT '',
      author TEXT NOT NULL DEFAULT 'unknown',
      source TEXT NOT NULL DEFAULT 'manual',
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS record_tags (
      record_id TEXT NOT NULL REFERENCES records(id) ON DELETE CASCADE,
      tag TEXT NOT NULL,
      PRIMARY KEY (record_id, tag)
    );

    CREATE TABLE IF NOT EXISTS record_relations (
      source_id TEXT NOT NULL REFERENCES records(id) ON DELETE CASCADE,
      target_id TEXT NOT NULL REFERENCES records(id) ON DELETE CASCADE,
      relation_type TEXT NOT NULL DEFAULT 'related',
      PRIMARY KEY (source_id, target_id)
    );

    CREATE INDEX IF NOT EXISTS idx_records_type ON records(type);
    CREATE INDEX IF NOT EXISTS idx_records_date ON records(date);
    CREATE INDEX IF NOT EXISTS idx_records_status ON records(status);
    CREATE INDEX IF NOT EXISTS idx_records_author ON records(author);
    CREATE INDEX IF NOT EXISTS idx_record_tags_tag ON record_tags(tag);
    CREATE INDEX IF NOT EXISTS idx_record_relations_source ON record_relations(source_id);
    CREATE INDEX IF NOT EXISTS idx_record_relations_target ON record_relations(target_id);

    -- Full-text search virtual table
    CREATE VIRTUAL TABLE IF NOT EXISTS records_fts USING fts5(
      id UNINDEXED,
      title,
      summary,
      decision,
      reason,
      problem,
      root_cause,
      fix,
      rule,
      issue,
      workaround,
      resolution,
      outcome,
      content=records,
      content_rowid=rowid
    );

    -- Triggers to keep FTS index in sync
    CREATE TRIGGER IF NOT EXISTS records_ai AFTER INSERT ON records BEGIN
      INSERT INTO records_fts(id, title, summary, decision, reason, problem, root_cause, fix, rule, issue, workaround, resolution, outcome)
      VALUES (new.id, new.title, new.summary, new.decision, new.reason, new.problem, new.root_cause, new.fix, new.rule, new.issue, new.workaround, new.resolution, new.outcome);
    END;

    CREATE TRIGGER IF NOT EXISTS records_ad AFTER DELETE ON records BEGIN
      INSERT INTO records_fts(records_fts, rowid, id, title, summary, decision, reason, problem, root_cause, fix, rule, issue, workaround, resolution, outcome)
      VALUES ('delete', old.rowid, old.id, old.title, old.summary, old.decision, old.reason, old.problem, old.root_cause, old.fix, old.rule, old.issue, old.workaround, old.resolution, old.outcome);
    END;

    CREATE TRIGGER IF NOT EXISTS records_au AFTER UPDATE ON records BEGIN
      INSERT INTO records_fts(records_fts, rowid, id, title, summary, decision, reason, problem, root_cause, fix, rule, issue, workaround, resolution, outcome)
      VALUES ('delete', old.rowid, old.id, old.title, old.summary, old.decision, old.reason, old.problem, old.root_cause, old.fix, old.rule, old.issue, old.workaround, old.resolution, old.outcome);
      INSERT INTO records_fts(id, title, summary, decision, reason, problem, root_cause, fix, rule, issue, workaround, resolution, outcome)
      VALUES (new.id, new.title, new.summary, new.decision, new.reason, new.problem, new.root_cause, new.fix, new.rule, new.issue, new.workaround, new.resolution, new.outcome);
    END;
  `);
}

// ── Types ────────────────────────────────────────────────────────────────────

export type MemoryRecordType =
  | "architecture-decision"
  | "lesson-learned"
  | "incident-knowledge"
  | "completed-task-summary"
  | "operational-decision"
  | "framework-rule"
  | "runbook"
  | "known-issue"
  | "commit";

export interface StationMemoryRecord {
  id: string;
  type: MemoryRecordType;
  title: string;
  summary: string;
  decision: string | null;
  reason: string | null;
  supersedes: string | null;
  problem: string | null;
  rootCause: string | null;
  fix: string | null;
  filesChanged: string[];
  neverDoThis: string | null;
  timeline: string | null;
  resolution: string | null;
  prevention: string | null;
  originalObjective: string | null;
  outcome: string | null;
  lessons: string[];
  recommendations: string[];
  alternativeConsidered: string | null;
  decisionOwner: string | null;
  reviewDate: string | null;
  rule: string | null;
  examples: string | null;
  issue: string | null;
  currentState: string | null;
  workaround: string | null;
  owner: string | null;
  priority: string | null;
  status: string;
  date: string;
  author: string;
  tags: string[];
  relatedIds: string[];
  source: string;
  createdAt: string;
  updatedAt: string;
  commitHash: string | null;
  commitMessage: string | null;
  commitRepo: string | null;
}

export interface SearchResult extends StationMemoryRecord {
  rank: number;
  relevanceScore: number;
}

// ── Row mapping ──────────────────────────────────────────────────────────────

function rowToRecord(row: Record<string, unknown>): StationMemoryRecord {
  const id = row.id as string;
  return {
    id,
    type: row.type as MemoryRecordType,
    title: row.title as string,
    summary: row.summary as string,
    decision: row.decision as string | null,
    reason: row.reason as string | null,
    supersedes: row.supersedes as string | null,
    problem: row.problem as string | null,
    rootCause: row.root_cause as string | null,
    fix: row.fix as string | null,
    filesChanged: JSON.parse((row.files_changed as string) || "[]"),
    neverDoThis: row.never_do_this as string | null,
    timeline: row.timeline as string | null,
    resolution: row.resolution as string | null,
    prevention: row.prevention as string | null,
    originalObjective: row.original_objective as string | null,
    outcome: row.outcome as string | null,
    lessons: JSON.parse((row.lessons as string) || "[]"),
    recommendations: JSON.parse((row.recommendations as string) || "[]"),
    alternativeConsidered: row.alternative_considered as string | null,
    decisionOwner: row.decision_owner as string | null,
    reviewDate: row.review_date as string | null,
    rule: row.rule as string | null,
    examples: row.examples as string | null,
    issue: row.issue as string | null,
    currentState: row.current_state as string | null,
    workaround: row.workaround as string | null,
    owner: row.owner as string | null,
    priority: row.priority as string | null,
    status: row.status as string,
    date: row.date as string,
    author: row.author as string,
    tags: [],
    relatedIds: [],
    source: row.source as string,
    createdAt: row.created_at as string,
    updatedAt: row.updated_at as string,
    commitHash: row.commit_hash as string | null,
    commitMessage: row.commit_message as string | null,
    commitRepo: row.commit_repo as string | null,
  };
}

function loadRelations(database: Database.Database, record: StationMemoryRecord): StationMemoryRecord {
  const tags = database.prepare("SELECT tag FROM record_tags WHERE record_id = ?").all(record.id) as { tag: string }[];
  const related = database.prepare("SELECT target_id FROM record_relations WHERE source_id = ?").all(record.id) as { target_id: string }[];
  record.tags = tags.map((t) => t.tag);
  record.relatedIds = related.map((r) => r.target_id);
  return record;
}

// ── CRUD Operations ─────────────────────────────────────────────────────────

export function getRecord(id: string): StationMemoryRecord | null {
  const database = getDb();
  const row = database.prepare("SELECT * FROM records WHERE id = ?").get(id) as Record<string, unknown> | undefined;
  if (!row) return null;
  return loadRelations(database, rowToRecord(row));
}

export function getAllRecords(): StationMemoryRecord[] {
  const database = getDb();
  const rows = database.prepare("SELECT * FROM records ORDER BY date DESC").all() as Record<string, unknown>[];
  return rows.map((row) => loadRelations(database, rowToRecord(row)));
}

export function getRecordsByType(type: MemoryRecordType): StationMemoryRecord[] {
  const database = getDb();
  const rows = database.prepare("SELECT * FROM records WHERE type = ? ORDER BY date DESC").all(type) as Record<string, unknown>[];
  return rows.map((row) => loadRelations(database, rowToRecord(row)));
}

export function insertRecord(record: Omit<StationMemoryRecord, "createdAt" | "updatedAt">): void {
  const database = getDb();
  const now = new Date().toISOString();
  database.prepare(`
    INSERT OR REPLACE INTO records (
      id, type, title, summary, decision, reason, supersedes,
      problem, root_cause, fix, files_changed, never_do_this,
      timeline, resolution, prevention,
      original_objective, outcome, lessons, recommendations,
      alternative_considered, decision_owner, review_date,
      rule, examples, issue, current_state, workaround, owner, priority,
      commit_hash, commit_message, commit_repo,
      status, date, author, source, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    record.id, record.type, record.title, record.summary,
    record.decision, record.reason, record.supersedes,
    record.problem, record.rootCause, record.fix,
    JSON.stringify(record.filesChanged || []), record.neverDoThis,
    record.timeline, record.resolution, record.prevention,
    record.originalObjective, record.outcome,
    JSON.stringify(record.lessons || []), JSON.stringify(record.recommendations || []),
    record.alternativeConsidered, record.decisionOwner, record.reviewDate,
    record.rule, record.examples, record.issue, record.currentState, record.workaround,
    record.owner, record.priority,
    record.commitHash, record.commitMessage, record.commitRepo,
    record.status || "current", record.date, record.author, record.source,
    now, now
  );

  // Upsert tags
  database.prepare("DELETE FROM record_tags WHERE record_id = ?").run(record.id);
  const insertTag = database.prepare("INSERT OR IGNORE INTO record_tags (record_id, tag) VALUES (?, ?)");
  for (const tag of record.tags || []) {
    insertTag.run(record.id, tag);
  }

  // Upsert relations
  database.prepare("DELETE FROM record_relations WHERE source_id = ?").run(record.id);
  const insertRel = database.prepare("INSERT OR IGNORE INTO record_relations (source_id, target_id, relation_type) VALUES (?, ?, ?)");
  for (const targetId of record.relatedIds || []) {
    insertRel.run(record.id, targetId, "related");
  }
}

export function deleteRecord(id: string): boolean {
  const database = getDb();
  const result = database.prepare("DELETE FROM records WHERE id = ?").run(id);
  return result.changes > 0;
}

// ── Search ───────────────────────────────────────────────────────────────────

export function searchRecords(query: string, type?: MemoryRecordType, limit = 20): SearchResult[] {
  const database = getDb();
  const q = query.trim();
  if (!q) {
    const records = type ? getRecordsByType(type) : getAllRecords();
    return records.slice(0, limit).map((r) => ({ ...r, rank: 0, relevanceScore: 0 }));
  }

  // Try FTS5 first, fall back to LIKE
  try {
    const ftsQuery = q.split(/\s+/).map((t) => `"${t.replace(/"/g, "")}"`).join(" OR ");
    let sql = `
      SELECT r.*, rank
      FROM records_fts fts
      JOIN records r ON r.id = fts.id
      WHERE records_fts MATCH ?
    `;
    const params: unknown[] = [ftsQuery];
    if (type) {
      sql += " AND r.type = ?";
      params.push(type);
    }
    sql += " ORDER BY rank LIMIT ?";
    params.push(limit);

    const rows = database.prepare(sql).all(...params) as (Record<string, unknown> & { rank: number })[];
    if (rows.length > 0) {
      return rows.map((row) => {
        const record = loadRelations(database, rowToRecord(row));
        return { ...record, rank: Math.abs(row.rank), relevanceScore: 1 / (1 + Math.abs(row.rank)) };
      });
    }
  } catch {
    // FTS query may fail on special chars — fall through to LIKE
  }

  // Fallback: LIKE search across key fields
  const likeQ = `%${q}%`;
  let sql = `
    SELECT * FROM records
    WHERE (title LIKE ? OR summary LIKE ? OR decision LIKE ? OR reason LIKE ?
      OR problem LIKE ? OR root_cause LIKE ? OR fix LIKE ? OR rule LIKE ?
      OR issue LIKE ? OR workaround LIKE ? OR resolution LIKE ? OR outcome LIKE ?)
  `;
  const params: unknown[] = Array(12).fill(likeQ);
  if (type) {
    sql += " AND type = ?";
    params.push(type);
  }
  sql += " ORDER BY date DESC LIMIT ?";
  params.push(limit);

  const rows = database.prepare(sql).all(...params) as Record<string, unknown>[];
  return rows.map((row, i) => {
    const record = loadRelations(database, rowToRecord(row));
    return { ...record, rank: i, relevanceScore: 1 / (1 + i) };
  });
}

export function searchByTag(tag: string): StationMemoryRecord[] {
  const database = getDb();
  const rows = database.prepare(`
    SELECT r.* FROM records r
    JOIN record_tags rt ON rt.record_id = r.id
    WHERE rt.tag = ?
    ORDER BY r.date DESC
  `).all(tag) as Record<string, unknown>[];
  return rows.map((row) => loadRelations(database, rowToRecord(row)));
}

export function searchByAuthor(author: string): StationMemoryRecord[] {
  const database = getDb();
  const rows = database.prepare("SELECT * FROM records WHERE author = ? ORDER BY date DESC").all(author) as Record<string, unknown>[];
  return rows.map((row) => loadRelations(database, rowToRecord(row)));
}

// ── Relations ────────────────────────────────────────────────────────────────

export function getRelatedRecords(id: string): StationMemoryRecord[] {
  const database = getDb();
  const rows = database.prepare(`
    SELECT r.* FROM records r
    JOIN record_relations rel ON rel.target_id = r.id
    WHERE rel.source_id = ?
  `).all(id) as Record<string, unknown>[];
  return rows.map((row) => loadRelations(database, rowToRecord(row)));
}

export function getReverseRelatedRecords(id: string): StationMemoryRecord[] {
  const database = getDb();
  const rows = database.prepare(`
    SELECT r.* FROM records r
    JOIN record_relations rel ON rel.source_id = r.id
    WHERE rel.target_id = ?
  `).all(id) as Record<string, unknown>[];
  return rows.map((row) => loadRelations(database, rowToRecord(row)));
}

export function getAllRelations(id: string): StationMemoryRecord[] {
  const database = getDb();
  const rows = database.prepare(`
    SELECT r.* FROM records r
    JOIN record_relations rel ON rel.target_id = r.id
    WHERE rel.source_id = ?
    UNION
    SELECT r.* FROM records r
    JOIN record_relations rel ON rel.source_id = r.id
    WHERE rel.target_id = ?
  `).all(id, id) as Record<string, unknown>[];
  return rows.map((row) => loadRelations(database, rowToRecord(row)));
}

// ── Stats ────────────────────────────────────────────────────────────────────

export function getStats(): { total: number; byType: Record<string, number>; byStatus: Record<string, number> } {
  const database = getDb();
  const total = (database.prepare("SELECT COUNT(*) as n FROM records").get() as { n: number }).n;
  const byTypeRows = database.prepare("SELECT type, COUNT(*) as n FROM records GROUP BY type").all() as { type: string; n: number }[];
  const byStatusRows = database.prepare("SELECT status, COUNT(*) as n FROM records GROUP BY status").all() as { status: string; n: number }[];
  return {
    total,
    byType: Object.fromEntries(byTypeRows.map((r) => [r.type, r.n])),
    byStatus: Object.fromEntries(byStatusRows.map((r) => [r.status, r.n])),
  };
}

// ── Ingestion helpers ────────────────────────────────────────────────────────

export function ingestTask(task: Record<string, unknown>): string | null {
  const id = task.id as string;
  if (!id) return null;

  const now = new Date().toISOString();
  const record: Omit<StationMemoryRecord, "createdAt" | "updatedAt"> = {
    id: `task-${id}`,
    type: "completed-task-summary",
    title: (task.title as string) || `Task ${id}`,
    summary: (task.summary as string) || (task.note as string) || (task.description as string) || "",
    decision: null,
    reason: null,
    supersedes: null,
    problem: null,
    rootCause: null,
    fix: null,
    filesChanged: [],
    neverDoThis: null,
    timeline: null,
    resolution: null,
    prevention: null,
    originalObjective: (task.note as string) || (task.description as string) || "",
    outcome: (task.summary as string) || "",
    lessons: [],
    recommendations: [],
    alternativeConsidered: null,
    decisionOwner: null,
    reviewDate: null,
    rule: null,
    examples: null,
    issue: null,
    currentState: null,
    workaround: null,
    owner: null,
    priority: (task.priority as string) || null,
    status: "current",
    date: now.slice(0, 10),
    author: (task.author as string) || "monkey",
    tags: ["auto-ingested", "task"],
    relatedIds: [],
    source: "task-completion",
  };

  // Extract files from history
  const history = (task.history as Record<string, unknown>[]) || [];
  const filesSet = new Set<string>();
  for (const entry of history) {
    const details = (entry.details as string) || "";
    const fileMatches = details.match(/[\w\-./]+\.(ts|tsx|js|jsx|sh|json|md|css|html)/g);
    if (fileMatches) fileMatches.forEach((f) => filesSet.add(f));
  }
  record.filesChanged = [...filesSet];

  // Extract lessons from summary
  if (record.outcome) {
    const lessonMatch = record.outcome.match(/(?:lesson|learned|key insight|takeaway)s?:?\s*([^.]+)/gi);
    if (lessonMatch) record.lessons = lessonMatch.map((l) => l.trim());
  }

  insertRecord(record);
  return record.id;
}

export function ingestIncident(incident: Record<string, unknown>): string | null {
  const id = incident.id as string;
  if (!id) return null;

  const now = new Date().toISOString();
  const record: Omit<StationMemoryRecord, "createdAt" | "updatedAt"> = {
    id: `inc-${id}`,
    type: "incident-knowledge",
    title: (incident.title as string) || (incident.summary as string) || `Incident ${id}`,
    summary: (incident.summary as string) || "",
    decision: null,
    reason: null,
    supersedes: null,
    problem: (incident.summary as string) || "",
    rootCause: (incident.rootCause as string) || null,
    fix: null,
    filesChanged: [],
    neverDoThis: null,
    timeline: null,
    resolution: (incident.resolution as string) || null,
    prevention: (incident.prevention as string) || null,
    originalObjective: null,
    outcome: (incident.resolution as string) || null,
    lessons: [],
    recommendations: [],
    alternativeConsidered: null,
    decisionOwner: null,
    reviewDate: null,
    rule: null,
    examples: null,
    issue: (incident.summary as string) || null,
    currentState: null,
    workaround: null,
    owner: null,
    priority: (incident.severity as string) || null,
    status: (incident.status as string) || "resolved",
    date: (incident.date as string) || now.slice(0, 10),
    author: (incident.author as string) || "monkey",
    tags: ["auto-ingested", "incident"],
    relatedIds: [],
    source: "incident-resolution",
  };

  // Link to related tasks
  const linkedTaskIds = (incident.linkedTaskIds as string[]) || [];
  record.relatedIds = linkedTaskIds.map((tid) => `task-${tid}`);

  insertRecord(record);
  return record.id;
}

// ── Seed from JSON ───────────────────────────────────────────────────────────

export function seedFromJson(jsonPath: string): number {
  const { readFileSync, existsSync } = require("node:fs");
  if (!existsSync(jsonPath)) return 0;

  const data = JSON.parse(readFileSync(jsonPath, "utf-8"));
  const records = (data.records as Record<string, unknown>[]) || [];
  let count = 0;

  for (const r of records) {
    try {
      const record: Omit<StationMemoryRecord, "createdAt" | "updatedAt"> = {
        id: r.id as string,
        type: r.type as MemoryRecordType,
        title: r.title as string,
        summary: r.summary as string,
        decision: (r.decision as string) || null,
        reason: (r.reason as string) || null,
        supersedes: (r.supersedes as string) || null,
        problem: (r.problem as string) || null,
        rootCause: (r.rootCause as string) || null,
        fix: (r.fix as string) || null,
        filesChanged: (r.filesChanged as string[]) || [],
        neverDoThis: (r.neverDoThis as string) || null,
        timeline: (r.timeline as string) || null,
        resolution: (r.resolution as string) || null,
        prevention: (r.prevention as string) || null,
        originalObjective: (r.originalObjective as string) || null,
        outcome: (r.outcome as string) || null,
        lessons: (r.lessons as string[]) || [],
        recommendations: (r.recommendations as string[]) || [],
        alternativeConsidered: (r.alternativeConsidered as string) || null,
        decisionOwner: (r.decisionOwner as string) || null,
        reviewDate: (r.reviewDate as string) || null,
        rule: (r.rule as string) || null,
        examples: (r.examples as string) || null,
        issue: (r.issue as string) || null,
        currentState: (r.currentState as string) || null,
        workaround: (r.workaround as string) || null,
        owner: (r.owner as string) || null,
        priority: (r.priority as string) || null,
        status: (r.status as string) || "current",
        date: (r.date as string) || new Date().toISOString().slice(0, 10),
        author: (r.author as string) || "monkey",
        tags: (r.tags as string[]) || [],
        relatedIds: (r.relatedIds as string[]) || [],
        source: (r.source as string) || "manual",
      };
      insertRecord(record);
      count++;
    } catch (e) {
      console.error(`Failed to seed record ${r.id}:`, e);
    }
  }

  return count;
}

// ── Close (for testing) ──────────────────────────────────────────────────────

export function closeDb(): void {
  if (db) {
    db.close();
    db = null;
  }
}
