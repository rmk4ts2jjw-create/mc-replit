// src/lib/server-data/helpers.ts
// Shared utility functions
// NOTE: node:fs is lazy-imported to avoid pulling it into client bundles.
// These functions are only called from server-side code (createServerFn handlers),
// but the module itself may be imported by client components through barrel exports.
import { WORKSPACE } from "./types";

export async function readFileOrNull(path: string): Promise<string | null> {
  try {
    const { existsSync, readFileSync } = await import("node:fs");
    if (!existsSync(path)) return null;
    return readFileSync(path, "utf-8");
  } catch {
    return null;
  }
}

export async function readJsonOrNull<T>(path: string): Promise<T | null> {
  const raw = await readFileOrNull(path);
  if (!raw) return null;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return null;
  }
}

export function normalizeTasks(data: unknown): unknown[] {
  if (Array.isArray(data)) return data;
  if (data && typeof data === "object") {
    return Object.entries(data as Record<string, unknown>).map(([id, task]) => {
      const t = task as Record<string, unknown>;
      if (t && typeof t === "object" && !("id" in t)) {
        return { ...t, id };
      }
      return t;
    });
  }
  return [];
}

export function formatBytes(bytes: number): string {
  if (bytes === 0) return "0 B";
  const k = 1024;
  const sizes = ["B", "KB", "MB", "GB", "TB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + " " + sizes[i];
}

export function extractTitle(md: string): string {
  const h1 = md.match(/^#\s+(.+)/m);
  if (h1) return h1[1].replace(/<!--.*?>/g, "").trim();
  const h2 = md.match(/^##\s+(.+)/m);
  if (h2) return h2[1].replace(/<!--.*?>/g, "").trim();
  return "Untitled";
}

export function parseSize(s: string): number {
  const match = s.match(/^([\d.]+)\s*([KMGT]?B?)$/i);
  if (!match) return 0;
  const num = parseFloat(match[1]);
  const unit = (match[2] || "B").toUpperCase();
  const mult = unit.startsWith("K") ? 1024 : unit.startsWith("M") ? 1024 ** 2 : unit.startsWith("G") ? 1024 ** 3 : unit.startsWith("T") ? 1024 ** 4 : 1;
  return num * mult;
}
