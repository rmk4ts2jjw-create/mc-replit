// src/lib/server-data/predictions.ts
// Reads prediction state and auto-heal audit data for dashboard display
// NOTE: node:fs/node:path are lazy-imported inside functions to avoid client bundle leak

const WORKSPACE = "/Users/spacemonkey/.openclaw/workspace";

export interface PredictionState {
  checks: Record<string, Array<{ ts: string; [key: string]: unknown }>>;
  predictions: Array<{
    ts: string;
    pattern: string;
    confidence: number;
    detail: string;
    status: string;
  }>;
  accuracy: Record<string, { total: number; correct: number }>;
}

export interface AutoHealState {
  auto_heal_level: string;
  total_heals: number;
  success_count: number;
  fail_count: number;
}

export interface AutoHealAuditEntry {
  ts: string;
  task_id: string;
  task_title: string;
  dry_run: boolean;
  results: Array<{
    pattern: string;
    status: string;
    reason?: string;
  }>;
}

export interface RiskMeterItem {
  pattern: string;
  label: string;
  confidence: number;
  detail: string;
  detectedAt: string;
  status: "active" | "mitigated" | "expired";
}

export async function getPredictionState(): Promise<PredictionState> {
  const { readFileSync, existsSync } = await import("node:fs");
  const { join } = await import("node:path");
  try {
    const path = join(WORKSPACE, "data/prediction-state.json");
    if (!existsSync(path)) return { checks: {}, predictions: [], accuracy: {} };
    return JSON.parse(readFileSync(path, "utf-8")) as PredictionState;
  } catch {
    return { checks: {}, predictions: [], accuracy: {} };
  }
}

export async function getAutoHealState(): Promise<AutoHealState> {
  const { readFileSync, existsSync } = await import("node:fs");
  const { join } = await import("node:path");
  try {
    const path = join(WORKSPACE, "data/auto-heal-state.json");
    if (!existsSync(path)) return { auto_heal_level: "none", total_heals: 0, success_count: 0, fail_count: 0 };
    return JSON.parse(readFileSync(path, "utf-8")) as AutoHealState;
  } catch {
    return { auto_heal_level: "none", total_heals: 0, success_count: 0, fail_count: 0 };
  }
}

export async function getAutoHealAudit(): Promise<AutoHealAuditEntry[]> {
  const { readFileSync, existsSync } = await import("node:fs");
  const { join } = await import("node:path");
  try {
    const path = join(WORKSPACE, "data/auto-heal-audit.json");
    if (!existsSync(path)) return [];
    return JSON.parse(readFileSync(path, "utf-8")) as AutoHealAuditEntry[];
  } catch {
    return [];
  }
}

export async function getRiskMeterItems(): Promise<RiskMeterItem[]> {
  const { readFileSync, existsSync } = await import("node:fs");
  const { join } = await import("node:path");
  let predictions: PredictionState["predictions"] = [];
  try {
    const path = join(WORKSPACE, "data/prediction-state.json");
    if (existsSync(path)) {
      const state = JSON.parse(readFileSync(path, "utf-8")) as PredictionState;
      predictions = state.predictions;
    }
  } catch { /* ignore */ }

  const now = Date.now();
  return predictions
    .filter((p) => {
      const age = now - new Date(p.ts).getTime();
      return age < 86400000 && p.status === "pending";
    })
    .sort((a, b) => b.confidence - a.confidence)
    .slice(0, 3)
    .map((p) => ({
      pattern: p.pattern,
      label: p.pattern.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase()),
      confidence: p.confidence,
      detail: p.detail,
      detectedAt: p.ts,
      status: "active" as const,
    }));
}