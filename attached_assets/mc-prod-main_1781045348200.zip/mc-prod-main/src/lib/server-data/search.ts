// src/lib/server-data/search.ts
// NOTE: node:fs is lazy-imported to avoid pulling it into client bundles.

import { createServerFn } from "@tanstack/react-start";
import { WORKSPACE, OPENCLAW_DIR, type Task, type Project, type Incident, type SearchResult } from "./types";
import { readJsonOrNull, extractTitle, normalizeTasks } from "./helpers";
// NOTE: Do NOT import station-memory statically — it contains node:fs imports
// that leak into client bundle. Use dynamic import instead.

export const search = createServerFn({ method: "GET" })
  .inputValidator((d: unknown) => d as { query: string })
  .handler(async ({ data }) => {
    const q = data.query.toLowerCase().trim();
    if (!q) return [] as SearchResult[];
    const results: SearchResult[] = [];

    const raw = await readJsonOrNull<unknown>(`${WORKSPACE}/data/tasks.json`);
    const tasks = normalizeTasks(raw) as unknown as Task[];
    for (const t of tasks) {
      if (t.title.toLowerCase().includes(q) || t.id.toLowerCase().includes(q) || (t.note && t.note.toLowerCase().includes(q))) {
        results.push({ id: t.id, title: t.title, snippet: t.note || t.status, type: "task", url: "/tasks" });
      }
    }

    const projects = await readJsonOrNull<Project[]>(`${WORKSPACE}/data/projects.json`) || [];
    for (const p of projects) {
      if (p.name.toLowerCase().includes(q) || p.description.toLowerCase().includes(q)) {
        results.push({ id: p.id, title: p.name, snippet: p.description, type: "project", url: "/projects" });
      }
    }

    const incidents = await readJsonOrNull<Incident[]>(`${WORKSPACE}/data/incidents.json`) || [];
    for (const inc of incidents) {
      if (inc.title.toLowerCase().includes(q) || inc.summary.toLowerCase().includes(q)) {
        results.push({ id: inc.id, title: inc.title, snippet: inc.summary, type: "incident", url: "/incidents" });
      }
    }

    try {
      const { existsSync, readdirSync, readFileSync } = await import("node:fs");
      const memDir = `${WORKSPACE}/memory`;
      if (existsSync(memDir)) {
        const memFiles = readdirSync(memDir).filter((f) => /^\d{4}-\d{2}-\d{2}\.md$/.test(f));
        for (const file of memFiles) {
          const body = readFileSync(`${memDir}/${file}`, "utf-8");
          const title = extractTitle(body);
          if (title.toLowerCase().includes(q) || body.toLowerCase().includes(q)) {
            const snippet = body.split("\n").find((l) => l.toLowerCase().includes(q) && !l.startsWith("#"))?.trim() || "";
            results.push({ id: file, title, snippet: snippet.slice(0, 120), type: "memory", url: "/memory", date: file.replace(".md", "") });
          }
        }
      }

      const exclude = new Set(["AGENTS.md", "SOUL.md", "IDENTITY.md", "USER.md", "TOOLS.md", "MEMORY.md", "HEARTBEAT.md", "BACKUP_GUIDE.md", "RECOVERY_GUIDE.md"]);
      const docFiles = readdirSync(WORKSPACE).filter((f) => f.endsWith(".md") && !exclude.has(f));
      for (const file of docFiles) {
        const body = readFileSync(`${WORKSPACE}/${file}`, "utf-8");
        const title = extractTitle(body);
        if (title.toLowerCase().includes(q) || body.toLowerCase().includes(q)) {
          const snippet = body.split("\n").find((l) => l.toLowerCase().includes(q) && !l.startsWith("#"))?.trim() || "";
          results.push({ id: file, title, snippet: snippet.slice(0, 120), type: "doc", url: "/docs" });
        }
      }
    } catch { /* ignore */ }

    const cfg = await readJsonOrNull<Record<string, unknown>>(`${OPENCLAW_DIR}/openclaw.json`);
    if (cfg && Array.isArray(cfg.cron)) {
      for (const job of cfg.cron as Record<string, unknown>[]) {
        const name = String(job.name || job.schedule || "");
        if (name.toLowerCase().includes(q)) {
          results.push({ id: String(job.id || ""), title: name, snippet: String(job.schedule || ""), type: "cron", url: "/scheduler" });
        }
      }
    }

    // 8. Station Memory records
    try {
      const { getStationMemory } = await import("./station-memory");
      const memStore = getStationMemory();
      for (const rec of memStore.records) {
        const searchable = [rec.title, rec.summary, rec.decision || "", rec.reason || "", rec.problem || "", rec.rootCause || "", rec.fix || "", rec.rule || "", rec.issue || "", ...rec.tags].join(" ").toLowerCase();
        if (searchable.includes(q)) {
          results.push({
            id: rec.id,
            title: rec.title,
            snippet: rec.summary.slice(0, 120),
            type: "station-memory" as const,
            url: "/memory",
            date: rec.date,
          });
        }
      }
    } catch { /* ignore */ }

    return results.slice(0, 25) as SearchResult[];
  });
