// src/lib/server-data/performance.ts
// Reads performance tuning state for dashboard display
// NOTE: node:fs/node:path are lazy-imported inside createServerFn handlers only.

import { createServerFn } from "@tanstack/react-start";

const WORKSPACE = "/Users/spacemonkey/.openclaw/workspace";

export interface AgentPerformance {
  total_tasks: number;
  done: number;
  failed: number;
  in_progress: number;
  avg_task_hours: number;
  failure_rate: number;
  success_rate: number;
  analyzed_at: string;
}

export interface TuneTask {
  agent: string;
  rule_id: string;
  label: string;
  confidence: number;
  risk: string;
  status: string;
  generated_at: string;
}

export interface AppliedTune {
  ts: string;
  agent: string;
  rule_id: string;
  success: boolean;
  detail: string;
}

export interface PerformanceState {
  agents: Record<string, AgentPerformance>;
  tune_tasks: TuneTask[];
  applied_tunes: AppliedTune[];
}

export const getPerformanceState = createServerFn({ method: "GET" }).handler(async () => {
  const { readFileSync, existsSync } = await import("node:fs");
  const { join } = await import("node:path");
  try {
    const path = join(WORKSPACE, "data/performance-state.json");
    if (!existsSync(path)) return { agents: {}, tune_tasks: [], applied_tunes: [] };
    return JSON.parse(readFileSync(path, "utf-8")) as PerformanceState;
  } catch {
    return { agents: {}, tune_tasks: [], applied_tunes: [] };
  }
});
