import { Link, useRouterState } from "@tanstack/react-router";
import {
  Home,
  Target,
  Calendar as CalendarIcon,
  Brain,
  FileText,
  Users,
  Gamepad2,
  Satellite,
  AlertTriangle,
  Menu,
  X,
  Zap,
  Settings,
  BookOpen,
  Eye,
  Clock,
} from "lucide-react";
import { useState, useEffect } from "react";
import monkey from "@/assets/sprite-monkey-idle.png";
import { getAwaitingReviewCount } from "@/lib/server-data/openclaw-status";
import { getBacklogCount } from "@/lib/server-data/tasks";

const sections = [
  {
    label: "OPERATIONS",
    items: [
      { title: "Tasks", to: "/tasks", icon: Target },
      { title: "Incidents", to: "/incidents", icon: AlertTriangle },
      { title: "Scheduler", to: "/scheduler", icon: CalendarIcon },
    ],
  },
  {
    label: "KNOWLEDGE",
    items: [
      { title: "Memory", to: "/memory", icon: Brain },
      { title: "Docs", to: "/docs", icon: FileText },
    ],
  },
  {
    label: "STATION",
    items: [
      { title: "Agent Office", to: "/visual", icon: Eye },
      { title: "Team", to: "/team", icon: Users },
      { title: "Activity", to: "/activity", icon: Zap },
      { title: "Timeline", to: "/timeline", icon: Clock },
      { title: "Settings", to: "/settings", icon: Settings },
    ],
  },
] as const;

export function AppSidebar() {
  const path = useRouterState({ select: (s) => s.location.pathname });
  const [mobileOpen, setMobileOpen] = useState(false);
  const [awaitingReviewCount, setAwaitingReviewCount] = useState(0);
  const [backlogCount, setBacklogCount] = useState(0);

  // Poll for awaiting review + backlog counts
  useEffect(() => {
    const fetchCounts = async () => {
      try {
        const [reviewRes, backlogRes] = await Promise.all([
          getAwaitingReviewCount(),
          getBacklogCount(),
        ]);
        setAwaitingReviewCount(reviewRes.count);
        setBacklogCount(backlogRes.count);
      } catch { /* ignore */ }
    };
    fetchCounts();
    const interval = setInterval(fetchCounts, 30000); // every 30s
    return () => clearInterval(interval);
  }, []);

  const isActive = (to: string) => {
    if (to === "/") return path === "/";
    if (to === "/visual") return path === "/visual" || path === "/spacestation";
    return path === to || path.startsWith(to + "/");
  };

  return (
    <>
      {/* Mobile header */}
      <div className="md:hidden flex items-center justify-between px-4 py-3 border-b border-sidebar-border bg-sidebar">
        <button onClick={() => setMobileOpen(!mobileOpen)} className="text-sidebar-foreground">
          {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
        <Link to="/" className="font-mono text-sm font-bold tracking-[0.18em]" aria-label="Mission Control dashboard">MISSION CONTROL</Link>
        <div className="w-5" />
      </div>

      {/* Mobile overlay */}
      {mobileOpen && (
        <div className="fixed inset-0 z-40 bg-background/80 backdrop-blur-sm md:hidden" onClick={() => setMobileOpen(false)} />
      )}

      {/* Sidebar */}
      <aside
        className={[
          "w-60 shrink-0 flex-col bg-sidebar text-sidebar-foreground border-r border-sidebar-border",
          "fixed inset-y-0 left-0 z-50 md:relative md:z-0 md:flex",
          "transition-transform duration-200",
          mobileOpen ? "flex translate-x-0" : "hidden -translate-x-full md:flex md:translate-x-0",
        ].join(" ")}
      >
        {/* Header — clickable Home */}
        <div className="px-5 pt-6 pb-4">
          <Link to="/" className="block" onClick={() => setMobileOpen(false)} aria-label="Mission Control home">
            <div className="rounded-lg border border-sidebar-border bg-card/40 px-4 py-3 shadow-[inset_0_0_0_1px_oklch(0.30_0.10_295/0.25)]">
              <div className="font-mono text-[11px] tracking-[0.22em] text-muted-foreground">MISSION</div>
              <div className="font-mono text-base font-bold tracking-[0.18em]">CONTROL</div>
            </div>
          </Link>
          <div className="mt-3 flex items-center gap-2 px-1">
            <span className="status-dot online animate-pulse-soft" />
            <Satellite className="h-3.5 w-3.5 text-violet/90" />
            <span className="font-mono text-[11px] tracking-[0.22em] text-muted-foreground">
              STATION <span className="text-foreground/90">ONLINE</span>
            </span>
          </div>
        </div>

        {/* Home nav item */}
        <div className="px-3 mb-2">
          <Link
            to="/"
            onClick={() => setMobileOpen(false)}
            aria-label="Dashboard home"
            className={[
              "group flex items-center justify-between rounded-md px-3 py-2 text-sm transition-colors",
              isActive("/")
                ? "bg-sidebar-accent text-sidebar-accent-foreground border border-violet/40 shadow-[0_0_0_1px_oklch(0.62_0.22_295/0.25),0_8px_24px_-12px_oklch(0.62_0.22_295/0.5)]"
                : "text-sidebar-foreground/80 hover:bg-card/40 hover:text-sidebar-foreground",
            ].join(" ")}
          >
            <span className="flex items-center gap-3">
              <Home className="h-4 w-4" />
              <span className="font-medium">Dashboard</span>
            </span>
            {isActive("/") && <span className="status-dot online" />}
          </Link>
        </div>

        <nav className="flex-1 px-3 py-2 space-y-4 overflow-y-auto">
          {sections.map((section) => (
            <div key={section.label} className="space-y-1">
              <div className="px-3 pt-1 pb-1 font-mono text-[10px] tracking-[0.28em] text-muted-foreground/70" role="heading" aria-level={3}>
                {section.label}
              </div>
              {section.items.map((item) => {
                const active = isActive(item.to);
                const Icon = item.icon;
                const isTasks = item.to === "/tasks";
                const reviewBadge = isTasks && awaitingReviewCount > 0;
                const backlogBadge = isTasks && backlogCount > 0;
                return (
                  <Link
                    key={item.to}
                    to={item.to}
                    onClick={() => setMobileOpen(false)}
                    aria-label={`${item.title}${reviewBadge ? ` (${awaitingReviewCount} awaiting review)` : ""}${active ? " (current page)" : ""}`}
                    aria-current={active ? "page" : undefined}
                    className={[
                      "group flex items-center justify-between rounded-md px-3 py-2 text-sm transition-colors",
                      active
                        ? "bg-sidebar-accent text-sidebar-accent-foreground border border-violet/40 shadow-[0_0_0_1px_oklch(0.62_0.22_295/0.25),0_8px_24px_-12px_oklch(0.62_0.22_295/0.5)]"
                        : "text-sidebar-foreground/80 hover:bg-card/40 hover:text-sidebar-foreground",
                    ].join(" ")}
                  >
                    <span className="flex items-center gap-3">
                      <Icon className="h-4 w-4" />
                      <span className="font-medium">{item.title}</span>
                    </span>
                    {reviewBadge ? (
                      <span className="inline-flex items-center justify-center rounded-full bg-warning/20 border border-warning/40 px-1.5 py-0.5 font-mono text-[9px] font-bold text-warning min-w-[20px]" aria-label={`${awaitingReviewCount} tasks awaiting review`}>
                        {awaitingReviewCount}
                      </span>
                    ) : backlogBadge ? (
                      <span className="inline-flex items-center justify-center rounded-full bg-violet/20 border border-violet/40 px-1.5 py-0.5 font-mono text-[9px] font-bold text-violet min-w-[20px]" aria-label={`${backlogCount} tasks in backlog`}>
                        {backlogCount}
                      </span>
                    ) : active && <span className="status-dot online" />}
                  </Link>
                );
              })}
            </div>
          ))}
        </nav>

        <div className="px-5 py-4 border-t border-sidebar-border">
          <div className="flex items-center gap-2">
            <img src={monkey} alt="Space Monkey" className="h-7 w-7 rounded-full border border-violet/50 object-cover" />
            <div className="font-mono text-[11px] text-muted-foreground tracking-wider">
              SPACE <span className="text-foreground/90">MONKEY</span>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
}
