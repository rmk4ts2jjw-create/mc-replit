import { useEffect, useState, useRef } from "react";
import { getCrew, CREW } from "@/lib/crew";
import type { AgentStatus, SystemStats, OpenClawStatus, ActivityEvent, Incident } from "@/lib/server-data-types";
import type { Task } from "@/lib/server-data-types";
import { getDreamingState, toggleDreaming } from "@/lib/dreaming";
import { Power, Moon, Activity, CheckCircle, AlertTriangle, Clock, Zap, HeartPulse, Wrench, TrendingUp } from "lucide-react";
import { Link } from "@tanstack/react-router";
import { AgentOffice } from "./AgentOffice";
import { AmbientStation } from "./AmbientStation";
import { StationFloorplan } from "./StationFloorplan";
import { CelebrationOverlay } from "./CelebrationOverlay";
import { RecentEventsPanel } from "./RecentEventsPanel";
import { DashboardRefresher } from "./DashboardRefresher";
import type { RiskMeterItem, AutoHealState, AutoHealAuditEntry } from "@/lib/server-data/predictions";
import type { PerformanceState } from "@/lib/server-data/performance";

// ── Types ────────────────────────────────────────────────────────────────────

// ── Live Activity Feed ─────────────────────────────────────────────────────
function LiveActivityFeed({ events, stats }: { events: ActivityEvent[]; stats: SystemStats }) {
  const [currentTime, setCurrentTime] = useState<Date | null>(null);
  useEffect(() => { setCurrentTime(new Date()); const t = setInterval(() => setCurrentTime(new Date()), 1000); return () => clearInterval(t); }, []);

  const workingCount = stats.activeCrons || 0;
  const memPercent = stats.memoryPercent;
  const diskPercent = stats.diskPercent;

  return (
    <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1">
      {/* Station clock */}
      <div className="rounded-lg border border-border/30 bg-card/20 px-2 py-1 text-center">
        <div className="font-mono text-sm font-bold tracking-wider">{currentTime ? currentTime.toLocaleTimeString("en-GB") : "--:--:--"}</div>
        <div className="font-mono text-[8px] text-muted-foreground/50">{currentTime ? currentTime.toLocaleDateString("en-GB", { weekday: "long", day: "numeric", month: "long" }) : "---"}</div>
      </div>

      {/* Quick status */}
      <div className="rounded-lg border border-border/30 bg-card/20 px-3 py-2 space-y-2">
        <div className="font-mono text-[9px] tracking-[0.2em] text-muted-foreground/60">STATION STATUS</div>
        <div className="grid grid-cols-2 gap-2">
          <div className="flex items-center gap-1.5 text-xs">
            <Zap className="h-3 w-3 text-[oklch(0.88_0.18_145)]" />
            <span>{workingCount} active</span>
          </div>
          <div className="flex items-center gap-1.5 text-xs">
            <HeartPulse className="h-3 w-3 text-[oklch(0.88_0.18_145)]" />
            <span>{memPercent}% mem</span>
          </div>
          <div className="flex items-center gap-1.5 text-xs">
            <Activity className="h-3 w-3 text-cyan-accent" />
            <span>{diskPercent}% disk</span>
          </div>
          <div className="flex items-center gap-1.5 text-xs">
            <CheckCircle className="h-3 w-3 text-[oklch(0.88_0.18_145)]" />
            <span>{stats.gatewayStatus}</span>
          </div>
        </div>
      </div>

      {/* Live activity feed */}
      <div className="rounded-lg border border-border/30 bg-card/20 overflow-hidden">
        <div className="px-3 py-2 border-b border-border/20 font-mono text-[9px] tracking-[0.2em] text-muted-foreground/60">LIVE ACTIVITY</div>
        <div className="max-h-64 overflow-y-auto">
          {events.length === 0 ? (
            <div className="px-3 py-4 text-center text-xs text-muted-foreground/50">No recent activity</div>
          ) : (
            events.slice(0, 15).map((e) => (
              <div key={e.id} className="activity-item flex items-start gap-2 px-3 py-1.5 text-xs border-b border-border/10 last:border-0">
                <span className="font-mono text-[9px] text-muted-foreground/40 shrink-0 mt-0.5">
                  {new Date(e.ts).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" })}
                </span>
                <span className={`font-mono text-[8px] tracking-wider shrink-0 mt-0.5 ${e.type === "task" ? "text-violet" : e.type === "cron" ? "text-[oklch(0.88_0.18_145)]" : e.type === "system" ? "text-cyan-accent" : "text-muted-foreground/50"}`}>
                  {e.type.toUpperCase()}
                </span>
                <span className="text-foreground/70 truncate">{e.message}</span>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Service pills */}
      <div className="flex flex-wrap gap-1">
        {[
          { label: "GATEWAY", ok: stats.gatewayStatus === "running" },
          { label: "CRON", ok: stats.activeCrons > 0 },
          { label: "MEMORY", ok: true },
          { label: "WIKI", ok: true },
        ].map((s) => (
          <span key={s.label} className={`inline-flex items-center gap-1 rounded-full border px-2 py-0.5 font-mono text-[7px] tracking-wider ${s.ok ? "border-[oklch(0.30_0.04_265)] bg-[oklch(0.82_0.21_145)]/10 text-[oklch(0.88_0.18_145)]" : "border-destructive/30 bg-destructive/10 text-destructive"}`}>
            <span className={`h-1.5 w-1.5 rounded-full ${s.ok ? "bg-[oklch(0.88_0.18_145)]" : "bg-destructive"}`} />
            {s.label}
          </span>
        ))}
      </div>
    </div>
  );
}

// ── Dashboard Chronometer ──────────────────────────────────────────────────
function DashboardChronometer({ stats }: { stats: SystemStats }) {
  return (
    <div className="rounded-lg border border-border/30 bg-card/20 px-2.5 py-1.5">
      <div className="font-mono text-[8px] tracking-[0.15em] text-muted-foreground/50 mb-1">CHRONOMETER</div>
      <div className="grid grid-cols-2 gap-2">
        <div>
          <div className="font-mono text-[8px] text-muted-foreground/40 tracking-wider">MAC</div>
          <div className="font-mono text-sm font-bold tracking-wider text-foreground/90">{stats.uptime}</div>
        </div>
        <div>
          <div className="font-mono text-[8px] text-muted-foreground/40 tracking-wider">GATEWAY</div>
          <div className={`font-mono text-sm font-bold tracking-wider ${
            stats.gatewayStatus === "running" ? "text-[oklch(0.88_0.18_145)]" : "text-destructive"
          }`}>
            {stats.gatewayUptime}
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Dashboard Disk Widget ────────────────────────────────────────────────────
function DashboardDiskWidget({ stats }: { stats: SystemStats }) {
  const diskWarn = stats.diskPercent >= 85;
  const wdWarn = stats.wdDiskPercent >= 85;
  const wdAvailable = stats.wdDiskMount !== "—";

  return (
    <div className="rounded-lg border border-border/30 bg-card/20 px-2.5 py-1.5">
      <div className="font-mono text-[8px] tracking-[0.15em] text-muted-foreground/50 mb-1">STORAGE</div>
      <div className="flex items-center gap-4">
        {/* Internal */}
        <div className="flex-1 space-y-1">
          <div className="flex items-center gap-2">
            <span className="font-mono text-[8px] text-muted-foreground/70">INTERNAL</span>
            {diskWarn && <span className="font-mono text-[7px] text-warning">⚠</span>}
          </div>
          <div className="h-1.5 w-full rounded-full bg-muted/30 overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-1000 ${
                diskWarn ? "bg-warning" : "bg-[oklch(0.88_0.18_145)]"
              }`}
              style={{ width: `${Math.min(stats.diskPercent, 100)}%` }}
            />
          </div>
          <div className={`font-mono text-[9px] ${diskWarn ? "text-warning font-bold" : "text-foreground/60"}`}>
            {stats.diskPercent}% · {stats.diskFree} free
          </div>
        </div>

        {/* WD MyCloud */}
        {wdAvailable && (
          <div className="flex-1 space-y-1">
            <div className="flex items-center gap-2">
              <span className="font-mono text-[8px] text-muted-foreground/70">WD MYCLOUD</span>
              {wdWarn && <span className="font-mono text-[7px] text-warning">⚠</span>}
            </div>
            <div className="h-1.5 w-full rounded-full bg-muted/30 overflow-hidden">
              <div
                className={`h-full rounded-full transition-all duration-1000 ${
                  wdWarn ? "bg-warning" : "bg-cyan-accent"
                }`}
                style={{ width: `${Math.min(stats.wdDiskPercent, 100)}%` }}
              />
            </div>
            <div className={`font-mono text-[9px] ${wdWarn ? "text-warning font-bold" : "text-foreground/60"}`}>
              {stats.wdDiskPercent}% · {stats.wdDiskUsed}/{stats.wdDiskTotal}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ── Right panel: Quick Actions ───────────────────────────────────────────────
function QuickActionsPanel({ stats }: { stats: SystemStats }) {
  const [dreamingEnabled, setDreamingEnabled] = useState<boolean | null>(null);
  const [toggling, setToggling] = useState(false);
  const [result, setResult] = useState<string | null>(null);

  useEffect(() => {
    getDreamingState().then((res) => { if (res.ok) setDreamingEnabled(res.enabled); }).catch(() => setDreamingEnabled(false));
  }, []);

  const handleToggleDreaming = async () => {
    setToggling(true);
    try {
      const res = await toggleDreaming();
      if (res.ok) setDreamingEnabled(res.enabled);
      setResult(res.message);
    } catch (err) { setResult(`Failed: ${err}`); }
    setToggling(false);
    setTimeout(() => setResult(null), 3000);
  };

  return (
    <div className="space-y-2 pl-1">
      <div className="font-mono text-[8px] tracking-[0.15em] text-muted-foreground/50">QUICK ACTIONS</div>

      {/* Dreaming toggle */}
      <div className={`rounded-lg border px-3 py-2 transition-all ${dreamingEnabled ? "border-[oklch(0.30_0.04_265)] bg-[oklch(0.82_0.21_145)]/10" : "border-border/40 bg-card/20"}`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Moon className={`h-4 w-4 ${dreamingEnabled ? "text-[oklch(0.88_0.18_145)]" : "text-muted-foreground/50"}`} />
            <div>
              <div className="text-xs font-medium">Dreaming</div>
              <div className="font-mono text-[9px] text-muted-foreground/50">{dreamingEnabled ? "Memory consolidation active" : "Paused"}</div>
            </div>
          </div>
          <button onClick={handleToggleDreaming} disabled={toggling} className={`relative inline-flex h-5 w-9 items-center rounded-full transition-colors ${dreamingEnabled ? "bg-[oklch(0.88_0.18_145)]" : "bg-muted-foreground/30"} ${toggling ? "opacity-50" : "cursor-pointer"}`}>
            <span className={`inline-block h-3 w-3 transform rounded-full bg-white transition-transform ${dreamingEnabled ? "translate-x-5" : "translate-x-1"}`} />
          </button>
        </div>
        {result && <div className="mt-1 text-[9px] text-[oklch(0.88_0.18_145)]">{result}</div>}
      </div>

      {/* System info */}
      <div className="rounded-lg border border-border/30 bg-card/20 px-3 py-2 space-y-1.5">
        <div className="font-mono text-[9px] tracking-[0.2em] text-muted-foreground/60">SYSTEM</div>
        <div className="flex items-center justify-between text-xs">
          <span className="text-muted-foreground">Model</span>
          <span className="font-mono text-[10px]">{stats.model?.split("/").pop() || "—"}</span>
        </div>
        <div className="flex items-center justify-between text-xs">
          <span className="text-muted-foreground">Gateway</span>
          <span className={`font-mono text-[10px] ${stats.gatewayStatus === "running" ? "text-[oklch(0.88_0.18_145)]" : "text-destructive"}`}>{stats.gatewayStatus}</span>
        </div>
        <div className="flex items-center justify-between text-xs">
          <span className="text-muted-foreground">Crons</span>
          <span className="font-mono text-[10px]">{stats.activeCrons}/{stats.totalCrons}</span>
        </div>
      </div>

      {/* Health bars */}
      <div className="rounded-lg border border-border/30 bg-card/20 px-3 py-2 space-y-2">
        <div className="font-mono text-[9px] tracking-[0.2em] text-muted-foreground/60">HEALTH</div>
        {[
          { label: "CPU", pct: Math.min(Math.round(parseFloat(stats.cpuLoad) || 0), 100), warn: 80 },
          { label: "DISK", pct: stats.diskPercent, warn: 85 },
          { label: "MEM", pct: stats.memoryPercent, warn: 85 },
        ].map((item) => (
          <div key={item.label} className="space-y-1">
            <div className="flex items-center justify-between text-[10px]">
              <span className="text-muted-foreground">{item.label}</span>
              <span className={`font-mono ${item.pct >= item.warn ? "text-warning" : "text-foreground/60"}`}>{item.pct}%</span>
            </div>
            <div className="h-1 w-full rounded-full bg-muted/30 overflow-hidden">
              <div className={`h-full rounded-full transition-all ${item.pct >= item.warn ? "bg-warning" : "bg-[oklch(0.88_0.18_145)]"}`} style={{ width: `${Math.min(item.pct, 100)}%` }} />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Risk Meter Widget ──────────────────────────────────────────────────────
function RiskMeterWidget({ items }: { items: RiskMeterItem[] }) {
  const [currentTime, setCurrentTime] = useState<Date | null>(null);
  useEffect(() => { setCurrentTime(new Date()); const t = setInterval(() => setCurrentTime(new Date()), 1000); return () => clearInterval(t); }, []);

  if (!items || items.length === 0) return null;

  return (
    <div className="rounded-lg border border-border/30 bg-card/20 p-3">
      <div className="flex items-center gap-2 mb-2">
        <TrendingUp className="h-3.5 w-3.5 text-warning" />
        <div className="font-mono text-[9px] tracking-[0.2em] text-muted-foreground/60">RISK METER</div>
      </div>
      <div className="space-y-2">
        {items.map((item, idx) => {
          const age = currentTime ? (currentTime.getTime() - new Date(item.detectedAt).getTime()) / 60000 : 0;
          const maxAge = 60; // 60 min countdown
          const remaining = Math.max(0, maxAge - age);
          const urgencyColor = item.confidence >= 80 ? "text-destructive" : item.confidence >= 70 ? "text-warning" : "text-violet";
          const barColor = item.confidence >= 80 ? "bg-destructive" : item.confidence >= 70 ? "bg-warning" : "bg-violet";
          return (
            <div key={idx} className="space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-[10px] text-foreground/70 truncate flex-1">{item.label}</span>
                <span className={`font-mono text-[9px] ${urgencyColor} shrink-0 ml-2`}>{item.confidence}%</span>
              </div>
              <div className="h-1 w-full rounded-full bg-muted/30 overflow-hidden">
                <div className={`h-full rounded-full ${barColor}`} style={{ width: `${item.confidence}%` }} />
              </div>
              <div className="flex items-center justify-between">
                <span className="font-mono text-[8px] text-muted-foreground/40 truncate">{item.detail.substring(0, 50)}</span>
                <span className="font-mono text-[8px] text-muted-foreground/40">{Math.round(remaining)}m</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ── Auto-Heal Status Panel ──────────────────────────────────────────────────
function AutoHealStatusPanel({ state, audit }: { state: AutoHealState; audit: AutoHealAuditEntry[] }) {
  const total = state.total_heals || 0;
  const success = state.success_count || 0;
  const failed = state.fail_count || 0;
  const level = state.auto_heal_level || "none";
  const recentActions = audit.slice(-5).reverse();

  return (
    <div className="rounded-lg border border-border/30 bg-card/20 p-3">
      <div className="flex items-center gap-2 mb-2">
        <Wrench className="h-3.5 w-3.5 text-cyan-accent" />
        <div className="font-mono text-[9px] tracking-[0.2em] text-muted-foreground/60">AUTO-HEAL</div>
        <span className={`ml-auto font-mono text-[7px] tracking-wider px-1.5 py-0.5 rounded ${
          level === "none" ? "bg-muted/20 text-muted-foreground/40" :
          level === "low" ? "bg-[oklch(0.82_0.21_145)]/10 text-[oklch(0.88_0.18_145)]" :
          level === "medium" ? "bg-violet/10 text-violet" :
          "bg-cyan-accent/10 text-cyan-accent"
        }`}>{level.toUpperCase()}</span>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-3 gap-2 mb-2">
        <div className="text-center">
          <div className="font-mono text-sm font-bold text-foreground/80">{total}</div>
          <div className="font-mono text-[7px] text-muted-foreground/40">TOTAL</div>
        </div>
        <div className="text-center">
          <div className="font-mono text-sm font-bold text-[oklch(0.88_0.18_145)]">{success}</div>
          <div className="font-mono text-[7px] text-muted-foreground/40">SUCCESS</div>
        </div>
        <div className="text-center">
          <div className="font-mono text-sm font-bold text-destructive">{failed}</div>
          <div className="font-mono text-[7px] text-muted-foreground/40">FAILED</div>
        </div>
      </div>

      {/* Recent actions */}
      {recentActions.length > 0 && (
        <div className="space-y-1">
          <div className="font-mono text-[7px] tracking-wider text-muted-foreground/30">RECENT</div>
          {recentActions.map((entry, idx) => (
            <div key={idx} className="flex items-center gap-1.5 text-[9px]">
              <span className={`h-1.5 w-1.5 rounded-full shrink-0 ${
                entry.results.length > 0 && entry.results.every(r => r.status === "success") ? "bg-[oklch(0.88_0.18_145)]" :
                entry.results.some(r => r.status === "rollback" || r.status === "timeout") ? "bg-destructive" :
                entry.results.some(r => r.status === "dry_run") ? "bg-cyan-accent" :
                "bg-muted-foreground/30"
              }`} />
              <span className="text-foreground/50 truncate">{entry.task_title.substring(0, 35)}</span>
              <span className="ml-auto text-muted-foreground/30 shrink-0">{entry.ts.substring(11, 16)}</span>
            </div>
          ))}
        </div>
      )}

      {recentActions.length === 0 && (
        <div className="text-[9px] text-muted-foreground/30 text-center py-1">No auto-heal actions yet</div>
      )}
    </div>
  );
}

// ── Performance Insights Panel ─────────────────────────────────────────────
function PerformanceInsightsPanel({ state }: { state: PerformanceState }) {
  const agents = Object.entries(state.agents || {});
  const pendingTunes = (state.tune_tasks || []).filter((t: any) => t.status === "pending");

  return (
    <div className="rounded-lg border border-border/30 bg-card/20 p-3">
      <div className="flex items-center gap-2 mb-2">
        <Activity className="h-3.5 w-3.5 text-violet" />
        <div className="font-mono text-[9px] tracking-[0.2em] text-muted-foreground/60">PERFORMANCE</div>
        {pendingTunes.length > 0 && (
          <span className="ml-auto font-mono text-[7px] bg-violet/10 text-violet px-1.5 py-0.5 rounded">
            {pendingTunes.length} tune{pendingTunes.length > 1 ? "s" : ""}
          </span>
        )}
      </div>

      {/* Agent efficiency scores */}
      {agents.length > 0 && (
        <div className="space-y-1.5 mb-2">
          {agents.map(([agent, stats]: [string, any]) => {
            const successRate = stats.success_rate || 0;
            const score = Math.round(successRate * 100);
            const scoreColor = score >= 90 ? "text-[oklch(0.88_0.18_145)]" : score >= 70 ? "text-warning" : "text-destructive";
            const barColor = score >= 90 ? "bg-[oklch(0.88_0.18_145)]" : score >= 70 ? "bg-warning" : "bg-destructive";
            return (
              <div key={agent} className="space-y-0.5">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] text-foreground/70">{agent}</span>
                  <span className={`font-mono text-[9px] ${scoreColor}`}>{score}%</span>
                </div>
                <div className="h-1 w-full rounded-full bg-muted/30 overflow-hidden">
                  <div className={`h-full rounded-full ${barColor}`} style={{ width: `${score}%` }} />
                </div>
                <div className="flex items-center justify-between text-[8px] text-muted-foreground/40">
                  <span>{stats.done || 0} tasks · {stats.avg_task_hours || 0}h avg</span>
                  <span>{(stats.failure_rate * 100 || 0).toFixed(0)}% fail</span>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Pending tuning suggestions */}
      {pendingTunes.length > 0 && (
        <div className="space-y-1">
          <div className="font-mono text-[7px] tracking-wider text-muted-foreground/30">PROPOSED TUNES</div>
          {pendingTunes.slice(0, 3).map((tune: any, idx: number) => (
            <div key={idx} className="flex items-center gap-1.5 text-[9px]">
              <span className={`h-1.5 w-1.5 rounded-full shrink-0 ${
                tune.confidence >= 80 ? "bg-violet" : "bg-muted-foreground/30"
              }`} />
              <span className="text-foreground/50 truncate">{tune.label}</span>
              <span className="ml-auto text-muted-foreground/30 shrink-0">{tune.confidence}%</span>
            </div>
          ))}
        </div>
      )}

      {agents.length === 0 && pendingTunes.length === 0 && (
        <div className="text-[9px] text-muted-foreground/30 text-center py-1">No performance data yet</div>
      )}
    </div>
  );
}

// ── Main Dashboard component ─────────────────────────────────────────────────

interface DashboardProps {
  agents: AgentStatus[];
  systemStats: SystemStats;
  openclawStats?: OpenClawStatus;
  activity?: ActivityEvent[];
  incidents?: Incident[];
  allTasks?: Task[];
  riskItems?: RiskMeterItem[];
  autoHealState?: AutoHealState;
  autoHealAudit?: AutoHealAuditEntry[];
  performanceState?: PerformanceState;
}

export function Dashboard({ agents, systemStats, openclawStats: _openclawStats, activity = [], incidents = [], allTasks = [], riskItems = [], autoHealState, autoHealAudit = [], performanceState }: DashboardProps) {
  // Compute awaiting review count from loader data (no client-side fs import needed)
  const awaitingReviewCount = allTasks.filter((t) => t.status === "awaiting_review").length;

  void _openclawStats;

  // Determine station mood from stats + open incidents
  const openIncidents = (incidents || []).filter((i) => i.status !== "RESOLVED");
  const hasP1 = openIncidents.some((i) => i.severity === "P1");
  const hasP2 = openIncidents.some((i) => i.severity === "P2");
  const hasP3P4 = openIncidents.some((i) => i.severity === "P3" || i.severity === "P4");
  const mood: "calm" | "busy" | "alert" | "critical" =
    systemStats.gatewayStatus !== "running" ? "critical" :
    hasP1 ? "critical" :
    hasP2 ? "alert" :
    hasP3P4 ? "busy" :
    agents.filter(a => a.status === "active" && a.tasksActive > 0).length >= 2 ? "busy" : "calm";

  // Alert banner data
  const openIncidentCount = openIncidents.length;
  const p1Count = openIncidents.filter((i) => i.severity === "P1").length;
  const p2Count = openIncidents.filter((i) => i.severity === "P2").length;

  // Map incident owners to rooms for pulse effect
  const AGENT_ROOMS: Record<string, string> = {
    monkey: "command",
    lifesupport: "security",
    engineer: "workshop",
    archivist: "archive",
  };
  const activeIncidentRooms = Array.from(
    new Set(
      openIncidents
        .filter((i) => i.owner && AGENT_ROOMS[i.owner])
        .map((i) => AGENT_ROOMS[i.owner!])
    )
  );

  // Visiting agent tracking for crew visits
  const [visitingAgentId, setVisitingAgentId] = useState<string | null>(null);

  // Celebration trigger — when a task completes, briefly celebrate
  const [celebrate, setCelebrate] = useState(false);
  const prevDoneCount = useRef(0);
  useEffect(() => {
    const currentDone = allTasks.filter(t => t.status === "done").length;
    if (prevDoneCount.current > 0 && currentDone > prevDoneCount.current) {
      setCelebrate(true);
      setTimeout(() => setCelebrate(false), 3000);
    }
    prevDoneCount.current = currentDone;
  }, [allTasks]);

  // ── Operational Readiness: derived data ──────────────────────────────────
  const backlogTasks = allTasks.filter((t) => t.status === "backlog");
  const inProgressTasks = allTasks.filter((t) => t.status === "in_progress");
  const stalledTasks = allTasks.filter((t) => t.status === "in_progress" && t.stalledAt);
  const backlogCount = backlogTasks.length;

  // Agent load: count tasks per agent
  const agentLoad = agents.map((a) => {
    const agentTasks = allTasks.filter((t) => t.assignee === a.id && t.status !== "done");
    const active = agentTasks.filter((t) => t.status === "in_progress").length;
    const assigned = agentTasks.filter((t) => t.status === "backlog" || t.status === "triage").length;
    return { id: a.id, name: a.name, total: agentTasks.length, active, assigned };
  });

  // Station status determination
  const stationStatus: "nominal" | "warning" | "critical" =
    openIncidents.some((i) => i.severity === "P1") ? "critical" :
    openIncidents.length > 0 || stalledTasks.length > 0 ? "warning" : "nominal";
  const stationStatusText =
    stationStatus === "critical" ? "🔴 P1 incident requires attention" :
    stationStatus === "warning" ? `🟡 ${openIncidents.length} incident${openIncidents.length > 1 ? "s" : ""}${stalledTasks.length > 0 ? `, ${stalledTasks.length} stalled task${stalledTasks.length > 1 ? "s" : ""}` : ""}` :
    "🟢 All systems nominal";

  return (
    <div className="space-y-4">
      {/* Auto-refresh every 30s */}
      <DashboardRefresher intervalMs={30000} />

      {/* Station Status Bar */}
      <div className={`flex items-center gap-3 rounded-lg border px-4 py-2 text-sm ${
        stationStatus === "critical"
          ? "border-red-400/40 bg-red-400/10 text-red-400"
          : stationStatus === "warning"
          ? "border-amber-400/40 bg-amber-400/10 text-amber-400"
          : "border-[oklch(0.88_0.18_145)]/30 bg-[oklch(0.88_0.18_145)]/5 text-[oklch(0.88_0.18_145)]"
      }`}>
        <span className="font-mono text-xs tracking-wider">STATION STATUS</span>
        <span className="text-xs">{stationStatusText}</span>
        <span className="ml-auto font-mono text-[10px] text-muted-foreground/50">
          {backlogCount} backlog · {inProgressTasks.length} active · {agents.filter(a => a.status === "active").length}/{agents.length} agents
        </span>
      </div>

      {/* Alert banner — shown when incidents are open */}
      {openIncidentCount > 0 && (
        <Link
          to="/incidents"
          className={`flex items-center gap-3 rounded-lg border px-4 py-2.5 text-sm transition-colors ${
            p1Count > 0
              ? "border-red-400/40 bg-red-400/10 text-red-400"
              : p2Count > 0
              ? "border-amber-400/40 bg-amber-400/10 text-amber-400"
              : "border-border/40 bg-card/30 text-muted-foreground"
          }`}
        >
          <AlertTriangle className="h-4 w-4 shrink-0" />
          <span>
            ⚠️ {openIncidentCount} open incident{openIncidentCount > 1 ? "s" : ""}
            {p1Count > 0 && ` — ${p1Count} P1`}
            {p2Count > 0 && `, ${p2Count} P2`}
          </span>
          <span className="ml-auto text-xs opacity-70">View Incidents →</span>
        </Link>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4" style={{ animation: "fade-in 0.4s ease-out" }}>
      {/* Left (75-80%): Agent Office — living station */}
      <div className="lg:col-span-9">
        <AmbientStation mood={mood}>
          <StationFloorplan enableVisits onVisitingAgentChange={setVisitingAgentId} activeIncidentRooms={activeIncidentRooms as any}>
            {CREW.map(member => {
              const liveStatus = agents.find(a => a.id === member.id);
              const isAway = visitingAgentId === member.id;
              return (
                <AgentOffice
                  key={member.id}
                  crew={member}
                  liveStatus={liveStatus ? {
                    id: liveStatus.id,
                    name: liveStatus.name,
                    status: liveStatus.status === "active" && liveStatus.tasksActive > 0 ? "working" as const : "idle" as const,
                    currentAction: liveStatus.currentAction,
                    tasksActive: liveStatus.tasksActive,
                  } : undefined}
                  isAway={isAway}
                />
              );
            })}
          </StationFloorplan>
          <CelebrationOverlay active={celebrate} />
        </AmbientStation>
      </div>

      {/* Right (20-25%): Info panels stacked tightly */}
      <div className="lg:col-span-3 space-y-2">
        <DashboardChronometer stats={systemStats} />
        <DashboardDiskWidget stats={systemStats} />

        {/* Agent Load Indicators */}
        <div className="rounded-lg border border-border/30 bg-card/20 p-3">
          <div className="font-mono text-[9px] tracking-[0.2em] text-muted-foreground/60 mb-2">AGENT LOAD</div>
          <div className="space-y-1.5">
            {agentLoad.map((a) => (
              <div key={a.id} className="flex items-center justify-between text-xs">
                <span className="text-foreground/70">{a.name}</span>
                <span className="font-mono text-[10px] text-muted-foreground/50">
                  {a.total} task{a.total !== 1 ? "s" : ""}
                  {a.total > 0 && (
                    <span className="text-muted-foreground/30">
                      {' '}({a.active} active, {a.assigned} assigned)
                    </span>
                  )}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Risk Meter Widget */}
        <RiskMeterWidget items={riskItems} />

        {/* Auto-Heal Status Panel */}
        {autoHealState && <AutoHealStatusPanel state={autoHealState} audit={autoHealAudit} />}

        {/* Performance Insights Panel */}
        {performanceState && <PerformanceInsightsPanel state={performanceState} />}

        {/* Recent Events Panel */}
        <RecentEventsPanel events={activity} />

        <LiveActivityFeed events={activity} stats={systemStats} />
        {awaitingReviewCount > 0 && (
          <Link
            to="/tasks"
            className="flex items-center gap-2 rounded-lg border border-warning/40 bg-warning/5 px-3 py-2 text-xs hover:bg-warning/10 transition-colors"
          >
            <AlertTriangle className="h-3.5 w-3.5 text-warning" />
            <span className="text-warning font-medium">{awaitingReviewCount} Awaiting Review</span>
          </Link>
        )}
        <QuickActionsPanel stats={systemStats} />
      </div>

      {/* Footer */}
      <div className="lg:col-span-12 flex items-center justify-between rounded-lg border border-border/20 bg-card/10 px-4 py-2 gap-4 flex-wrap">
        <div className="font-mono text-[9px] text-muted-foreground/40 tracking-wider">OPENCLAW STATION · v2026.5.7 · {systemStats.hostname}</div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5">
            <span className={`inline-block h-1.5 w-1.5 rounded-full ${
              systemStats.gatewayStatus === "running" ? "bg-[oklch(0.88_0.18_145)] animate-pulse" : "bg-destructive"
            }`} />
            <span className="font-mono text-[8px] text-muted-foreground/50">
              {systemStats.gatewayStatus === "running" ? "ALL SYSTEMS GO" : "GATEWAY DOWN"}
            </span>
          </div>
          <span className="text-muted-foreground/20">|</span>
          <span className="font-mono text-[8px] text-muted-foreground/50">
            {systemStats.activeCrons} crons · {Math.round(parseFloat(systemStats.cpuLoad) || 0)}% CPU · {systemStats.memoryPercent}% RAM
          </span>
        </div>
        <div className="font-mono text-[9px] text-muted-foreground/40 tracking-wider">MODEL: {systemStats.model}</div>
      </div>
    </div>
  </div>
);
}
