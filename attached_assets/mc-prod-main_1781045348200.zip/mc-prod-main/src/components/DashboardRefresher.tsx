// src/components/DashboardRefresher.tsx
// Auto-refreshes dashboard data every 30 seconds

import { useEffect } from "react";
import { useRouter } from "@tanstack/react-router";

interface DashboardRefresherProps {
  intervalMs?: number;
}

export function DashboardRefresher({ intervalMs = 30000 }: DashboardRefresherProps) {
  const router = useRouter();

  useEffect(() => {
    const interval = setInterval(() => {
      // Invalidate the current route's loader data to trigger a refetch
      router.invalidate();
    }, intervalMs);

    return () => clearInterval(interval);
  }, [router, intervalMs]);

  return null;
}
