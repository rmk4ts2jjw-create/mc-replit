import { useEffect, useState, useCallback, useRef } from "react";
import { CREW, getCrew, type CrewMember } from "@/lib/crew";
import { getAgentStatus } from "@/lib/server-data/agent-status";
import { getSystemStats } from "@/lib/server-data/system";
import { getQueue } from "@/lib/server-data/tasks";
import { getActivityFeed } from "@/lib/server-data/activity";
import type { AgentStatus, SystemStats, OpenClawStatus, ActivityEvent } from "@/lib/server-data-types";
import roomCommand from "@/assets/room-command-4x-v2.png";
import { getRotationFact, getRandomComment, getRandomChatter } from "@/lib/delights";
import roomSecurity from "@/assets/room-lifesupport-4x-v2.png";
import roomWorkshop from "@/assets/room-engineer-4x-v2.png";
import roomArchive from "@/assets/room-archivist-4x-v2.png";

// ── Types ────────────────────────────────────────────────────────────────────

interface AgentPosition {
  x: number;
  y: number;
}

interface AgentState {
  agent: AgentStatus;
  crew: CrewMember;
  status: "working" | "idle" | "away" | "collaborating";
  position: AgentPosition;
  targetPosition?: AgentPosition;
  currentAction?: string;
}

interface StationAlert {
  id: string;
  message: string;
  severity: "info" | "warning" | "error";
  agentId?: string;
}

// ── Room configuration ───────────────────────────────────────────────────────
// Each room is a pixel-art background image (768×512).
// Config-driven: add new rooms by adding entries here.

const ROOMS: Record<string, {
  label: string;
  occupantId: string;
  bgImage: string;
  accent: string;
  accentHue: number;
  agentPos: { xPct: number; yPct: number };
  monitors: { xPct: number; yPct: number; w: number; h: number; label?: string }[];
  ambientElements?: { xPct: number; yPct: number; type: "radar" | "pulse" | "flicker" };
}> = {
  command: {
    label: "COMMAND HQ",
    occupantId: "monkey",
    bgImage: roomCommand,
    accent: "violet",
    accentHue: 295,
    agentPos: { xPct: 0.50, yPct: 0.55 },
    monitors: [
      { xPct: 0.12, yPct: 0.18, w: 90, h: 55, label: "TASKS" },
      { xPct: 0.62, yPct: 0.14, w: 100, h: 60, label: "STATUS" },
    ],
    ambientElements: { xPct: 0.85, yPct: 0.75, type: "radar" },
  },
  security: {
    label: "SECURITY BAY",
    occupantId: "lifesupport",
    bgImage: roomSecurity,
    accent: "pink",
    accentHue: 0,
    agentPos: { xPct: 0.50, yPct: 0.55 },
    monitors: [
      { xPct: 0.08, yPct: 0.12, w: 75, h: 48, label: "HEALTH" },
      { xPct: 0.68, yPct: 0.18, w: 75, h: 48, label: "ALERTS" },
      { xPct: 0.38, yPct: 0.08, w: 65, h: 42, label: "LOGS" },
    ],
    ambientElements: { xPct: 0.15, yPct: 0.80, type: "pulse" },
  },
  workshop: {
    label: "ENGINEERING",
    occupantId: "engineer",
    bgImage: roomWorkshop,
    accent: "cyan",
    accentHue: 200,
    agentPos: { xPct: 0.50, yPct: 0.55 },
    monitors: [
      { xPct: 0.18, yPct: 0.16, w: 80, h: 50, label: "BUILD" },
      { xPct: 0.58, yPct: 0.20, w: 70, h: 45, label: "DEPLOY" },
    ],
    ambientElements: { xPct: 0.82, yPct: 0.72, type: "flicker" },
  },
  archive: {
    label: "ARCHIVE",
    occupantId: "archivist",
    bgImage: roomArchive,
    accent: "warning",
    accentHue: 90,
    agentPos: { xPct: 0.50, yPct: 0.55 },
    monitors: [
      { xPct: 0.12, yPct: 0.18, w: 85, h: 52, label: "MEMORY" },
      { xPct: 0.62, yPct: 0.16, w: 80, h: 50, label: "WIKI" },
    ],
    ambientElements: { xPct: 0.50, yPct: 0.82, type: "pulse" },
  },
};

// ── Agent action descriptions ───────────────────────────────────────────────

function getAgentAction(crewId: string, status: AgentState["status"]): string {
  if (status === "idle") return "Standing by...";
  if (status === "away") return "Offline";
  if (status === "collaborating") {
    const actions = ["Coordinating with crew", "Reviewing shared task", "Syncing progress"];
    return actions[Math.floor(Math.random() * actions.length)];
  }
  // Working
  switch (crewId) {
    case "monkey": return "Orchestrating mission";
    case "lifesupport": return "Monitoring systems";
    case "engineer": return "Building & deploying";
    case "archivist": return "Consolidating memory";
    default: return "Working";
  }
}

// ── CSS Animation keyframes ─────────────────────────────────────────────────

function injectStyles() {
  if (document.getElementById("spacestation-styles")) return;
  const style = document.createElement("style");
  style.id = "spacestation-styles";
  style.textContent = `
    @keyframes sprite-bounce {
      0%, 100% { transform: translateY(0); }
      50% { transform: translateY(-3px); }
    }
    @keyframes sprite-hack {
      0%, 100% { transform: translateX(0) rotate(0deg); }
      20% { transform: translateX(2px) rotate(1deg); }
      40% { transform: translateX(-1px) rotate(-0.5deg); }
      60% { transform: translateX(1.5px) rotate(0.5deg); }
      80% { transform: translateX(-2px) rotate(-1deg); }
    }
    @keyframes sprite-monitor {
      0%, 100% { transform: scale(1); }
      50% { transform: scale(1.02); }
    }
    @keyframes sprite-idle {
      0%, 100% { opacity: 0.7; }
      50% { opacity: 0.9; }
    }
    @keyframes screen-glow {
      0%, 100% { opacity: 0.3; }
      50% { opacity: 0.8; }
    }
    @keyframes alert-pulse {
      0%, 100% { opacity: 1; }
      50% { opacity: 0.3; }
    }
    @keyframes fade-in {
      from { opacity: 0; transform: translateY(6px); }
      to { opacity: 1; transform: translateY(0); }
    }
    @keyframes walk-bounce {
      0%, 100% { transform: translateY(0); }
      25% { transform: translateY(-2px) translateX(3px); }
      50% { transform: translateY(0) translateX(6px); }
      75% { transform: translateY(-2px) translateX(3px); }
    }
    @keyframes blink-terminal {
      0%, 45%, 55%, 100% { opacity: 1; }
      50% { opacity: 0; }
    }
    @keyframes radar-sweep {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }
    @keyframes ambient-pulse {
      0%, 100% { opacity: 0.2; transform: scale(1); }
      50% { opacity: 0.5; transform: scale(1.1); }
    }
    @keyframes flicker {
      0%, 100% { opacity: 0.6; }
      5% { opacity: 0.3; }
      10% { opacity: 0.7; }
      15% { opacity: 0.4; }
      20% { opacity: 0.8; }
    }
    @keyframes activity-scroll {
      0% { transform: translateY(100%); }
      100% { transform: translateY(-100%); }
    }
    .sprite-working { animation: sprite-bounce 1.4s ease-in-out infinite; }
    .sprite-hacking { animation: sprite-hack 0.7s ease-in-out infinite; }
    .sprite-monitoring { animation: sprite-monitoring 2.5s ease-in-out infinite; }
    .sprite-idle { animation: sprite-idle 3s ease-in-out infinite; }
    .sprite-away { opacity: 0.3; filter: grayscale(0.7); }
    .sprite-walking { animation: walk-bounce 0.5s ease-in-out infinite; }
    .screen-active { animation: screen-glow 2.5s ease-in-out infinite; }
    .alert-blink { animation: alert-pulse 1.2s ease-in-out infinite; }
    .terminal-blink { animation: blink-terminal 1s step-end infinite; }
    .radar-sweep { animation: radar-sweep 4s linear infinite; }
    .ambient-pulse { animation: ambient-pulse 3s ease-in-out infinite; }
    .ambient-flicker { animation: flicker 5s step-end infinite; }
    .pixel-room { image-rendering: pixelated; image-rendering: crisp-edges; }
    @keyframes slide-in-right {
      from { transform: translateX(100%); }
      to { transform: translateX(0); }
    }
  `;
  document.head.appendChild(style);
}

// ── Agent sprite renderer ────────────────────────────────────────────────────

function AgentSprite({ agentState, onClick }: {
  agentState: AgentState;
  onClick?: () => void;
}) {
  const { agent, crew, status } = agentState;
  const [currentPos, setCurrentPos] = useState(agentState.position);
  const [isMoving, setIsMoving] = useState(false);
  const moveTimeout = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);

  useEffect(() => {
    if (agentState.targetPosition &&
        (agentState.targetPosition.x !== currentPos.x || agentState.targetPosition.y !== currentPos.y)) {
      setIsMoving(true);
      if (moveTimeout.current) clearTimeout(moveTimeout.current);
      moveTimeout.current = setTimeout(() => {
        setCurrentPos(agentState.targetPosition!);
        setIsMoving(false);
      }, 1800);
      return () => { if (moveTimeout.current) clearTimeout(moveTimeout.current); };
    }
  }, [agentState.targetPosition]);

  const getAnimationClass = () => {
    if (isMoving) return "sprite-walking";
    switch (status) {
      case "working":
        if (crew.id === "engineer") return "sprite-hacking";
        if (crew.id === "lifesupport") return "sprite-monitoring";
        return "sprite-working";
      case "collaborating": return "sprite-working";
      case "idle": return "sprite-idle";
      case "away": return "sprite-away";
      default: return "";
    }
  };

  const getStatusColor = () => {
    switch (status) {
      case "working": return "text-[oklch(0.88_0.18_145)]";
      case "collaborating": return "text-[oklch(0.85_0.12_200)]";
      case "idle": return "text-muted-foreground";
      case "away": return "text-muted-foreground/40";
      default: return "text-foreground";
    }
  };

  const getStatusLabel = () => {
    switch (status) {
      case "working": return "ON DUTY";
      case "collaborating": return "IN MEETING";
      case "idle": return "STANDBY";
      case "away": return "AWAY";
      default: return "";
    }
  };

  const accentColor = crew.accent === "violet" ? "oklch(0.62 0.22 295)"
    : crew.accent === "pink" ? "oklch(0.72 0.20 0)"
    : crew.accent === "cyan" ? "oklch(0.78 0.14 200)"
    : "oklch(0.85 0.18 90)";

  const action = getAgentAction(crew.id, status);

  return (
    <div
      className="absolute transition-all duration-[1800ms] ease-in-out cursor-pointer group"
      style={{
        left: `${currentPos.x}%`,
        top: `${currentPos.y}%`,
        zIndex: isMoving ? 30 : 10,
        transform: "translate(-50%, -50%)",
      }}
      onClick={onClick}
    >
      <div className={`relative ${getAnimationClass()}`}>
        {(status === "working" || status === "collaborating") && (
          <div className="absolute -inset-3 rounded-full opacity-20 blur-md"
            style={{ background: accentColor }}
          />
        )}

        <img
          src={isMoving ? crew.sprites.walking : status === "working" || status === "collaborating" ? crew.sprites.working : crew.sprites.idle}
          alt={crew.name}
          className={`w-14 h-14 rounded-lg border-2 object-cover pixel-room ${status === "away" ? "grayscale" : ""}`}
          style={{
            borderColor: status === "working" ? "oklch(0.88 0.18 145)"
              : status === "collaborating" ? "oklch(0.85 0.12 200)"
              : status === "idle" ? "oklch(0.30 0.04 265)"
              : "oklch(0.25 0.04 265)",
            imageRendering: "pixelated",
          }}
        />

        <span className={`absolute -top-1 -right-1 h-3.5 w-3.5 rounded-full border-2 border-[#12182A] ${
          status === "working" ? "bg-[oklch(0.88_0.18_145)]" :
          status === "collaborating" ? "bg-[oklch(0.85_0.12_200)]" :
          status === "idle" ? "bg-warning" : "bg-muted-foreground/40"
        } ${status === "working" ? "animate-pulse" : ""}`} />
      </div>

      <div className={`mt-1.5 text-center transition-opacity ${isMoving ? "opacity-40" : ""}`}>
        <div className={`font-mono text-[9px] tracking-wider ${getStatusColor()}`}>
          {crew.emoji} {getStatusLabel()}
        </div>
        {(status === "working" || status === "collaborating") && (
          <div className="font-mono text-[7px] text-foreground/40 mt-0.5 truncate max-w-[80px]">
            {action}
          </div>
        )}
        {agent.tasksActive > 0 && (
          <div className="font-mono text-[8px] text-foreground/50 mt-0.5">
            {agent.tasksActive} task{agent.tasksActive > 1 ? "s" : ""}
          </div>
        )}
      </div>

      <div className="absolute left-1/2 -translate-x-1/2 top-full mt-2 hidden group-hover:block z-50 w-52 rounded-lg border border-border bg-[#12182A]/95 backdrop-blur p-3 shadow-xl">
        <div className="font-mono text-[10px] text-muted-foreground tracking-wider">{crew.name.toUpperCase()}</div>
        <div className="text-xs font-medium mt-0.5">{crew.shortRole}</div>
        <div className="font-mono text-[9px] text-muted-foreground mt-1">model: {crew.model}</div>
        <div className="font-mono text-[9px] text-muted-foreground mt-0.5">status: {status}</div>
        {agent.tasksActive > 0 && (
          <div className="mt-1.5 pt-1.5 border-t border-border/30 font-mono text-[9px] text-[oklch(0.88_0.18_145)]">
            {agent.tasksActive} active task{agent.tasksActive > 1 ? "s" : ""}
          </div>
        )}
        <div className="mt-1.5 pt-1.5 border-t border-border/30 text-[9px] text-muted-foreground/60 italic">
          "{getRandomComment(crew.id)}"
        </div>
      </div>
    </div>
  );
}

// ── Room component ───────────────────────────────────────────────────────────

function AgentRoom({
  roomId,
  room,
  agentState,
  alerts,
  onAgentClick,
}: {
  roomId: string;
  room: typeof ROOMS[string];
  agentState?: AgentState;
  alerts?: StationAlert[];
  onAgentClick?: (id: string) => void;
}) {
  const isActive = agentState && (agentState.status === "working" || agentState.status === "collaborating");
  const hue = room.accentHue;

  return (
    <div className="relative overflow-hidden rounded-xl border border-border/40 group">
      <img
        src={room.bgImage}
        alt={room.label}
        className="w-full h-auto pixel-room"
        style={{ imageRendering: "pixelated" }}
      />

      {/* Room label */}
      <div className="absolute top-2 left-3 z-10 font-mono text-[10px] tracking-[0.25em] text-muted-foreground/60">
        {room.label}
      </div>

      {/* Animated monitors */}
      {room.monitors.map((m, i) => (
        <div
          key={`mon-${m.xPct}-${m.yPct}-${i}`}
          className={`absolute rounded-sm ${isActive ? "screen-active" : ""}`}
          style={{
            left: `${m.xPct * 100}%`,
            top: `${m.yPct * 100}%`,
            width: m.w,
            height: m.h,
            background: isActive
              ? `linear-gradient(180deg, oklch(0.40 0.08 ${hue} / 0.25) 0%, oklch(0.30 0.06 ${hue} / 0.12) 50%, oklch(0.40 0.08 ${hue} / 0.25) 100%)`
              : `linear-gradient(180deg, oklch(0.25 0.04 ${hue} / 0.08) 0%, oklch(0.20 0.03 ${hue} / 0.03) 100%)`,
            boxShadow: isActive
              ? agentState && agentState.agent.tasksActive > 2
                ? `0 0 20px oklch(0.50 0.10 ${hue} / 0.4), 0 0 40px oklch(0.50 0.10 ${hue} / 0.15)`
                : `0 0 12px oklch(0.50 0.10 ${hue} / 0.25)`
              : "none",
          }}
        >
          <div className="absolute inset-0 opacity-15"
            style={{
              backgroundImage: "repeating-linear-gradient(0deg, transparent, transparent 2px, oklch(0.50 0.10 ${hue} / 0.3) 2px, oklch(0.50 0.10 ${hue} / 0.3) 4px)",
            }}
          />
          {isActive && (
            <div className="absolute bottom-1 left-1 w-1.5 h-2 bg-[oklch(0.88_0.18_145)] terminal-blink" />
          )}
          {m.label && (
            <div className="absolute top-0.5 left-1 font-mono text-[6px] text-foreground/30 tracking-wider">
              {m.label}
            </div>
          )}
        </div>
      ))}

      {/* Ambient elements */}
      {room.ambientElements && (
        <div
          className={`absolute pointer-events-none ${
            room.ambientElements.type === "radar" ? "radar-sweep" :
            room.ambientElements.type === "pulse" ? "ambient-pulse" :
            "ambient-flicker"
          }`}
          style={{
            left: `${room.ambientElements.xPct * 100}%`,
            top: `${room.ambientElements.yPct * 100}%`,
            width: 20,
            height: 20,
            borderRadius: "50%",
            background: `radial-gradient(circle, oklch(0.50 0.10 ${hue} / 0.3) 0%, transparent 70%)`,
          }}
        />
      )}

      {/* Agent sprite */}
      {agentState && (
        <AgentSprite
          agentState={agentState}
          onClick={() => onAgentClick?.(agentState.crew.id)}
        />
      )}

      {/* Room dimming for idle/away */}
      {agentState?.status === "idle" && (
        <div className="absolute inset-0 bg-[#12182A]/15 pointer-events-none" />
      )}
      {agentState?.status === "away" && (
        <div className="absolute inset-0 bg-[#12182A]/35 pointer-events-none" />
      )}

      {/* Subtle vignette */}
      <div className="absolute inset-0 pointer-events-none"
        style={{ boxShadow: "inset 0 0 40px oklch(0.10 0.02 265 / 0.4)" }}
      />

      {/* Station reactivity: alert glow for incidents */}
      {alerts && alerts.some(a => a.agentId === room.occupantId) && (
        <div className="absolute inset-0 pointer-events-none border-2 border-destructive/30 rounded-xl animate-pulse" />
      )}
    </div>
  );
}

// ── Activity feed ────────────────────────────────────────────────────────────

// Diegetic message transformer — converts raw logs into station language
function diegeticMessage(e: ActivityEvent): string {
  const msg = e.message;
  if (e.type === "cron") {
    if (msg.includes("backup")) return "Life Support secured the station archives.";
    if (msg.includes("completed")) return "Mission assignment completed successfully.";
    if (msg.includes("failed")) return "Operational anomaly detected — investigation required.";
    if (msg.includes("started")) return "Automated sequence initiated.";
    return `Station process: ${msg}`;
  }
  if (e.type === "task") {
    if (msg.includes("dispatched")) return "Mission assignment transmitted to crew.";
    if (msg.includes("completed")) return "Mission objective achieved.";
    if (msg.includes("created")) return "New mission parameters received.";
    return `Crew action: ${msg}`;
  }
  if (e.type === "system") {
    if (msg.includes("restart")) return "Station systems reinitialised.";
    if (msg.includes("error")) return "System anomaly flagged for review.";
    if (msg.includes("mount")) return "External storage link status updated.";
    return `Station status: ${msg}`;
  }
  return msg;
}

function ActivityFeed({ events }: { events: ActivityEvent[] }) {
  if (events.length === 0) return null;

  return (
    <div className="rounded-xl border border-border/30 bg-card/20 overflow-hidden">
      <div className="px-4 py-2 border-b border-border/20 font-mono text-[10px] tracking-[0.2em] text-muted-foreground/60">
        STATION LOG
      </div>
      <div className="max-h-36 overflow-y-auto">
        {events.slice(0, 10).map((e) => (
          <div key={e.id} className="flex items-start gap-2 px-4 py-1.5 text-xs border-b border-border/10 last:border-0 activity-item">
            <span className="font-mono text-[9px] text-muted-foreground/40 shrink-0 mt-0.5">
              {new Date(e.ts).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" })}
            </span>
            <span className={`font-mono text-[8px] tracking-wider shrink-0 mt-0.5 px-1 py-0.5 rounded ${
              e.type === "task" ? "bg-violet/10 text-violet" :
              e.type === "cron" ? "bg-[oklch(0.88_0.18_145)]/10 text-[oklch(0.88_0.18_145)]" :
              e.type === "system" ? "bg-cyan-accent/10 text-cyan-accent" :
              "bg-muted/10 text-muted-foreground/50"
            }`}>
              {e.type === "task" ? "MISSION" : e.type === "cron" ? "AUTO" : e.type === "system" ? "SYS" : e.type.toUpperCase()}
            </span>
            <span className="text-foreground/70 truncate">{diegeticMessage(e)}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── System health bar ────────────────────────────────────────────────────────

function HealthBar({ stats }: { stats: SystemStats }) {
  const healthItems = [
    { label: "CPU", pct: Math.min(Math.round(parseFloat(stats.cpuLoad) || 0), 100), warn: 80 },
    { label: "DISK", pct: stats.diskPercent, warn: 85 },
    { label: "MEM", pct: stats.memoryPercent, warn: 85 },
  ];

  return (
    <div className="flex items-center gap-4">
      {healthItems.map((item) => {
        const warn = item.pct >= item.warn;
        return (
          <div key={item.label} className="flex items-center gap-2">
            <span className="font-mono text-[9px] text-muted-foreground tracking-wider">{item.label}</span>
            <div className="h-1.5 w-16 rounded-full bg-muted/30 overflow-hidden">
              <div
                className={`h-full rounded-full transition-all duration-1000 ${
                  warn ? "bg-warning" : "bg-[oklch(0.88_0.18_145)]"
                }`}
                style={{ width: `${Math.min(item.pct, 100)}%` }}
              />
            </div>
            <span className={`font-mono text-[9px] ${warn ? "text-warning" : "text-foreground/60"}`}>
              {item.pct}%
            </span>
          </div>
        );
      })}
    </div>
  );
}

// ── Disk Space Widget ────────────────────────────────────────────────────────

function DiskWidget({ stats }: { stats: SystemStats }) {
  const diskWarn = stats.diskPercent >= 85;
  const wdWarn = stats.wdDiskPercent >= 85;
  const wdAvailable = stats.wdDiskMount !== "—";

  return (
    <div className="rounded-xl border border-border/30 bg-card/20 overflow-hidden">
      <div className="px-4 py-2 border-b border-border/20 font-mono text-[10px] tracking-[0.2em] text-muted-foreground/60">
        STORAGE
      </div>
      <div className="px-4 py-3 space-y-3">
        {/* Internal disk */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="font-mono text-[9px] text-muted-foreground/70">INTERNAL</span>
              {diskWarn && <span className="font-mono text-[8px] text-warning">⚠ HIGH</span>}
            </div>
            <span className={`font-mono text-[9px] ${diskWarn ? "text-warning" : "text-foreground/60"}`}>
              {stats.diskUsed} / {stats.diskTotal}
            </span>
          </div>
          <div className="h-2 w-full rounded-full bg-muted/30 overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-1000 ${
                diskWarn ? "bg-warning" : "bg-[oklch(0.88_0.18_145)]"
              }`}
              style={{ width: `${Math.min(stats.diskPercent, 100)}%` }}
            />
          </div>
          <div className="flex items-center justify-between">
            <span className={`font-mono text-[10px] ${diskWarn ? "text-warning font-bold" : "text-foreground/70"}`}>
              {stats.diskPercent}% used
            </span>
            <span className="font-mono text-[9px] text-muted-foreground/50">
              {stats.diskFree} free
            </span>
          </div>
        </div>

        {/* WD MyCloud disk */}
        {wdAvailable && (
          <div className="space-y-1.5 pt-2 border-t border-border/20">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="font-mono text-[9px] text-muted-foreground/70">WD MYCLOUD</span>
                {wdWarn && <span className="font-mono text-[8px] text-warning">⚠ HIGH</span>}
              </div>
              <span className={`font-mono text-[9px] ${wdWarn ? "text-warning" : "text-foreground/60"}`}>
                {stats.wdDiskUsed} / {stats.wdDiskTotal}
              </span>
            </div>
            <div className="h-2 w-full rounded-full bg-muted/30 overflow-hidden">
              <div
                className={`h-full rounded-full transition-all duration-1000 ${
                  wdWarn ? "bg-warning" : "bg-cyan-accent"
                }`}
                style={{ width: `${Math.min(stats.wdDiskPercent, 100)}%` }}
              />
            </div>
            <div className="flex items-center justify-between">
              <span className={`font-mono text-[10px] ${wdWarn ? "text-warning font-bold" : "text-foreground/70"}`}>
                {stats.wdDiskPercent}% used
              </span>
              <span className="font-mono text-[9px] text-muted-foreground/50">
                {stats.wdDiskMount}
              </span>
            </div>
          </div>
        )}

        {!wdAvailable && (
          <div className="pt-2 border-t border-border/20">
            <div className="flex items-center gap-2">
              <span className="font-mono text-[9px] text-muted-foreground/70">WD MYCLOUD</span>
              <span className="font-mono text-[8px] text-muted-foreground/40">— not mounted</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ── Ship's Chronometer ──────────────────────────────────────────────────────

function ShipsChronometer({ stats }: { stats: SystemStats }) {
  return (
    <div className="rounded-xl border border-border/30 bg-card/20 overflow-hidden">
      <div className="px-4 py-2 border-b border-border/20 font-mono text-[10px] tracking-[0.2em] text-muted-foreground/60">
        SHIP'S CHRONOMETER
      </div>
      <div className="px-4 py-3">
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1">
            <div className="font-mono text-[9px] text-muted-foreground/50 tracking-wider">MAC UPTIME</div>
            <div className="font-mono text-lg font-bold tracking-wider text-foreground/90">{stats.uptime}</div>
            <div className="font-mono text-[8px] text-muted-foreground/40">since last boot</div>
          </div>
          <div className="space-y-1">
            <div className="font-mono text-[9px] text-muted-foreground/50 tracking-wider">GATEWAY UPTIME</div>
            <div className={`font-mono text-lg font-bold tracking-wider ${
              stats.gatewayStatus === "running" ? "text-[oklch(0.88_0.18_145)]" : "text-destructive"
            }`}>
              {stats.gatewayUptime}
            </div>
            <div className="font-mono text-[8px] text-muted-foreground/40">
              {stats.gatewayStatus === "running" ? "gateway active" : "gateway " + stats.gatewayStatus}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Service pills ────────────────────────────────────────────────────────────

function ServicePills({ stats }: { stats: SystemStats }) {
  const services = [
    { label: "GATEWAY", ok: stats.gatewayStatus === "running" },
    { label: "CRON", ok: stats.activeCrons > 0 },
    { label: "TELEGRAM", ok: true },
    { label: "MEMORY", ok: true },
    { label: "WIKI", ok: true },
  ];

  return (
    <div className="flex gap-1.5 flex-wrap">
      {services.map((s) => (
        <span
          key={s.label}
          className={`inline-flex items-center gap-1 rounded-full border px-2 py-0.5 font-mono text-[8px] tracking-wider ${
            s.ok
              ? "border-[oklch(0.30_0.04_265)] bg-[oklch(0.82_0.21_145)]/10 text-[oklch(0.88_0.18_145)]"
              : "border-destructive/30 bg-destructive/10 text-destructive"
          }`}
        >
          <span className={`h-1.5 w-1.5 rounded-full ${s.ok ? "bg-[oklch(0.88_0.18_145)]" : "bg-destructive"}`} />
          {s.label}
        </span>
      ))}
    </div>
  );
}

// ── Alerts strip ─────────────────────────────────────────────────────────────

function AlertsStrip({ alerts }: { alerts: StationAlert[] }) {
  if (alerts.length === 0) return null;
  return (
    <div className="space-y-1">
      {alerts.map((a) => (
        <div
          key={a.id}
          className={`flex items-center gap-2 rounded-md border px-3 py-1.5 text-xs ${
            a.severity === "error" ? "border-destructive/30 bg-destructive/10 text-destructive alert-blink"
            : a.severity === "warning" ? "border-warning/30 bg-warning/10 text-warning"
            : "border-border/60 bg-card/40 text-muted-foreground"
          }`}
        >
          <span className="font-mono text-[9px]">
            {a.severity === "error" ? "⚠" : a.severity === "warning" ? "◆" : "○"}
          </span>
          <span>{a.message}</span>
        </div>
      ))}
    </div>
  );
}

// ── Main Spacestation component ──────────────────────────────────────────────

interface SpacestationProps {
  agents: AgentStatus[];
  systemStats: SystemStats;
  openclawStats?: OpenClawStatus;
  queue?: ActivityEvent[];
  activity?: ActivityEvent[];
  alerts?: StationAlert[];
  incidents?: Array<{ id: string; severity: string; status: string; title: string; summary: string }>;
  onAgentClick?: (agentId: string) => void;
}

export function Spacestation({ agents, systemStats, openclawStats: _openclawStats, activity = [], alerts = [], incidents = [], onAgentClick }: SpacestationProps) {
  const [currentTime, setCurrentTime] = useState<Date | null>(null);

  useEffect(() => {
    injectStyles();
    setCurrentTime(new Date());
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const getAgentState = useCallback((crewMember: CrewMember, agentData?: AgentStatus): AgentState => {
    const isActive = agentData?.status === "active";
    const taskCount = agentData?.tasksActive ?? 0;
    const isWorking = isActive && taskCount > 0;
    const isIdle = isActive && taskCount === 0;
    const isAway = !isActive;

    const workingAgents = agents.filter(a => (a.tasksActive ?? 0) > 0);
    const isCollaborating = workingAgents.length >= 2 && isWorking;

    let status: AgentState["status"] = "away";
    if (isCollaborating) status = "collaborating";
    else if (isWorking) status = "working";
    else if (isIdle) status = "idle";

    const homeRoom = crewMember.id === "monkey" ? "command"
      : crewMember.id === "lifesupport" ? "security"
      : crewMember.id === "engineer" ? "workshop"
      : "archive";
    const roomDef = ROOMS[homeRoom];
    const pos: AgentPosition = {
      x: roomDef.agentPos.xPct * 100,
      y: roomDef.agentPos.yPct * 100,
    };

    return {
      agent: agentData || {
        id: crewMember.id,
        name: crewMember.name,
        role: crewMember.role,
        emoji: crewMember.emoji,
        status: "active" as const,
        model: crewMember.model,
        lastActive: "unknown",
        tasksActive: 0,
      },
      crew: crewMember,
      status,
      position: pos,
      currentAction: getAgentAction(crewMember.id, status),
    };
  }, [agents]);

  const agentStates = CREW.map(c => getAgentState(c, agents.find(a => a.id === c.id)));
  const workingCount = agentStates.filter(a => a.status === "working" || a.status === "collaborating").length;
  const idleCount = agentStates.filter(a => a.status === "idle").length;
  const collaboratingCount = agentStates.filter(a => a.status === "collaborating").length;

  void _openclawStats;

  return (
    <div className="space-y-4" style={{ animation: "fade-in 0.4s ease-out" }}>
      {/* Station header */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
            <span className="text-2xl">🐒</span>
            <span>Mission Control</span>
          </h1>
          <div className="mt-0.5 font-mono text-[10px] text-muted-foreground tracking-wider">
            STATION STATUS · {workingCount} ACTIVE · {idleCount} STANDBY
            {collaboratingCount >= 2 && <span className="text-cyan-accent"> · {collaboratingCount} COLLABORATING</span>}
            {currentTime ? ` · ${currentTime.toLocaleTimeString("en-GB")} UTC+1` : ""}
          </div>
        </div>
        <div className="flex flex-col items-end gap-2">
          <ServicePills stats={systemStats} />
          <HealthBar stats={systemStats} />
        </div>
      </div>

      {/* Incident alert banner for open P1/P2 */}
      {incidents.filter(i => i.status !== "RESOLVED" && (i.severity === "P1" || i.severity === "P2")).length > 0 && (
        <div className={`rounded-lg border px-4 py-2 flex items-center gap-3 ${
          incidents.some(i => i.severity === "P1" && i.status !== "RESOLVED")
            ? "border-destructive/40 bg-destructive/10"
            : "border-warning/40 bg-warning/10"
        }`}>
          <span className="font-mono text-xs">
            {incidents.some(i => i.severity === "P1" && i.status !== "RESOLVED") ? "🚨" : "⚠️"}
          </span>
          <div className="flex-1">
            <span className="font-mono text-[10px] tracking-wider">
              {incidents.filter(i => i.status !== "RESOLVED" && (i.severity === "P1" || i.severity === "P2")).length} OPEN INCIDENT{incidents.filter(i => i.status !== "RESOLVED" && (i.severity === "P1" || i.severity === "P2")).length > 1 ? "S" : ""}
            </span>
            <span className="font-mono text-[10px] text-muted-foreground ml-2">
              {incidents.filter(i => i.status !== "RESOLVED" && (i.severity === "P1" || i.severity === "P2")).map(i => i.id).join(", ")}
            </span>
          </div>
          <a href="/incidents" className="font-mono text-[9px] tracking-wider text-muted-foreground hover:text-foreground underline">
            VIEW →
          </a>
        </div>
      )}

      {/* Alerts */}
      <AlertsStrip alerts={alerts} />

      {/* Chronometer + Disk */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <ShipsChronometer stats={systemStats} />
        <DiskWidget stats={systemStats} />
      </div>

      {/* Main station — seamless 2×2 room grid */}
      <div className="grid grid-cols-2 gap-0 border border-border/20 rounded-lg overflow-hidden">
        {(["command", "security", "workshop", "archive"] as const).map((roomId) => {
          const room = ROOMS[roomId];
          const state = agentStates.find(s => s.crew.id === room.occupantId);
          return (
            <AgentRoom
              key={roomId}
              roomId={roomId}
              room={room}
              agentState={state}
              onAgentClick={onAgentClick}
            />
          );
        })}
      </div>

      {/* Collaboration indicator */}
      {collaboratingCount >= 2 && (
        <div className="flex items-center justify-center gap-2 font-mono text-[10px] tracking-wider text-cyan-accent/70">
          <span className="inline-block h-2 w-2 rounded-full bg-cyan-accent animate-pulse" />
          COLLABORATION ACTIVE — {collaboratingCount} AGENTS WORKING TOGETHER
        </div>
      )}

      {/* Activity feed */}
      <ActivityFeed events={activity} />

      {/* Station footer */}
      <div className="flex items-center justify-between rounded-lg border border-border/20 bg-card/10 px-4 py-2">
        <div className="font-mono text-[9px] text-muted-foreground/40 tracking-wider">
          OPENCLAW STATION · v2026.5.7 · {systemStats.hostname}
        </div>
        <div className="font-mono text-[9px] text-muted-foreground/40 tracking-wider">
          MODEL: {systemStats.model}
        </div>
      </div>
    </div>
  );
}
