// src/routes/visual.tsx
// Agent Office — the living, animated station view

import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/PageHeader";
import { AgentOffice } from "@/components/AgentOffice";
import { AmbientStation } from "@/components/AmbientStation";
import { StationFloorplan } from "@/components/StationFloorplan";
import { CelebrationOverlay } from "@/components/CelebrationOverlay";
import { CREW } from "@/lib/crew";
import { getAgentStatus } from "@/lib/server-data/agent-status";
import { getSystemStats } from "@/lib/server-data/system";
import { getIncidents } from "@/lib/server-data/incidents";
import { useState } from "react";
import type { LiveAgentStatus } from "@/lib/live-data";

export const Route = createFileRoute("/visual")({
  head: () => ({ meta: [{ title: "Agent Office — Mission Control" }] }),
  loader: async () => {
    const [agents, stats, incidents] = await Promise.all([
      getAgentStatus(),
      getSystemStats(),
      getIncidents(),
    ]);
    return { agents, stats, incidents };
  },
  component: VisualPage,
});

function VisualPage() {
  const { agents, stats, incidents } = Route.useLoaderData();
  const [visitingAgentId, setVisitingAgentId] = useState<string | null>(null);

  const mood: "calm" | "busy" | "alert" | "critical" =
    stats.gatewayStatus !== "running" ? "critical" :
    agents.filter(a => a.status === "active" && a.tasksActive > 0).length >= 2 ? "busy" : "calm";

  return (
    <>
      <PageHeader
        icon="🎮"
        title="Agent Office"
        right={
          <span className="font-mono text-xs text-muted-foreground">
            Live pixel-art station view
          </span>
        }
      >
        A persistent orbital workspace where the AI crew works, collaborates, and maintains the station in real time.
      </PageHeader>

      <AmbientStation mood={mood}>
        <StationFloorplan enableVisits onVisitingAgentChange={setVisitingAgentId}>
          {CREW.map(member => {
            const liveStatus = agents.find(a => a.id === member.id);
            const isAway = visitingAgentId === member.id;
            return (
              <AgentOffice
                key={member.id}
                crew={member}
                liveStatus={liveStatus ? {
                  id: liveStatus.id,
                  name: liveStatus.name,
                  status: liveStatus.status === "active" && liveStatus.tasksActive > 0 ? "working" as const : "idle" as const,
                  currentAction: liveStatus.currentAction,
                  tasksActive: liveStatus.tasksActive,
                } : undefined}
                isAway={isAway}
              />
            );
          })}
        </StationFloorplan>
        <CelebrationOverlay active={false} />
      </AmbientStation>
    </>
  );
}
