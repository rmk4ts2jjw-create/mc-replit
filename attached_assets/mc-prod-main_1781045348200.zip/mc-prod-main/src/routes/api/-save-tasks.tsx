// src/routes/api/save-tasks.ts
// API route for saving tasks — MERGE-based to prevent data loss.
//
// PROBLEM: The MC frontend loads tasks once into React state, then
// writes the entire array back on every mutation. If tasks were added
// externally (cron, dispatcher, agent) between page load and save,
// those tasks were destroyed by the full-array overwrite.
//
// FIX: Before writing, read the current tasks.json. Merge in the
// client's changes, preserving any tasks that exist on disk but not
// in the incoming array. The client's version wins for tasks it knows
// about (it may have mutated status/progress/etc). Tasks only on disk
// are preserved as-is.

import { writeFileSync, readFileSync, renameSync, existsSync, mkdirSync } from "node:fs";
import { join } from "node:path";

const WORKSPACE = process.env.OPENCLAW_WORKSPACE || "/Users/spacemonkey/.openclaw/workspace";

// Simple in-memory mutex for single-process safety
let writeLock = false;
let writeQueue: (() => void)[] = [];

function acquireLock(): Promise<void> {
  return new Promise((resolve) => {
    if (!writeLock) {
      writeLock = true;
      resolve();
    } else {
      writeQueue.push(resolve);
    }
  });
}

function releaseLock() {
  const next = writeQueue.shift();
  if (next) {
    next();
  } else {
    writeLock = false;
  }
}

export async function POST({ request }: { request: Request }) {
  await acquireLock();
  try {
    const clientTasks = await request.json() as Record<string, unknown>[];
    const dir = join(WORKSPACE, "data");
    if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
    const path = join(dir, "tasks.json");

    // Read current disk state
    let diskTasks: Record<string, unknown>[] = [];
    try {
      if (existsSync(path)) {
        const raw = JSON.parse(readFileSync(path, "utf-8"));
        diskTasks = Array.isArray(raw) ? raw : Object.entries(raw).map(([id, t]: [string, any]) => ({ ...t, id }));
      }
    } catch {
      // File corrupt or missing — use client version as base
    }

    // Merge: client wins for tasks it knows about, disk-only tasks preserved
    // But protect critical disk-side fields the client may have lost
    const clientIds = new Set(clientTasks.map(t => t.id as string));
    const diskOnlyTasks = diskTasks.filter(t => !clientIds.has(t.id as string));
    const diskTaskMap = new Map(diskTasks.map(t => [t.id, t]));
    const PROTECTED_FIELDS = ['stalledAt', 'stallNotified', 'dispatchCount'];
    const mergedClientTasks = clientTasks.map(ct => {
      const dt = diskTaskMap.get(ct.id);
      if (!dt) return ct;
      const merged = { ...ct };
      for (const field of PROTECTED_FIELDS) {
        if (dt[field] && !ct[field]) {
          merged[field] = dt[field];
        }
      }
      return merged;
    });
    const merged = [...mergedClientTasks, ...diskOnlyTasks];

    // Count for logging
    const preserved = diskOnlyTasks.length;
    const addedBackIds = diskOnlyTasks.map(t => t.id as string);

    // Atomic write: write to temp, then rename
    const tmpPath = path + ".tmp";
    writeFileSync(tmpPath, JSON.stringify(merged, null, 2), "utf-8");
    renameSync(tmpPath, path);
    console.log(`[save-tasks] Merged ${clientTasks.length} client + ${preserved} disk-only = ${merged.length} total`);
    if (preserved > 0) {
      console.log(`[save-tasks] Preserved disk-only tasks: ${addedBackIds.join(", ")}`);
    }

    // Station Memory auto-ingestion: check for newly completed tasks
    try {
      const ingestUrl = process.env.MC_BASE_URL || "http://192.168.68.64:3000";
      const newlyDone = clientTasks.filter(
        (ct) => ct.status === "done" &&
          (!diskTaskMap.get(ct.id as string) || diskTaskMap.get(ct.id as string)?.status !== "done")
      );
      for (const task of newlyDone) {
        try {
          const resp = await fetch(`${ingestUrl}/api/station-memory/ingest`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ type: "task", id: task.id }),
          });
          const result = await resp.json() as { ok: boolean; id?: string; error?: string };
          if (result.ok) {
            console.log(`[save-tasks] Station Memory ingested task ${task.id} → ${result.id}`);
          } else if (!result.error?.includes("already")) {
            console.log(`[save-tasks] Station Memory skip task ${task.id}: ${result.error}`);
          }
        } catch (e) {
          // Non-fatal: don't block task save
          console.error(`[save-tasks] Station Memory ingest failed for task ${task.id}:`, e);
        }
      }
    } catch (e) {
      console.error("[save-tasks] Station Memory ingest check failed:", e);
    }

    return new Response(JSON.stringify({ ok: true, merged: merged.length, preserved }), {
      headers: { "Content-Type": "application/json" },
    });
  } catch (err) {
    console.error("[save-tasks] Error:", err);
    return new Response(JSON.stringify({ ok: false, error: String(err) }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  } finally {
    releaseLock();
  }
}
