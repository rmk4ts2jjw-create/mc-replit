// src/routes/api/cron-toggle.tsx
// Cron toggle API — handled by handleApiRequest in src/server.ts
// This stub export prevents TanStack Router warnings about non-route files.
export function Route() {
  return null;
}
